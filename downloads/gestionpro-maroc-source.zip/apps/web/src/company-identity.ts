export type Palette = { label: string; primary: string; accent: string; light: string };
export type CompanyIdentity = { palette: string; hasLogo: boolean; canManage: boolean; palettes: Record<string, Palette> };

export async function identityRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, { credentials: 'same-origin', cache: 'no-store', ...init });
  if (!response.ok) {
    const body = await response.json().catch(() => ({})) as { error?: string };
    const messages: Record<string, string> = {
      unauthorized: 'Session expirée.', forbidden: 'Modification réservée aux propriétaires et gestionnaires.',
      invalid_logo: 'Logo invalide ou trop volumineux.', payload_too_large: 'Logo trop volumineux (2 Mo maximum).',
      document_identity_unavailable: 'Identité des documents non initialisée sur cette base.'
    };
    throw new Error(messages[body.error ?? ''] ?? 'Opération indisponible.');
  }
  return response.json() as Promise<T>;
}
