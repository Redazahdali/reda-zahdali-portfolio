/** Presentation-only model. The API remains the single source of tenant/account truth. */
export type CompanyStatus = 'ACTIVE' | 'SETUP_PENDING' | 'CANCELLATION_PENDING' | 'CLOSED';
export type WorkspaceScreen = 'dashboard' | 'company' | 'account' | 'parties' | 'catalog' | 'quotes' | 'invoices';

export const MANAGEMENT_MODULES: readonly { id: string; title: string; screen?: WorkspaceScreen }[] = [
  { id: 'clients', title: 'Clients & Fournisseurs', screen: 'parties' },
  { id: 'products', title: 'Produits & Services', screen: 'catalog' },
  { id: 'quotes', title: 'Devis', screen: 'quotes' },
  { id: 'invoices', title: 'Factures', screen: 'invoices' },
  { id: 'credits', title: 'Avoirs' },
  { id: 'payments', title: 'Paiements & Encaissements' },
  { id: 'purchases', title: 'Achats & Dépenses' },
];

export interface ModulePreview {
  id: 'clients' | 'catalogue' | 'devis' | 'factures' | 'depenses';
  title: string;
  description: string;
  icon: 'users' | 'package' | 'file' | 'receipt' | 'wallet';
}

/** Preview only. No commercial action/data exists for these modules in DASH-01. */
export const UPCOMING_MODULES: readonly ModulePreview[] = [
  { id: 'clients', title: 'Clients & fournisseurs', description: 'Organise tes contacts professionnels dans un annuaire unique.', icon: 'users' },
  { id: 'catalogue', title: 'Produits & services', description: 'Prépare ton catalogue et tes articles.', icon: 'package' },
  { id: 'devis', title: 'Devis', description: 'Crée et suis tes propositions commerciales.', icon: 'file' },
  { id: 'factures', title: 'Factures', description: 'Émets tes documents de vente.', icon: 'receipt' },
  { id: 'depenses', title: 'Dépenses', description: 'Suis les frais de ton activité.', icon: 'wallet' },
];

export function statusLabel(status: CompanyStatus): string {
  const labels: Record<CompanyStatus, string> = {
    ACTIVE: 'Entreprise active',
    SETUP_PENDING: 'Configuration en cours',
    CANCELLATION_PENDING: 'Résiliation en cours',
    CLOSED: 'Entreprise clôturée',
  };
  return labels[status];
}

export function isWorkspacePath(path: string): boolean {
  return path === '/dashboard' || path === '/company' || path === '/account' || path === '/parties' || path === '/catalog' || path === '/quotes' || path === '/invoices';
}

export function formatRole(role: 'OWNER' | 'MANAGER' | 'EMPLOYEE'): string {
  return { OWNER: 'Propriétaire', MANAGER: 'Gestionnaire', EMPLOYEE: 'Collaborateur' }[role];
}
