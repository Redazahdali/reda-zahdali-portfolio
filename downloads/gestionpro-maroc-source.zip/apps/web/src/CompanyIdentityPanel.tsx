import React, {useEffect, useRef, useState, type ChangeEvent, type CSSProperties} from 'react';
import {identityRequest, type CompanyIdentity, type Palette} from './company-identity.js';

export function PaletteChoices({palettes, palette, disabled, onSelect}: {palettes: Record<string, Palette>; palette: string; disabled: boolean; onSelect: (id: string) => void}) {
  return <React.Fragment><fieldset className="document-palettes" disabled={disabled}><legend>Palette des documents</legend>{Object.entries(palettes).map(([id,p])=><label key={id} className={palette===id?'is-selected':''} style={{'--swatch-selection':p.primary} as CSSProperties}><input type="radio" name="document-palette" checked={palette===id} onChange={()=>onSelect(id)}/><span className="document-swatches" aria-hidden="true"><i style={{background:p.primary}}/><i style={{background:p.accent}}/></span><strong>{p.label}</strong></label>)}</fieldset></React.Fragment>;
}

type Props = {companyName: string; identity: CompanyIdentity; logoUrl: string | null; onIdentity: (identity: CompanyIdentity, logoChanged?: boolean) => void};
export default function CompanyIdentityPanel({companyName, identity, logoUrl, onIdentity}: Props) {
  const [palette, setPalette] = useState(identity.palette);
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const operation = useRef(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  useEffect(() => { if (!editing) setPalette(identity.palette); }, [identity.palette, editing]);
  const selected = identity.palettes[palette];
  const saved = identity.palettes[identity.palette];
  async function upload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file || operation.current) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 2_000_000) { setError('Choisis un PNG, JPEG ou WebP de 2 Mo maximum.'); return; }
    operation.current = true; setBusy(true); setError(''); setMessage('');
    try {
      const result = await identityRequest<{palette:string;hasLogo:boolean}>('/api/v1/company/document-identity/logo', {method:'POST', headers:{'Content-Type':file.type}, body:file});
      onIdentity({...identity, ...result}, true); setMessage('Logo enregistré.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Logo indisponible.'); }
    finally { operation.current = false; setBusy(false); }
  }
  async function save(removeLogo = false) {
    if (operation.current) return;
    operation.current = true; setBusy(true); setError(''); setMessage('');
    try {
      const result = await identityRequest<{palette:string;hasLogo:boolean}>('/api/v1/company/document-identity', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({palette:removeLogo ? identity.palette : palette, removeLogo})});
      onIdentity({...identity, ...result}, removeLogo);
      if (!removeLogo) { setEditing(false); setMessage('Couleurs enregistrées.'); }
      else setMessage('Logo supprimé.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Enregistrement impossible.'); }
    finally { operation.current = false; setBusy(false); }
  }
  return <section className="dash-detail-card document-identity">
    <span className="dash-kicker">PERSONNALISATION</span><h2>Identité des documents</h2>
    <p>Le logo et la palette s’appliquent à ton espace, aux devis et aux nouveaux documents. Les factures émises restent conservées.</p>
    {error && <p role="alert" className="party-feedback party-feedback-error">{error}</p>}
    {message && <p role="status" className="party-feedback party-feedback-success">{message}</p>}
    <div className="document-logo"><div>{identity.hasLogo && logoUrl ? <img src={logoUrl} alt="Logo actuel de l’entreprise"/> : <span>{identity.hasLogo ? 'Chargement du logo…' : 'Aucun logo personnalisé'}</span>}</div>
      {identity.canManage && <><label className="party-button party-button-secondary">Choisir un logo<input type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={e=>void upload(e)}/></label>
      {identity.hasLogo && <button type="button" className="party-button party-button-secondary" disabled={busy} onClick={()=>void save(true)}>Supprimer le logo</button>}
      <small>PNG, JPEG ou WebP · 2 Mo maximum. Le logo choisi est enregistré immédiatement.</small></>}
    </div>
    {!editing && <div className="document-saved"><div><span>Palette enregistrée</span><strong>{saved?.label ?? identity.palette}</strong></div>{saved && <div className="document-swatches" aria-hidden="true"><i style={{background:saved.primary}}/><i style={{background:saved.accent}}/></div>}{identity.canManage && <button type="button" className="party-button party-button-secondary" disabled={busy} onClick={()=>{setPalette(identity.palette);setEditing(true);setError('');setMessage('');}}>Modifier</button>}</div>}
    {editing && identity.canManage && <>
      <PaletteChoices palettes={identity.palettes} palette={palette} disabled={busy} onSelect={setPalette}/>
      <div className="document-palette-actions"><button type="button" className="party-button party-button-primary" disabled={busy} onClick={()=>void save()}>{busy?'Enregistrement…':'Enregistrer les couleurs'}</button><button type="button" className="party-button party-button-secondary" disabled={busy} onClick={()=>{setPalette(identity.palette);setEditing(false);setError('');}}>Annuler</button></div>
      {selected && <div className="document-preview" aria-label="Aperçu représentatif du document" style={{borderTopColor:selected.primary}}><div className="document-preview-head"><div>{identity.hasLogo && logoUrl && <img className="document-preview-logo" src={logoUrl} alt=""/>}<strong>{companyName}</strong></div><b style={{color:selected.primary}}>DEVIS</b></div><p>Client · Informations du document</p><div className="document-preview-table" style={{background:selected.light,color:selected.primary}}>Désignation <span>Montant HT</span></div><p>Produit ou service <span>1 000,00 MAD</span></p><div className="document-preview-total" style={{background:selected.light,color:selected.primary}}>Total TTC <strong>1 200,00 MAD</strong></div></div>}
    </>}
  </section>;
}
