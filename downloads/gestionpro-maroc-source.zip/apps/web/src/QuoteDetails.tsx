import React from 'react';
import {displayQuantity} from '../../api/src/company/document-display.js';

export type QuoteDetail = {id:string;quote_number:string;status:string;client_snapshot:{display_name:string};issued_on:string;valid_until:string;subject:string;notes:string;terms:string;total_net:string;total_tax:string;total_gross:string;lines:{item_snapshot:{name:string;description:string;unit:string};quantity:string;unit_price:string;discount_rate:string;tax_rate:string;net_amount:string}[]};
export type RelatedInvoice = {id:string;invoice_number:string|null;status:string;total_gross:string};
const quoteStatus=(status:string)=>({DRAFT:'Brouillon',SENT:'Envoyé',ACCEPTED:'Accepté',REJECTED:'Refusé',CANCELLED:'Annulé'} as Record<string,string>)[status]??status;
const invoiceStatus=(status:string)=>({DRAFT:'Brouillon',ISSUED:'Émise'} as Record<string,string>)[status]??status;
type Props={quote:QuoteDetail;related:RelatedInvoice[];relatedLoading:boolean;relatedError:string;offset:number;pending:boolean;retry:boolean;error:string;message:string;onPrevious:()=>void;onNext:()=>void;onInvoice:(id:string)=>void;onClose:()=>void;onEdit:()=>void;onConvert:()=>void};
export default function QuoteDetails(p:Props) {
 const q=p.quote;
 return <React.Fragment><div className="quote-detail-layout">
  <aside className="quote-context" aria-label="Devis sélectionné et factures associées">
   <span className="party-eyebrow">DEVIS SÉLECTIONNÉ</span><h2>{q.quote_number}</h2>
   <dl className="quote-context-summary"><div><dt>Client</dt><dd><bdi>{q.client_snapshot.display_name}</bdi></dd></div><div><dt>Statut</dt><dd>{quoteStatus(q.status)}</dd></div><div><dt>Total TTC</dt><dd>{q.total_gross} MAD</dd></div></dl>
   <div className="quote-related"><h3>Factures associées</h3>
    {p.relatedLoading&&<p role="status">Chargement des factures…</p>}
    {p.relatedError&&<p role="alert" className="party-feedback party-feedback-error">{p.relatedError}</p>}
    {!p.relatedLoading&&!p.relatedError&&!p.related.length&&<p className="quote-related-empty">Aucune facture associée.</p>}
    {!p.relatedLoading&&p.related.slice(0,25).map(invoice=><article key={invoice.id} className="quote-related-item"><div><strong>{invoice.invoice_number??'Facture brouillon'}</strong><span>{invoiceStatus(invoice.status)}</span><b>{invoice.total_gross} MAD TTC</b></div><button type="button" className="party-button party-button-secondary" disabled={p.pending||p.retry} onClick={()=>p.onInvoice(invoice.id)}>Voir la facture</button></article>)}
    {(p.offset>0||p.related.length>25)&&<div className="quote-related-pagination"><button type="button" className="party-button party-button-secondary" disabled={!p.offset||p.relatedLoading} onClick={p.onPrevious}>Précédent</button><button type="button" className="party-button party-button-secondary" disabled={p.related.length<=25||p.relatedLoading} onClick={p.onNext}>Suivant</button></div>}
   </div>
  </aside>
  <section className="party-detail quote-main-detail" aria-label="Détails du devis"><div className="party-section-heading"><div><span className="party-eyebrow">DEVIS {q.quote_number}</span><h2>{q.subject}</h2><p><bdi>{q.client_snapshot.display_name}</bdi> · {quoteStatus(q.status)}</p><p>Émis le {q.issued_on?.slice(0,10)} · Valable jusqu’au {q.valid_until?.slice(0,10)}</p></div><button type="button" className="party-button party-button-secondary" disabled={p.pending||p.retry} onClick={p.onClose}>Fermer</button></div>
   <div className="party-table-wrap quote-detail-lines"><table className="party-table"><thead><tr><th>Désignation</th><th>Quantité</th><th>Unité</th><th>Prix HT</th><th>Remise</th><th>TVA</th><th>Total HT</th></tr></thead><tbody>{q.lines.map((line,i)=><tr key={i}><td data-label="Désignation"><strong><bdi>{line.item_snapshot.name}</bdi></strong>{line.item_snapshot.description&&<span className="party-roles"><bdi>{line.item_snapshot.description}</bdi></span>}</td><td data-label="Quantité">{displayQuantity(line.quantity)}</td><td data-label="Unité">{line.item_snapshot.unit}</td><td data-label="Prix HT">{line.unit_price}</td><td data-label="Remise">{line.discount_rate} %</td><td data-label="TVA">{line.tax_rate} %</td><td data-label="Total HT">{line.net_amount}</td></tr>)}</tbody></table></div>
   {q.notes&&<p><strong>Notes : </strong><bdi>{q.notes}</bdi></p>}{q.terms&&<p><strong>Conditions : </strong><bdi>{q.terms}</bdi></p>}
   <div className="quote-totals"><span>HT <strong>{q.total_net} MAD</strong></span><span>TVA <strong>{q.total_tax} MAD</strong></span><span>TTC <strong>{q.total_gross} MAD</strong></span></div>
   <div className="party-form-actions">{q.status==='DRAFT'&&<button type="button" className="party-button party-button-secondary" disabled={p.pending||p.retry} onClick={p.onEdit}>Modifier</button>}<a className="party-button party-button-secondary" href={`/api/v1/quotes/${q.id}/pdf`}>Télécharger PDF</a><a className="party-button party-button-secondary" href={`/api/v1/quotes/${q.id}/pdf?inline=1`} target="_blank" rel="noreferrer">Imprimer</a></div>
   {p.error&&<p role="alert" className="party-feedback party-feedback-error">{p.error}</p>}{p.message&&<p role="status" className="party-feedback party-feedback-success">{p.message}</p>}
   <div className="quote-convert-action"><button type="button" className="party-button party-button-primary" disabled={p.pending} onClick={p.onConvert}>{p.pending?'Transformation en cours…':p.retry?'Réessayer la transformation':'Transformer en facture'}</button><p>Une nouvelle facture brouillon sera créée à partir de ce devis.</p></div>
  </section>
 </div></React.Fragment>;
}
