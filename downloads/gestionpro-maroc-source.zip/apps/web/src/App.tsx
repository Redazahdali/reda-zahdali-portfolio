import { useCallback, useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react';
import { MANAGEMENT_MODULES, UPCOMING_MODULES, statusLabel, formatRole, isWorkspacePath, type CompanyStatus, type WorkspaceScreen } from './dashboard-model.js';
import Quotes from './Quotes.js';
import Catalog from './Catalog.js';
import Invoices from './Invoices.js';
import CompanyIdentityPanel from './CompanyIdentityPanel.js';
import {identityRequest, type CompanyIdentity} from './company-identity.js';

type Screen = 'login' | 'register' | 'verify-email' | 'request-verification' | 'forgot-password' | 'reset-password' | 'invite' | WorkspaceScreen;
type AuthUser = { id: string; email: string; status: 'ACTIVE' };
type MyCompany = { id: string; name: string; status: CompanyStatus; role: 'OWNER' | 'MANAGER' | 'EMPLOYEE' }; 
type CompanyMember = { id: string; email: string; role: 'OWNER' | 'MANAGER' | 'EMPLOYEE'; status: 'ACTIVE' | 'DISABLED'; joinedAt: string };
type CompanyInvitation = { id: string; email: string; proposedRole: 'MANAGER' | 'EMPLOYEE'; status: 'PENDING' | 'REVOKED' | 'EXPIRED' | 'ACCEPTED'; expiresAt: string; createdAt: string; revokedAt: string | null };
type ApiError = { error?: string; status?: string };

type ButtonProps = { children: ReactNode; busy?: boolean; disabled?: boolean; variant?: 'primary' | 'secondary'; type?: 'button' | 'submit'; onClick?: () => void };

const GOOGLE_ENABLED = (import.meta as ImportMeta & { env?: { VITE_GOOGLE_OIDC_ENABLED?: string } }).env?.VITE_GOOGLE_OIDC_ENABLED === 'true';
const LOCAL_DEVELOPMENT = ['127.0.0.1', 'localhost'].includes(window.location.hostname);
const INVITE_KEY = 'gestionpro_pending_invitation';
// Remove the bearer token before React or any subsequent navigation runs.
if (window.location.pathname === '/invite') {
  const token = new URLSearchParams(window.location.search).get('token');
  if (token && /^[A-Za-z0-9_-]{43}$/.test(token)) sessionStorage.setItem(INVITE_KEY, token);
  if (window.location.search) window.history.replaceState({}, '', '/invite');
}

function getScreen(): Screen {
  switch (window.location.pathname) {
    case '/register': return 'register';
    case '/verify-email': return 'verify-email';
    case '/request-verification': return 'request-verification';
    case '/forgot-password': return 'forgot-password';
    case '/reset-password': return 'reset-password';
    case '/account': return 'account';
    case '/dashboard': return 'dashboard';
    case '/company': return 'company';
    case '/parties': return 'parties';
    case '/catalog': return 'catalog';
    case '/quotes': return 'quotes';
    case '/invoices': return 'invoices';
    case '/invite': return 'invite';
    default: return 'login';
  }
}

function humanError(code: string): string {
  const messages: Record<string, string> = {
    invalid_registration_input: 'Vérifie les informations saisies.',
    invalid_login_input: 'Saisis une adresse e-mail et un mot de passe valides.',
    invalid_email: 'Cette adresse e-mail n’est pas valide.',
    invalid_password_length: 'Choisis un mot de passe de 12 à 128 caractères.',
    email_already_registered: 'Cette adresse possède déjà un compte. Connecte-toi, demande une vérification ou récupère ton mot de passe.',
    invalid_credentials: 'Adresse e-mail ou mot de passe incorrect.',
    email_verification_required: 'Vérifie ton adresse e-mail avant de te connecter.',
    account_unavailable: 'Ce compte n’est pas disponible.',
    invalid_or_expired_token: 'Ce lien est expiré ou a déjà été utilisé.',
    invalid_action_input: 'Le lien de confirmation est invalide.',
    invalid_email_request: 'Saisis une adresse e-mail valide.',
    database_unavailable: 'La base de données locale n’est pas disponible.',
    service_unavailable: 'L’envoi des e-mails n’est pas encore configuré sur cette API.',
    google_not_configured: 'La connexion Google n’est pas encore configurée.',
    unauthorized: 'Ta session a expiré. Reconnecte-toi.',
    invalid_json: 'Réponse non valide du serveur.',
    invalid_company_input: 'Vérifie les informations de ton entreprise.',
    invalid_company_name: 'Le nom de l’entreprise doit comporter de 1 à 200 caractères.',
    company_already_exists: 'Ce compte appartient déjà à une entreprise.',
    invitation_forbidden: 'Seul le propriétaire actif peut gérer les invitations.',
    invitation_already_pending: 'Une invitation est déjà en attente pour cette adresse.',
    invitation_recently_sent: 'Une invitation vient déjà d’être envoyée. Réessaie dans un instant.',
    invitation_recipient_already_assigned: 'Cette adresse est déjà associée à une entreprise.',
    invitation_self_forbidden: 'Tu ne peux pas t’inviter toi-même.',
    invalid_invitation_email: 'Saisis une adresse e-mail valide.',
    invalid_invitation_role: 'Ce rôle ne peut pas être invité.',
    invalid_invitation: 'Ce lien d’invitation est invalide.',
    invitation_unavailable: 'Cette invitation est expirée, révoquée ou déjà utilisée, ou son entreprise est inactive.',
    invitation_wrong_account: 'Cette invitation est destinée à une autre adresse e-mail. Connecte-toi avec le bon compte.',
    invalid_catalog: 'Vérifie les champs et les montants de l’article.',
    duplicate_reference: 'Cette référence existe déjà dans ton catalogue.',
    forbidden: 'Tu ne peux pas modifier le catalogue avec ce rôle.',
  };
  return messages[code] ?? 'Une erreur est survenue. Réessaie plus tard.';
}

async function api<T>(path: string, body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, {
      method: body === undefined ? 'GET' : 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new Error('Impossible de contacter l’API. Vérifie que le serveur est démarré.');
  }
  const text = await response.text();
  let payload: ApiError & Partial<T> = {};
  if (text) {
    try { payload = JSON.parse(text) as ApiError & Partial<T>; }
    catch { throw new Error('Le serveur a retourné une réponse inattendue.'); }
  }
  if (!response.ok) throw new Error(humanError(payload.error ?? `http_${response.status}`));
  return payload as T;
}

function Button({ children, busy, disabled, variant = 'primary', type = 'submit', onClick }: ButtonProps) {
  return <button className={`btn btn-${variant}`} type={type} disabled={disabled || busy} onClick={onClick}>{busy ? 'Veuillez patienter…' : children}</button>;
}

/** Google G multicolore, purement graphique. Aucun appel Google supplémentaire. */
function GoogleMark() {
  return <span className="google-mark" aria-hidden="true">
    <svg width="24" height="24" viewBox="0 0 48 48" focusable="false">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.25 5.48-4.76 7.18l7.73 6C44.42 38.03 46.98 31.87 46.98 24.55z" />
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.46-.76-3.01-.76-4.59s.27-3.13.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24s.92 7.54 2.56 10.78l7.97-6.19z" />
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.15 1.45-4.92 2.3-8.18 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
    </svg>
  </span>;
}

function Field({ label, value, onChange, type = 'text', autoComplete, placeholder, id, minLength }: {
  label: string; value: string; onChange: (value: string) => void; type?: string; autoComplete?: string;
  placeholder?: string; id: string; minLength?: number;
}) {
  return <label className="field" htmlFor={id}>
    <span>{label}</span>
    <input id={id} required value={value} onChange={(event) => onChange(event.target.value)}
      type={type} autoComplete={autoComplete} placeholder={placeholder} minLength={minLength} />
  </label>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>(getScreen);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [checking, setChecking] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [company, setCompany] = useState<MyCompany | null>(null);
  const [companyName, setCompanyName] = useState('');
  const [companyLoading, setCompanyLoading] = useState(false);
  const [companyLoaded, setCompanyLoaded] = useState(false);
  const [members, setMembers] = useState<CompanyMember[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [invitationPreview, setInvitationPreview] = useState<{ companyName: string; role: 'MANAGER' | 'EMPLOYEE' } | null>(null);
  const pendingInvitation = () => sessionStorage.getItem(INVITE_KEY);

  const navigate = useCallback((next: Screen) => {
    if (!window.dispatchEvent(new Event('gp:before-navigation',{cancelable:true}))) return;
    window.history.pushState({}, '', next === 'login' ? '/login' : `/${next}`);
    setScreen(next);
    setError('');
    setSuccess('');
    setPassword('');
    setConfirmation('');
  }, []);

  useEffect(() => {
    const onPopState = () => { if (!window.dispatchEvent(new Event('gp:before-navigation',{cancelable:true}))) {window.history.pushState({},'',`/${screen}`);return;} setScreen(getScreen()); setError(''); setSuccess(''); };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [screen]);

  useEffect(() => {
    let active = true;
    void api<{ user: AuthUser }>('/api/v1/auth/me')
      .then((result) => {
        if (!active) return;
        setUser(result.user);
        if (getScreen() === 'login') {
          const destination = pendingInvitation() ? '/invite' : '/dashboard';
          window.history.replaceState({}, '', destination);
          setScreen(destination === '/invite' ? 'invite' : 'dashboard');
        }
      })
      .catch((reason: unknown) => {
        if (active && isWorkspacePath(window.location.pathname)) {
          setScreen('login'); window.history.replaceState({}, '', '/login');
          setError(reason instanceof Error ? reason.message : 'Impossible de vérifier ta session.');
        }
      })
      .finally(() => { if (active) setChecking(false); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (screen !== 'invite' || !user) return;
    const token = pendingInvitation();
    setInvitationPreview(null);
    if (!token) { setError('Ce lien d’invitation est absent ou invalide.'); return; }
    let active = true;
    void api<{ invitation: { companyName: string; role: 'MANAGER' | 'EMPLOYEE' } }>('/api/v1/company/invitations/preview', { token })
      .then((result) => { if (active) setInvitationPreview(result.invitation); })
      .catch((reason) => { if (active) setError(reason instanceof Error ? reason.message : 'Invitation indisponible.'); });
    return () => { active = false; };
  }, [screen, user?.id]);

  // Loads only the authenticated user's company. Other tenants are never exposed.
  useEffect(() => {
    if (!user || !isWorkspacePath(`/${screen}`)) return;
    let active = true;
    setCompanyLoading(true);
    setCompanyLoaded(false);
    void api<{ company: MyCompany | null }>('/api/v1/auth/company')
      .then((result) => { if (active) { setCompany(result.company); setCompanyLoaded(true); } })
      .catch((reason) => { if (active) setError(reason instanceof Error ? reason.message : 'Entreprise indisponible.'); })
      .finally(() => { if (active) setCompanyLoading(false); });
    return () => { active = false; };
  }, [user?.id, screen]);

  useEffect(() => {
    if (!user || !company || screen !== 'dashboard') return;
    let active = true;
    setMembersLoading(true);
    void api<{ members: CompanyMember[] }>('/api/v1/company/members')
      .then((result) => { if (active) setMembers(result.members); })
      .catch((reason) => { if (active) setError(reason instanceof Error ? reason.message : 'Collaborateurs indisponibles.'); })
      .finally(() => { if (active) setMembersLoading(false); });
    return () => { active = false; };
  }, [user?.id, company?.id, screen]);

  useEffect(() => {
    const outcome = new URLSearchParams(window.location.search).get('google');
    if (!outcome || getScreen() !== 'login') return;
    if (outcome === 'account_link_required') setError('Ce compte existe déjà. Connecte-toi avec ton mot de passe ; la liaison Google sera disponible ultérieurement.');
    else if (outcome === 'cancelled') setError('Connexion Google annulée.');
    else if (outcome === 'failed') setError('La connexion Google n’a pas abouti.');
    window.history.replaceState({}, '', '/login');
  }, []);

  async function submit(action: () => Promise<void>) {
    setBusy(true); setError(''); setSuccess('');
    try { await action(); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Une erreur est survenue.'); }
    finally { setBusy(false); }
  }

  function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void submit(async () => {
      const result = await api<{ user: AuthUser }>('/api/v1/auth/login', { email, password });
      setUser(result.user); navigate(pendingInvitation() ? 'invite' : 'dashboard');
    });
  }
  function handleRegister(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (password !== confirmation) { setError('Les deux mots de passe doivent être identiques.'); return; }
    void submit(async () => {
      await api('/api/v1/auth/register', { email, password });
      setPassword(''); setConfirmation('');
      setSuccess(pendingInvitation() ? 'Compte créé. Vérifie ton e-mail, puis reviens dans cet onglet pour te connecter et accepter l’invitation.' : 'Compte créé. Vérifie ton adresse e-mail avant de te connecter. En développement local, consulte la boîte de test.');
    });
  }
  function handleEmailRequest(event: FormEvent<HTMLFormElement>, kind: 'verification' | 'password-reset') {
    event.preventDefault();
    void submit(async () => {
      await api(`/api/v1/auth/${kind}/request`, { email });
      setSuccess('Si cette adresse remplit les conditions, un lien a été préparé pour son titulaire.');
    });
  }
  function handleVerify(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const token = new URLSearchParams(window.location.search).get('token');
    if (!token) { setError('Il manque le jeton dans le lien de vérification.'); return; }
    void submit(async () => {
      await api('/api/v1/auth/verification/confirm', { token });
      window.history.replaceState({}, '', '/verify-email');
      setSuccess('Adresse e-mail vérifiée ! Tu peux maintenant te connecter.');
    });
  }
  function handleReset(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (password !== confirmation) { setError('Les deux mots de passe doivent être identiques.'); return; }
    const token = new URLSearchParams(window.location.search).get('token');
    if (!token) { setError('Il manque le jeton dans le lien de récupération.'); return; }
    void submit(async () => {
      await api('/api/v1/auth/password-reset/confirm', { token, newPassword: password });
      setPassword(''); setConfirmation('');
      window.history.replaceState({}, '', '/reset-password');
      setSuccess('Mot de passe modifié. Tes anciennes sessions ont été révoquées. Connecte-toi à nouveau.');
    });
  }
  function handleCompanyCreate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void submit(async () => {
      const result = await api<{ company: MyCompany }>('/api/v1/auth/company', { name: companyName });
      setCompany(result.company);
      setCompanyLoaded(true);
      setCompanyName('');
      navigate('dashboard');
      setSuccess('Entreprise créée ! Tu es son propriétaire (OWNER).');
    });
  }

  function handleLogout() {
    void submit(async () => {
      let response: Response;
      try { response = await fetch('/api/v1/auth/logout', { method: 'POST', credentials: 'same-origin', cache: 'no-store' }); }
      catch { throw new Error('Impossible de contacter l’API.'); }
      if (!response.ok) throw new Error('La déconnexion n’a pas abouti. Réessaie.');
      setUser(null); setCompany(null); setMembers([]); setCompanyLoaded(false); navigate('login');
    });
  }

  function handleAcceptInvitation() {
    void submit(async () => {
      const token = pendingInvitation();
      if (!token) throw new Error('Ce lien d’invitation est absent ou invalide.');
      await api('/api/v1/company/invitations/accept', { token });
      sessionStorage.removeItem(INVITE_KEY);
      const result = await api<{ company: MyCompany | null }>('/api/v1/auth/company');
      setCompany(result.company); setCompanyLoaded(true); setMembers([]);
      navigate('dashboard');
    });
  }

  const titles: Record<Screen, [string, string]> = {
    login: ['Bienvenue sur GestionPro', 'Connecte-toi pour retrouver ton espace professionnel.'],
    register: ['Créer mon compte', 'Quelques secondes pour commencer à organiser ton activité.'],
    'verify-email': ['Vérifier mon adresse', 'Confirme l’adresse e-mail associée à ton compte.'],
    'request-verification': ['Vérifier mon adresse', 'Demande un nouveau lien pour vérifier ton adresse e-mail.'],
    'forgot-password': ['Mot de passe oublié ?', 'Nous allons préparer un lien de récupération sécurisé.'],
    'reset-password': ['Nouveau mot de passe', 'Choisis un nouveau mot de passe pour protéger ton compte.'],
    account: ['Mon espace GestionPro', 'Retrouve les informations de ton compte.'],
    dashboard: ['Mon entreprise', 'Commence par créer ton entreprise pour accéder à son tableau de bord.'],
    company: ['Mon entreprise', 'Commence par créer ton entreprise pour accéder à son tableau de bord.'],
    parties: ['Clients & fournisseurs', 'Connecte-toi pour consulter ton annuaire.'],
    catalog: ['Produits & services', 'Connecte-toi pour consulter ton catalogue.'],
    quotes: ['Devis', 'Connecte-toi pour consulter tes devis.'],
    invoices: ['Factures', 'Connecte-toi pour consulter tes factures.'],
    invite: ['Invitation à rejoindre une entreprise', 'Connecte-toi avec l’adresse à laquelle l’invitation a été envoyée.'],
  };

  if (user && company && isWorkspacePath(`/${screen}`)) {
    return <Workspace key={user.id + ':' + company.id} user={user} company={company} members={members} membersLoading={membersLoading} screen={screen as WorkspaceScreen} navigate={navigate} logout={handleLogout} busy={busy} />;
  }

  return <div className="site-shell">
    <header className="topbar">
      <button className="logo" type="button" onClick={() => navigate(user ? 'account' : 'login')} aria-label="Accueil GestionPro Maroc">
        <span className="logo-mark">G<span className="logo-dot" /></span>
        <span>GestionPro <em>Maroc</em></span>
      </button>
      <span className="local-tag"><span className="live-dot" /> Version locale · V1</span>
    </header>
    <main className="auth-layout">
      <section className="intro" aria-label="Présentation GestionPro">
        <div className="intro-glow" />
        <div className="intro-content">
          <div className="eyebrow"><span className="eyebrow-line"/> LA GESTION D'ENTREPRISE, SIMPLIFIÉE</div>
          <h1>Votre entreprise.<br/><span>Une gestion plus simple.</span></h1>
          <p>Un espace pensé pour les entrepreneurs et les petites entreprises au Maroc. Clients, ventes, documents et activité — bientôt réunis au même endroit.</p>
          <div className="features">
            <div><span className="feature-icon">✓</span> Vos données organisées</div>
            <div><span className="feature-icon">✓</span> Une interface claire et intuitive</div>
            <div><span className="feature-icon">✓</span> Conçu pour les entreprises marocaines</div>
          </div>
        </div>
        <div className="intro-bottom"><span>GESTIONPRO MAROC</span><span>Développement local sécurisé</span></div>
      </section>
      <section className="auth-side" aria-label="Authentification">
        <div className="auth-card">
          <span className="card-kicker">ESPACE UTILISATEUR</span>
          <h2>{titles[screen][0]}</h2>
          <p className="card-lead">{titles[screen][1]}</p>
          {screen === 'login' || screen === 'register' ? <div className="tab-switch" role="group" aria-label="Choix connexion ou inscription">
            <button type="button" className={screen === 'login' ? 'selected' : ''} onClick={() => navigate('login')}>Connexion</button>
            <button type="button" className={screen === 'register' ? 'selected' : ''} onClick={() => navigate('register')}>Inscription</button>
          </div> : null}
          {error ? <div className="feedback feedback-error" role="alert">{error}</div> : null}
          {success ? <div className="feedback feedback-success" role="status">{success}</div> : null}
          {checking ? <p className="loading">Vérification de la session…</p> : null}

          {screen === 'invite' && !checking && <div className="company-panel">
            {!user ? <><p>Connecte-toi ou crée un compte avec l’adresse invitée, puis vérifie ton e-mail avant d’accepter.</p><Button type="button" onClick={() => navigate('login')}>Se connecter</Button><Button type="button" variant="secondary" onClick={() => navigate('register')}>Créer un compte</Button></> : <><p>Connecté en tant que <strong>{user.email}</strong>.</p>{invitationPreview && <><h3>{invitationPreview.companyName}</h3><span className="company-role">Rôle proposé : {formatRole(invitationPreview.role)}</span><Button type="button" busy={busy} onClick={handleAcceptInvitation}>Accepter l’invitation</Button></>}<Button type="button" variant="secondary" busy={busy} onClick={handleLogout}>Changer de compte</Button></>}
          </div>}

          {screen === 'login' && <>
            <form onSubmit={handleLogin} className="auth-form">
              <Field id="login-email" label="Adresse e-mail" type="email" autoComplete="username" placeholder="vous@entreprise.ma" value={email} onChange={setEmail} />
              <Field id="login-password" label="Mot de passe" type="password" autoComplete="current-password" value={password} onChange={setPassword} />
              <button className="text-link inline-link" type="button" onClick={() => navigate('forgot-password')}>Mot de passe oublié ?</button>
              <Button busy={busy || checking}>Se connecter <span aria-hidden="true">→</span></Button>
            </form>
            <div className="or"><span>ou</span></div>
            {GOOGLE_ENABLED
              ? <button type="button" className="google-btn" onClick={() => window.location.assign('/api/v1/auth/google/start')}>
                  <GoogleMark /><span className="google-btn-label">Continuer avec Google</span>
                </button>
              : <button type="button" className="google-btn" disabled title="Connexion Google non configurée localement">
                  <GoogleMark /><span className="google-btn-label">Google · bientôt disponible</span>
                </button>}
            <p className="switch-prompt">Pas encore de compte ? <button type="button" className="text-link" onClick={() => navigate('register')}>Créer un compte</button></p>
            <p className="switch-prompt">Adresse non vérifiée ? <button type="button" className="text-link" onClick={() => navigate('request-verification')}>Demander un lien de vérification</button></p>
          </>}
          {screen === 'register' && <form onSubmit={handleRegister} className="auth-form">
            <Field id="register-email" label="Adresse e-mail professionnelle" type="email" autoComplete="email" placeholder="vous@entreprise.ma" value={email} onChange={setEmail} />
            <Field id="register-password" label="Mot de passe (12 caractères minimum)" type="password" autoComplete="new-password" minLength={12} value={password} onChange={setPassword} />
            <Field id="register-confirm" label="Confirmer le mot de passe" type="password" autoComplete="new-password" minLength={12} value={confirmation} onChange={setConfirmation} />
            <Button busy={busy}>Créer mon compte <span aria-hidden="true">→</span></Button>
            <p className="fineprint">Après l'inscription, une vérification de l'adresse e-mail est nécessaire.</p>
            <p className="fineprint">Déjà inscrit ? <button type="button" className="text-link" onClick={() => navigate('login')}>Se connecter</button> · <button type="button" className="text-link" onClick={() => navigate('request-verification')}>Vérifier mon e-mail</button> · <button type="button" className="text-link" onClick={() => navigate('forgot-password')}>Mot de passe oublié</button></p>
          </form>}
          {screen === 'request-verification' && <form onSubmit={(e) => handleEmailRequest(e, 'verification')} className="auth-form">
            <Field id="verification-email" label="Adresse e-mail de ton compte" type="email" autoComplete="email" placeholder="vous@entreprise.ma" value={email} onChange={setEmail}/>
            <Button busy={busy}>Demander le lien de vérification</Button>
            <p className="fineprint">Après vérification, reviens à l’onglet de ton invitation. Si tu as oublié ton mot de passe, demande ensuite un lien de récupération.</p>
            <button className="text-link back-link" type="button" onClick={() => navigate('login')}>← Retour à la connexion</button>
          </form>}
          {screen === 'forgot-password' && <form onSubmit={(e) => handleEmailRequest(e, 'password-reset')} className="auth-form">
            <Field id="forgot-email" label="Adresse e-mail de ton compte" type="email" autoComplete="email" placeholder="vous@entreprise.ma" value={email} onChange={setEmail}/>
            <Button busy={busy}>Demander le lien</Button>
            <button className="text-link back-link" type="button" onClick={() => navigate('login')}>← Retour à la connexion</button>
          </form>}
          {screen === 'verify-email' && <form onSubmit={handleVerify} className="auth-form">
            <p className="token-hint">Le lien de vérification reçu contient un jeton à usage unique.</p>
            <Button busy={busy}>Confirmer mon e-mail</Button>
            <button className="text-link back-link" type="button" onClick={() => navigate('login')}>← Retour à la connexion</button>
          </form>}
          {screen === 'reset-password' && <form onSubmit={handleReset} className="auth-form">
            <Field id="reset-password" label="Nouveau mot de passe" type="password" autoComplete="new-password" minLength={12} value={password} onChange={setPassword}/>
            <Field id="reset-confirm" label="Confirmer le nouveau mot de passe" type="password" autoComplete="new-password" minLength={12} value={confirmation} onChange={setConfirmation}/>
            <Button busy={busy}>Enregistrer mon nouveau mot de passe</Button>
            <button className="text-link back-link" type="button" onClick={() => navigate('login')}>← Retour à la connexion</button>
          </form>}
          {isWorkspacePath(`/${screen}`) && <div className="account-card">
            {user ? <><div className="avatar">{user.email.charAt(0).toUpperCase()}</div>
              <strong>{user.email}</strong><span className="account-status">● Compte actif</span>
              {companyLoading && <p className="loading">Chargement de ton entreprise…</p>}
              {!companyLoading && companyLoaded && company && <div className="company-panel">
                <span className="company-panel-label">MON ENTREPRISE</span>
                <h3>{company.name}</h3>
                <span className="company-role">{company.role} · {company.status === 'ACTIVE' ? 'Entreprise active' : company.status}</span>
                <p>Ton espace entreprise est créé. Les modules clients, ventes et factures seront ajoutés progressivement.</p>
              </div>}
              {!companyLoading && companyLoaded && !company && <form className="company-form" onSubmit={handleCompanyCreate}>
                <h3>Créer mon entreprise</h3>
                <p>Donne un nom à ton entreprise pour commencer. Tu deviendras automatiquement son propriétaire (OWNER).</p>
                <Field id="company-name" label="Nom de l’entreprise" placeholder="Ex. Atlas Services" value={companyName} onChange={setCompanyName} />
                <Button busy={busy}>Créer mon entreprise <span aria-hidden="true">→</span></Button>
              </form>}
              <Button type="button" variant="secondary" onClick={handleLogout} busy={busy}>Se déconnecter</Button>
            </> : <><p>Tu n'es pas connecté.</p><Button type="button" onClick={() => navigate('login')}>Se connecter</Button></>}
          </div>}
          {LOCAL_DEVELOPMENT && screen !== 'account' && <p className="dev-note">Mode développement : pour tester les e-mails, activer <code>GP_DEV_MAILBOX=1</code> sur l’API puis consulter <a href="/api/v1/auth/dev-mailbox" target="_blank" rel="noreferrer">la boîte locale</a>.</p>}
        </div>
        <p className="secure-note">🔒 Sessions sécurisées · Aucun mot de passe enregistré dans le navigateur</p>
      </section>
    </main>
    <footer className="site-footer">© GestionPro Maroc · V1 en développement · Non disponible à la vente pour le moment</footer>
  </div>;
}


/** DASH-01: read-only tenant dashboard. No commercial KPIs are invented. */
type IconName = 'grid' | 'building' | 'users' | 'package' | 'file' | 'receipt' | 'wallet' | 'settings' | 'log-out' | 'arrow-right' | 'check' | 'shield' | 'menu' | 'x' | 'mail' | 'sparkles';
function DashIcon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
    building: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M9 21v-4h6v4M8 7h2m4 0h2M8 11h2m4 0h2" /></>,
    users: <><circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 5a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5"/></>,
    package: <><path d="m12 2 9 5-9 5-9-5 9-5ZM3 7v10l9 5 9-5V7M12 12v10"/></>,
    file: <><path d="M6 2h8l5 5v14H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2ZM14 2v6h5M8 13h8M8 17h8" /></>,
    receipt: <><path d="M5 2h14v20l-3-2-4 2-4-2-3 2V2ZM8 7h8M8 11h8M8 15h5" /></>,
    wallet: <><rect x="3" y="5" width="18" height="15" rx="2"/><path d="M16 12h5M3 8V5a2 2 0 0 1 2-2h12" /></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M4.9 4.9 7 7m10 10 2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1" /></>,
    'log-out': <><path d="M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5M14 7l5 5-5 5m5-5H9"/></>,
    'arrow-right': <><path d="M5 12h14m-6-6 6 6-6 6"/></>,
    check: <><path d="m5 12 4 4L19 6"/></>,
    shield: <><path d="m12 2 9 4v6c0 5-3.5 8-9 10-5.5-2-9-5-9-10V6l9-4Zm-4 10 3 3 5-6"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    x: <><path d="M5 5 19 19M19 5 5 19"/></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/></>,
    sparkles: <><path d="m12 2 1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2ZM19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

type PartyListItem = { id: string; display_name: string; kind: 'PERSON' | 'BUSINESS'; status: string; is_client: boolean; is_supplier: boolean; city: string | null; phone: string | null; ice: string | null };
type PartyDetail = PartyListItem & { contact_name: string | null; email: string | null; phone: string | null; address: string | null; ice: string | null; postal_code: string | null; tax_id: string | null; trade_register: string | null; professional_tax: string | null };
type PartyForm = { kind: 'PERSON' | 'BUSINESS'; display_name: string; contact_name: string; is_client: boolean; is_supplier: boolean; phone: string; email: string; address: string; city: string; postal_code: string; ice: string; tax_id: string; trade_register: string; professional_tax: string };
const blankParty = (): PartyForm => ({ kind: 'PERSON', display_name: '', contact_name: '', is_client: true, is_supplier: false, phone: '', email: '', address: '', city: '', postal_code: '', ice: '', tax_id: '', trade_register: '', professional_tax: '' });
class PartyRequestError extends Error { constructor(message: string, readonly status: number) { super(message); } }
async function partyPost<T>(path: string, body: unknown, key: string, confirmation?: string): Promise<T> {
  let response: Response;
  try { response = await fetch(path, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': key, ...(confirmation ? { 'ICE-Confirmation': confirmation } : {}) }, body: JSON.stringify(body) }); }
  catch { throw new Error('Connexion interrompue. Réessayez la même opération.'); }
  const data = response.status === 204 ? {} : await response.json();
  if (!response.ok) {
    const message = data.error === 'party_conflict' ? 'Conflit ou confirmation expirée : annulez cette tentative et recommencez.'
      : data.error === 'invalid_ice' ? 'L’ICE doit comporter 15 chiffres ; seuls les espaces et tirets séparateurs sont acceptés.'
      : response.status === 400 ? 'Vérifiez les champs de la fiche, notamment le nom, le contact et les caractères saisis.'
      : data.error === 'party_forbidden' ? 'Votre rôle ne permet pas cette opération.' : humanError(data.error ?? `http_${response.status}`);
    throw new PartyRequestError(message, response.status);
  }
  return data as T;
}

function PartyDirectory({ canManage }: { canManage: boolean }) {
  const [query, setQuery] = useState('');
  const [role, setRole] = useState<'client' | 'supplier'>('client');
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [offset, setOffset] = useState(0);
  const [items, setItems] = useState<PartyListItem[]>([]);
  const [detail, setDetail] = useState<PartyDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | undefined>();
  const [form, setForm] = useState<PartyForm>(blankParty);
  const [attempt, setAttempt] = useState<{ key: string; body: PartyForm; id?: string; phase: 'prepare' | 'write'; token?: string } | null>(null);
  const [duplicates, setDuplicates] = useState<{ id: string; display_name: string; status: string }[] | null>(null);
  const [actionAttempt, setActionAttempt] = useState<{ id: string; action: 'archive' | 'reactivate'; key: string } | null>(null);
  const [message, setMessage] = useState('');
  const [audit, setAudit] = useState<{ id: string; actor_id: string | null; event_type: string; occurred_at: string }[] | null>(null);
  const [saving, setSaving] = useState(false);
  const [reload, setReload] = useState(0);
  useEffect(() => { const timer = window.setTimeout(() => { setOffset(0); setSearch(query); }, 300); return () => window.clearTimeout(timer); }, [query]);
  useEffect(() => {
    let current = true;
    setLoading(true); setError('');
    const params = new URLSearchParams({ search, role, status, limit: '26', offset: String(offset) });
    void api<{ parties: PartyListItem[] }>(`/api/v1/parties?${params}`)
      .then((result) => { if (current) setItems(result.parties); })
      .catch((reason) => { if (current) { setItems([]); setError(reason instanceof Error ? reason.message : 'Annuaire indisponible.'); } })
      .finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [search, role, status, offset, reload]);
  function openParty(id: string) {
    setError(''); setDetail(null); setLoading(true);
    void api<{ party: PartyDetail }>(`/api/v1/parties/${encodeURIComponent(id)}`)
      .then((result) => setDetail(result.party))
      .catch((reason) => setError(reason instanceof Error ? reason.message : 'Fiche indisponible.'))
      .finally(() => setLoading(false));
  }
  async function editParty(id: string) {
    setError(''); setLoading(true); setAudit(null);
    try {
      const { party } = await api<{ party: PartyDetail }>(`/api/v1/parties/${encodeURIComponent(id)}`);
      setDetail(party); setEditingId(party.id);
      setForm({ ...blankParty(), ...Object.fromEntries(Object.keys(blankParty()).map(k => [k, party[k as keyof PartyDetail] ?? ''])) } as PartyForm);
      setEditing(true); setAttempt(null); setDuplicates(null);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Fiche indisponible.'); }
    finally { setLoading(false); }
  }
  async function showAudit(id: string) {
    setError(''); setLoading(true);
    try {
      const [party, events] = await Promise.all([api<{party: PartyDetail}>(`/api/v1/parties/${id}`), api<{events: NonNullable<typeof audit>}>(`/api/v1/parties/${id}/audit`)]);
      setDetail(party.party); setAudit(events.events);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Audit indisponible.'); }
    finally { setLoading(false); }
  }
  async function save(current: NonNullable<typeof attempt>) {
    setSaving(true); setError('');
    try {
      let next = current;
      if (next.phase === 'prepare') {
        const result = await partyPost<{ confirmation: { token: string; duplicates: NonNullable<typeof duplicates> } | null }>(next.id ? `/api/v1/parties/${next.id}/ice-confirmation` : '/api/v1/parties/ice-confirmation', next.body, next.key);
        next = { ...next, phase: 'write', token: result.confirmation?.token }; setAttempt(next);
        if (result.confirmation) { setDuplicates(result.confirmation.duplicates); return; }
      }
      const result = await partyPost<{ party: PartyDetail }>(next.id ? `/api/v1/parties/${next.id}/update` : '/api/v1/parties', next.body, next.key, next.token);
      setDetail(result.party); setEditing(false); setAttempt(null); setDuplicates(null); setMessage('Fiche enregistrée.'); setOffset(0); setReload(value => value + 1);
    } catch (reason) { if (reason instanceof PartyRequestError && reason.status === 400) setAttempt(null); setError(reason instanceof Error ? reason.message : 'Enregistrement impossible.'); }
    finally { setSaving(false); }
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const current = attempt ?? { key: crypto.randomUUID(), body: { ...form, contact_name: form.kind === 'PERSON' ? '' : form.contact_name }, id: editingId, phase: 'prepare' as const };
    setAttempt(current); void save(current);
  }
  async function changeStatus(current: NonNullable<typeof actionAttempt>) {
    setActionAttempt(current); setSaving(true); setError('');
    try { await partyPost(`/api/v1/parties/${current.id}/${current.action}`, {}, current.key); setActionAttempt(null); setMessage(current.action === 'archive' ? 'Fiche archivée.' : 'Fiche réactivée.'); setReload(value => value + 1); openParty(current.id); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Opération impossible.'); }
    finally { setSaving(false); }
  }
  const locked = editing || !!actionAttempt || saving;
  const shown = items.slice(0, 25);
  const statusAction = (item: PartyListItem) => {
    const action = item.status === 'ACTIVE' ? 'archive' : 'reactivate';
    if (actionAttempt || window.confirm(action === 'archive' ? 'Archiver cette fiche ?' : 'Réactiver cette fiche ?')) void changeStatus(actionAttempt ?? { id: item.id, action, key: crypto.randomUUID() });
  };
  const fields = [['phone','Téléphone'],['email','E-mail'],['address','Adresse'],['city','Ville'],['postal_code','Code postal'],['ice','ICE'],['tax_id','Identifiant fiscal'],['trade_register','Registre de commerce'],['professional_tax','Taxe professionnelle']] as const;
  return <div className="party-directory"><div className="party-page-heading"><div><span className="dash-kicker">ANNUAIRE</span><h1>Clients & fournisseurs</h1><p>Retrouvez et gérez les contacts de votre entreprise.</p></div><button type="button" disabled={locked} className="party-button party-button-primary" onClick={() => { setDetail(null); setEditingId(undefined); setForm(blankParty()); setEditing(true); setAttempt(null); setDuplicates(null); setMessage(''); setError(''); }}>＋ Nouveau client ou fournisseur</button></div>
    {editing && <section className="party-form-card" aria-labelledby="party-form-title"><div className="party-section-heading"><div><span className="party-eyebrow">FICHE CONTACT</span><h2 id="party-form-title">{editingId ? 'Modifier la fiche' : 'Nouveau client ou fournisseur'}</h2><p>Renseignez les informations disponibles. Les champs marqués * sont obligatoires.</p></div></div>
      <form onSubmit={submit} className="party-form"><fieldset disabled={saving || !!attempt} className="party-form-fields"><legend className="party-sr-only">Informations du contact</legend>
        <div className="party-form-grid"><label><span>Type *</span><select value={form.kind} onChange={e => setForm({ ...form, kind: e.target.value as PartyForm['kind'] })}><option value="PERSON">Personne</option><option value="BUSINESS">Entreprise</option></select></label>
        <label><span>{form.kind === 'BUSINESS' ? 'Raison sociale' : 'Nom'} *</span><input required maxLength={200} value={form.display_name} onChange={e => setForm({ ...form, display_name: e.target.value })} /></label>
        {form.kind === 'BUSINESS' && <label><span>Contact principal *</span><input required maxLength={200} value={form.contact_name} onChange={e => setForm({ ...form, contact_name: e.target.value })} /></label>}
        <div className="party-role-field"><span>Rôle *</span><div className="party-checks"><label><input type="checkbox" checked={form.is_client} onChange={e => setForm({ ...form, is_client: e.target.checked })} /> Client</label><label><input type="checkbox" checked={form.is_supplier} onChange={e => setForm({ ...form, is_supplier: e.target.checked })} /> Fournisseur</label></div>{!form.is_client && !form.is_supplier && <small>Sélectionnez au moins un rôle.</small>}</div></div>
        <div className="party-form-divider"><h3>Coordonnées & informations fiscales</h3><p>Ces informations sont facultatives.</p></div>
        <div className="party-form-grid">{fields.map(([field,label]) => <label key={field} className={field === 'address' ? 'party-field-wide' : undefined}><span>{label}</span><input value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} />{field === 'ice' && <small>15 chiffres, espaces ou tirets facultatifs.</small>}</label>)}</div></fieldset>
        {error && <p className="party-feedback party-feedback-error" role="alert">{error}</p>}
        {duplicates && <div className="party-confirm" role="alert"><strong>Confirmation du doublon ICE</strong><p>Cet ICE est déjà utilisé par les fiches suivantes :</p><ul>{duplicates.map(d => <li key={d.id}><bdi>{d.display_name}</bdi> ({d.status === 'ARCHIVED' ? 'archivée' : 'active'})</li>)}</ul><button type="button" className="party-button party-button-primary" disabled={saving} onClick={() => { setDuplicates(null); if (attempt) void save(attempt); }}>Confirmer le doublon ICE</button></div>}
        <div className="party-form-actions"><button type="button" className="party-button party-button-secondary" disabled={saving} onClick={() => { setEditing(false); setAttempt(null); setDuplicates(null); setError(''); }}>Annuler</button>{!duplicates && <button className="party-button party-button-primary" disabled={saving || (!form.is_client && !form.is_supplier)}>{saving ? 'Enregistrement…' : attempt ? 'Réessayer' : 'Enregistrer'}</button>}</div>
      </form></section>}
    <section className="party-list-card" aria-label="Annuaire des contacts"><div className="party-tabs" role="tablist" aria-label="Type de contact">{([['client','Clients'],['supplier','Fournisseurs']] as const).map(([value,label]) => <button key={value} type="button" role="tab" aria-selected={role === value} className={role === value ? 'is-selected' : ''} onClick={() => { setRole(value); setOffset(0); setDetail(null); setAudit(null); }}>{label}</button>)}</div>
      <div className="party-toolbar"><label className="party-search"><span>Recherche par nom</span><input placeholder="Rechercher un nom…" value={query} maxLength={200} onChange={e => setQuery(e.target.value)} /></label><label className="party-status-filter"><span>Statut</span><select value={status} onChange={e => { setStatus(e.target.value); setOffset(0); }}><option value="all">Tous les statuts</option><option value="ACTIVE">Actifs</option><option value="ARCHIVED">Archivés</option></select></label><a className="party-button party-button-secondary party-export" href={`/api/v1/parties/export.csv?${new URLSearchParams({ search, role, status })}`}>Exporter CSV</a></div>
      {!editing && error && <p className="party-feedback party-feedback-error" role="alert">{error}</p>}{message && <p className="party-feedback party-feedback-success" role="status">{message}</p>}{loading && <p className="party-list-state" role="status">Chargement des fiches…</p>}
      {!loading && !error && shown.length === 0 && <div className="party-empty"><strong>Aucune fiche trouvée</strong><p>Modifiez vos filtres ou ajoutez un contact.</p></div>}
      {shown.length > 0 && <div className="party-table-wrap"><table className="party-table"><thead><tr><th>Nom / Raison sociale</th><th>Type</th><th>Ville</th><th>Téléphone</th><th>ICE</th><th>Statut</th><th>Actions</th></tr></thead><tbody>{shown.map(item => <tr key={item.id}><td data-label="Nom / Raison sociale"><strong><bdi>{item.display_name}</bdi></strong><span className="party-roles">{item.is_client && item.is_supplier ? 'Client · Fournisseur' : item.is_client ? 'Client' : 'Fournisseur'}</span></td><td data-label="Type">{item.kind === 'BUSINESS' ? 'Entreprise' : 'Personne'}</td><td data-label="Ville">{item.city || '—'}</td><td data-label="Téléphone"><bdi>{item.phone || '—'}</bdi></td><td data-label="ICE"><bdi>{item.ice || '—'}</bdi></td><td data-label="Statut"><span className={`party-badge ${item.status === 'ACTIVE' ? 'is-active' : 'is-archived'}`}>{item.status === 'ACTIVE' ? 'Actif' : 'Archivé'}</span></td><td data-label="Actions"><div className="party-row-actions"><button type="button" disabled={locked || loading} onClick={() => { setAudit(null); openParty(item.id); }}>Voir</button><button type="button" disabled={locked || loading} onClick={() => void editParty(item.id)}>Modifier</button>{(item.status === 'ACTIVE' || canManage) && <button type="button" disabled={editing || saving || loading || (!!actionAttempt && actionAttempt.id !== item.id)} onClick={() => statusAction(item)}>{actionAttempt?.id === item.id ? 'Réessayer' : item.status === 'ACTIVE' ? 'Archiver' : 'Réactiver'}</button>}{canManage && <button type="button" disabled={locked || loading} onClick={() => void showAudit(item.id)}>Audit</button>}</div></td></tr>)}</tbody></table></div>}
      <div className="party-pagination"><span>Page {Math.floor(offset / 25) + 1}</span><div><button type="button" className="party-button party-button-secondary" disabled={offset === 0 || loading} onClick={() => setOffset(Math.max(0, offset - 25))}>Précédent</button><button type="button" className="party-button party-button-secondary" disabled={items.length <= 25 || loading} onClick={() => setOffset(offset + 25)}>Suivant</button></div></div>
    </section>
    {detail && !editing && <section className="party-detail" aria-label="Fiche du tiers"><div className="party-section-heading"><div><span className="party-eyebrow">FICHE CONTACT</span><h2><bdi>{detail.display_name}</bdi></h2><p>{detail.kind === 'BUSINESS' ? 'Entreprise' : 'Personne'} · {detail.status === 'ACTIVE' ? 'Actif' : 'Archivé'}</p></div><button type="button" className="party-button party-button-secondary" onClick={() => { setDetail(null); setAudit(null); }}>Fermer</button></div><dl className="party-detail-grid">{([['contact_name','Contact principal'],['email','E-mail'],['phone','Téléphone'],['address','Adresse'],['city','Ville'],['postal_code','Code postal'],['ice','ICE'],['tax_id','Identifiant fiscal'],['trade_register','Registre de commerce'],['professional_tax','Taxe professionnelle']] as const).map(([field,label]) => detail[field] && <div key={field}><dt>{label}</dt><dd><bdi>{detail[field]}</bdi></dd></div>)}</dl>{audit && <div className="party-audit"><h3>Historique de la fiche</h3>{audit.length ? <ul>{audit.map(e => <li key={e.id}>{({PARTY_CREATED:'Création',PARTY_UPDATED:'Modification',PARTY_ARCHIVED:'Archivage',PARTY_REACTIVATED:'Réactivation'} as Record<string,string>)[e.event_type] ?? e.event_type} · {new Date(e.occurred_at).toLocaleString('fr-MA')} · Auteur : {e.actor_id ?? 'indisponible'}</li>)}</ul> : <p>Aucun événement.</p>}</div>}</section>}
  </div>;
}

function RecentParties({ navigate }: { navigate: () => void }) {
  const [clients, setClients] = useState<PartyListItem[]>([]);
  const [suppliers, setSuppliers] = useState<PartyListItem[]>([]);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  useEffect(() => {
    let live = true;
    void Promise.all(['client', 'supplier'].map(role => api<{parties: PartyListItem[]}>(`/api/v1/parties?role=${role}&limit=5`)))
      .then(([a, b]) => { if (live) { setClients(a!.parties); setSuppliers(b!.parties); setState('ready'); } })
      .catch(() => { if (live) setState('error'); });
    return () => { live = false; };
  }, []);
  return <div className="dash-lower-grid">{([["Clients récents", clients], ["Fournisseurs récents", suppliers]] as const).map(([title, items]) => <section className="dash-info-card" key={title}><span className="dash-kicker">ANNUAIRE</span><h2>{title}</h2>{state === 'loading' ? <p>Chargement…</p> : state === 'error' ? <p role="alert">Impossible de charger l’annuaire.</p> : items.length ? <div className="dash-members-list">{items.map(item => <div className="dash-member-row" key={item.id}><div><strong>{item.display_name}</strong><span>{item.status === 'ACTIVE' ? 'Actif' : 'Archivé'}{item.city ? ` · ${item.city}` : ''}</span></div></div>)}</div> : <p>Aucune fiche pour le moment.</p>}<button type="button" className="dash-light-button" onClick={navigate}>Ouvrir l’annuaire</button></section>)}</div>;
}

function Workspace({ user, company, members, membersLoading, screen, navigate, logout, busy }: {
  user: AuthUser; company: MyCompany; screen: WorkspaceScreen;
  members: CompanyMember[]; membersLoading: boolean;
  navigate: (screen: Screen) => void; logout: () => void; busy: boolean;
}) {
  const [identity, setIdentity] = useState<CompanyIdentity | null>(null);
  const [identityError, setIdentityError] = useState('');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoVersion, setLogoVersion] = useState(0);
  const [invoiceTarget, setInvoiceTarget] = useState<string | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    setIdentity(null); setIdentityError('');
    void identityRequest<CompanyIdentity>('/api/v1/company/document-identity', {signal: controller.signal})
      .then(result => { if (!controller.signal.aborted) setIdentity(result); })
      .catch(() => { if (!controller.signal.aborted) setIdentityError('Identité de l’entreprise indisponible.'); });
    return () => controller.abort();
  }, [company.id, user.id]);
  useEffect(() => {
    setLogoUrl(null);
    if (!identity?.hasLogo) return;
    const controller = new AbortController();
    let objectUrl: string | null = null;
    void fetch('/api/v1/company/document-identity/logo', {credentials:'same-origin', cache:'no-store', signal:controller.signal})
      .then(response => { if (!response.ok) throw new Error('Logo indisponible'); return response.blob(); })
      .then(blob => { if (!controller.signal.aborted) { objectUrl = URL.createObjectURL(blob); setLogoUrl(objectUrl); } })
      .catch(() => { if (!controller.signal.aborted) setLogoUrl(null); });
    return () => { controller.abort(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [company.id, user.id, identity?.hasLogo, logoVersion]);
  const palette = identity?.palettes[identity.palette];
  const theme = palette ? {'--company-primary':palette.primary, '--company-accent':palette.accent, '--company-secondary':palette.light} as CSSProperties : undefined;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [managementOpen, setManagementOpen] = useState(screen === 'parties' || screen === 'catalog' || screen === 'quotes' || screen === 'invoices');
  useEffect(() => { if (screen === 'parties' || screen === 'catalog' || screen === 'quotes' || screen === 'invoices') setManagementOpen(true); }, [screen]);
  const [invitations, setInvitations] = useState<CompanyInvitation[]>([]);
  const [invitationsLoading, setInvitationsLoading] = useState(false);
  const [invitationEmail, setInvitationEmail] = useState('');
  const [invitationRole, setInvitationRole] = useState<'MANAGER' | 'EMPLOYEE'>('EMPLOYEE');
  const [invitationBusy, setInvitationBusy] = useState(false);
  const [invitationMessage, setInvitationMessage] = useState('');
  const [invitationError, setInvitationError] = useState('');
  const current = screen;
  const go = (to: WorkspaceScreen) => { setMobileMenuOpen(false); if (to === 'invoices') setInvoiceTarget(null); navigate(to); };
  const active = company.status === 'ACTIVE';
  const canInvite = company.role === 'OWNER' && active;
  const moduleIcons: Record<(typeof UPCOMING_MODULES)[number]['icon'], IconName> = {
    users: 'users', package: 'package', file: 'file', receipt: 'receipt', wallet: 'wallet',
  };
  const loadInvitations = useCallback(() => {
    if (!canInvite || screen !== 'dashboard') return;
    setInvitationsLoading(true);
    void api<{ invitations: CompanyInvitation[] }>('/api/v1/company/invitations')
      .then((result) => setInvitations(result.invitations))
      .catch((reason) => setInvitationError(reason instanceof Error ? reason.message : 'Invitations indisponibles.'))
      .finally(() => setInvitationsLoading(false));
  }, [canInvite, screen]);
  useEffect(() => { loadInvitations(); }, [loadInvitations]);
  function inviteMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setInvitationBusy(true); setInvitationError(''); setInvitationMessage('');
    void api('/api/v1/company/invitations', { email: invitationEmail, role: invitationRole })
      .then(() => { setInvitationEmail(''); setInvitationMessage('Invitation préparée et envoyée.'); loadInvitations(); })
      .catch((reason) => setInvitationError(reason instanceof Error ? reason.message : 'Invitation impossible.'))
      .finally(() => setInvitationBusy(false));
  }
  function revokeInvitation(id: string) {
    setInvitationBusy(true); setInvitationError(''); setInvitationMessage('');
    void api(`/api/v1/company/invitations/${id}/revoke`, {})
      .then(() => { setInvitationMessage('Invitation révoquée.'); loadInvitations(); })
      .catch((reason) => setInvitationError(reason instanceof Error ? reason.message : 'Révocation impossible.'))
      .finally(() => setInvitationBusy(false));
  }
  return <div className="dash-app" style={theme}>
    <aside className={`dash-sidebar ${mobileMenuOpen ? 'dash-sidebar-open' : ''}`} aria-label="Navigation GestionPro">
      <div className="dash-brand">
        <span className="dash-brand-company-logo">{logoUrl ? <img src={logoUrl} alt="" /> : <DashIcon name="building" size={24}/>}</span>
        <div className="dash-brand-company"><strong title={company.name}>{company.name}</strong><small>PAR GESTIONPRO MAROC</small></div>
        <button type="button" className="dash-menu-close" onClick={() => setMobileMenuOpen(false)} aria-label="Fermer le menu"><DashIcon name="x" /></button>
      </div>
      <div className="dash-tenant">
        <div><strong>Espace de travail</strong><span>{formatRole(company.role)}</span></div>
        <span className="dash-tenant-dot" title={statusLabel(company.status)}/>
      </div>
      <nav className="dash-menu">
        <span className="dash-menu-heading">ESPACE DE TRAVAIL</span>
        <button type="button" className={`dash-nav-item ${current === 'dashboard' ? 'is-current' : ''}`} aria-current={current === 'dashboard' ? 'page' : undefined} onClick={() => go('dashboard')}><DashIcon name="grid" />Vue globale</button>
        <button type="button" className={`dash-nav-item ${current === 'company' ? 'is-current' : ''}`} aria-current={current === 'company' ? 'page' : undefined} onClick={() => go('company')}><DashIcon name="building" />Mon entreprise</button>
        <button type="button" className={`dash-nav-item dash-management-toggle ${current === 'parties' ? 'has-current' : ''}`} aria-expanded={managementOpen} aria-controls="management-menu" onClick={() => setManagementOpen((open) => !open)}><DashIcon name="package" />Gestion <span aria-hidden="true" className="dash-management-arrow">{managementOpen ? '▾' : '▸'}</span></button>
        <div id="management-menu" className="dash-management-menu" hidden={!managementOpen}>
          {MANAGEMENT_MODULES.map((module) => module.screen ? <button key={module.id} type="button" className={`dash-nav-item ${screen === module.screen ? 'is-current' : ''}`} aria-current={screen === module.screen ? 'page' : undefined} onClick={() => go(module.screen!)}>{module.title}</button> : <div key={module.id} className="dash-nav-item dash-nav-soon">{module.title}<span className="dash-mini-soon">À venir</span></div>)}
        </div>
        <span className="dash-menu-heading dash-menu-heading-spaced">PARAMÈTRES</span>
        <button type="button" className={`dash-nav-item ${current === 'account' ? 'is-current' : ''}`} aria-current={current === 'account' ? 'page' : undefined} onClick={() => go('account')}><DashIcon name="settings" />Mon compte</button>
      </nav>
      <div className="dash-sidebar-bottom"><span className="dash-version">Version locale · V1</span><button type="button" className="dash-logout" disabled={busy} onClick={logout}><DashIcon name="log-out"/>Se déconnecter</button></div>
    </aside>
    {mobileMenuOpen && <button type="button" className="dash-backdrop" aria-label="Fermer la navigation" onClick={() => setMobileMenuOpen(false)} />}
    <div className="dash-content">
      <header className="dash-topbar">
        <div className="dash-topbar-left"><button type="button" className="dash-menu-toggle" onClick={() => setMobileMenuOpen(true)} aria-label="Ouvrir le menu"><DashIcon name="menu" /></button><span className="dash-breadcrumb">GestionPro Maroc <span>/</span> {current === 'dashboard' ? 'Tableau de bord' : current === 'company' ? 'Mon entreprise' : current === 'parties' ? 'Clients & fournisseurs' : current === 'catalog' ? 'Produits & services' : current === 'quotes' ? 'Devis' : current === 'invoices' ? 'Factures' : 'Mon compte'}</span></div>
        <div className="dash-topbar-right"><div className="dash-company-header"><span className="dash-company-logo">{logoUrl ? <img src={logoUrl} alt="" /> : <DashIcon name="building" size={20}/>}</span><strong title={company.name}>{company.name}</strong></div><span className="dash-local-status"><span /> Environnement local</span><button type="button" className="dash-user-pill" onClick={() => go('account')} title="Ouvrir mon compte" aria-label="Ouvrir mon compte"><span>{user.email.charAt(0).toUpperCase()}</span><strong>{user.email}</strong></button></div>
      </header>
      <main className="dash-main">
        {current === 'parties' && <PartyDirectory canManage={company.role !== 'EMPLOYEE'} />}
        {current === 'catalog' && <Catalog canManage={company.role !== 'EMPLOYEE'} />}
        {current === 'quotes' && <Quotes scope={user.id + ':' + company.id} onOpenInvoice={(id) => {setInvoiceTarget(id); setMobileMenuOpen(false); navigate('invoices');}} />}
        {current === 'invoices' && <Invoices key={invoiceTarget ?? 'list'} initialInvoiceId={invoiceTarget} />}
        {current === 'dashboard' && <>
          <div className="dash-title-row"><div><span className="dash-kicker">TABLEAU DE BORD</span><h1>Bonjour, bienvenue chez {company.name} <span aria-hidden="true">👋</span></h1><p>Un espace clair pour piloter ton entreprise. Les modules seront activés au fil du développement.</p></div><span className={`dash-status-badge ${active ? 'is-active' : ''}`}><span />{statusLabel(company.status)}</span></div>
          <section className="dash-welcome" aria-label="Bienvenue dans ton entreprise"><div><span className="dash-welcome-kicker"><DashIcon name="sparkles" size={16}/> TON ESPACE EST PRÊT</span><h2>Une meilleure vue sur ton activité commence ici.</h2><p>Ton entreprise est enregistrée. Nous allons construire tes outils de gestion, un module à la fois.</p><button type="button" className="dash-welcome-link" onClick={() => go('company')}>Consulter mon entreprise <DashIcon name="arrow-right" size={18}/></button></div><div className="dash-welcome-art" aria-hidden="true"><div className="dash-welcome-art-icon"><DashIcon name="building" size={58}/></div></div></section>
          <section className="dash-stat-grid" aria-label="État réel de ton espace">
            <div className="dash-stat-card"><span className="dash-stat-icon"><DashIcon name="building" /></span><span className="dash-stat-label">Entreprises liées</span><strong>1</strong><small>Une société par compte</small></div>
            <div className="dash-stat-card"><span className="dash-stat-icon"><DashIcon name="shield" /></span><span className="dash-stat-label">Ton rôle</span><strong>{company.role}</strong><small>{formatRole(company.role)} de l’entreprise</small></div>
            <div className="dash-stat-card"><span className="dash-stat-icon"><DashIcon name="check" /></span><span className="dash-stat-label">Statut de la société</span><strong>{active ? 'Active' : 'En cours'}</strong><small>{statusLabel(company.status)}</small></div>
          </section>
          <RecentParties navigate={() => go('parties')} />
          <div className="dash-section-heading"><div><span className="dash-kicker">À CONSTRUIRE ENSEMBLE</span><h2>Modules de gestion</h2><p>Ces fonctionnalités sont prévues, mais ne sont pas encore utilisables.</p></div><span className="dash-outline-badge">Feuille de route V1</span></div>
          <section className="dash-module-grid" aria-label="Modules bientôt disponibles">
            {UPCOMING_MODULES.filter((module) => module.id !== 'clients' && module.id !== 'catalogue').map((module) => <article key={module.id} className="dash-module-card"><div className="dash-module-top"><span className="dash-module-icon"><DashIcon name={moduleIcons[module.icon]} size={23}/></span><span className="dash-upcoming-label">À venir</span></div><h3>{module.title}</h3><p>{module.description}</p></article>)}
          </section>
          <section className="dash-members-card" aria-labelledby="members-title"><div className="dash-members-heading"><div><span className="dash-kicker">COLLABORATEURS</span><h2 id="members-title">Membres de l’entreprise</h2><p>Liste issue de votre entreprise uniquement.</p></div><span className="dash-outline-badge">{membersLoading ? 'Chargement…' : `${members.length} membre${members.length > 1 ? 's' : ''}`}</span></div>{membersLoading ? <p className="dash-members-empty">Chargement des collaborateurs…</p> : members.length === 0 ? <p className="dash-members-empty">Aucun collaborateur actif ou désactivé à afficher.</p> : <div className="dash-members-list">{members.map((member) => <article key={member.id} className="dash-member-row"><span className="dash-member-avatar">{member.email.charAt(0).toUpperCase()}</span><div><strong>{member.email}</strong><span>{formatRole(member.role)} · {member.status === 'ACTIVE' ? 'Actif' : 'Désactivé'}</span></div><time dateTime={member.joinedAt}>Membre depuis {new Intl.DateTimeFormat('fr-MA', { dateStyle: 'medium' }).format(new Date(member.joinedAt))}</time></article>)}</div>}</section>
          {canInvite && <section className="dash-invitations-card" aria-labelledby="invitations-title"><div><span className="dash-kicker">INVITATIONS</span><h2 id="invitations-title">Inviter un collaborateur</h2><p>Une invitation expire après 7 jours. Aucun accès n’est créé avant son acceptation.</p></div>{invitationError && <p className="dash-invitation-error" role="alert">{invitationError}</p>}{invitationMessage && <p className="dash-invitation-success" role="status">{invitationMessage}</p>}<form className="dash-invitation-form" onSubmit={inviteMember}><label><span>Adresse e-mail</span><input required type="email" autoComplete="email" placeholder="collaborateur@entreprise.ma" value={invitationEmail} onChange={(event) => setInvitationEmail(event.target.value)} /></label><label><span>Rôle proposé</span><select value={invitationRole} onChange={(event) => setInvitationRole(event.target.value as 'MANAGER' | 'EMPLOYEE')}><option value="EMPLOYEE">Collaborateur</option><option value="MANAGER">Gestionnaire</option></select></label><button className="dash-invite-button" disabled={invitationBusy}>{invitationBusy ? 'Traitement…' : 'Envoyer l’invitation'}</button></form><div className="dash-pending-invitations"><h3>Invitations en attente</h3>{invitationsLoading ? <p>Chargement…</p> : invitations.filter((invitation) => invitation.status === 'PENDING').length === 0 ? <p>Aucune invitation en attente.</p> : invitations.filter((invitation) => invitation.status === 'PENDING').map((invitation) => <article key={invitation.id}><div><strong>{invitation.email}</strong><span>{formatRole(invitation.proposedRole)} · expire le {new Intl.DateTimeFormat('fr-MA', { dateStyle: 'medium' }).format(new Date(invitation.expiresAt))}</span></div><button type="button" disabled={invitationBusy} onClick={() => revokeInvitation(invitation.id)}>Révoquer</button></article>)}</div></section>}
          <div className="dash-lower-grid"><section className="dash-info-card"><span className="dash-kicker">PROCHAINES ÉTAPES</span><h2>Les fondations sont posées</h2><div className="dash-check-row"><span><DashIcon name="check" size={16}/></span>Compte utilisateur actif</div><div className="dash-check-row"><span><DashIcon name="check" size={16}/></span>Entreprise créée et associée</div><div className="dash-check-row"><span><DashIcon name="check" size={16}/></span>Rôle attribué : {company.role}</div><div className="dash-next-step">Prochaine brique : annuaire clients et fournisseurs.</div></section><section className="dash-info-card dash-info-muted"><span className="dash-kicker">ACTIVITÉ</span><h2>Historique métier</h2><div className="dash-empty-illustration"><DashIcon name="file" size={28}/></div><p>Les opérations commerciales apparaîtront ici lorsque leurs modules seront disponibles. Aucun chiffre fictif n’est affiché.</p></section></div>
        </>}
        {current === 'company' && <><div className="dash-title-row"><div><span className="dash-kicker">FICHE ENTREPRISE</span><h1>Mon entreprise</h1><p>Ces informations proviennent de PostgreSQL, via ta session.</p></div><span className={`dash-status-badge ${active ? 'is-active' : ''}`}><span />{statusLabel(company.status)}</span></div><section className="dash-detail-card"><span className="dash-detail-icon"><DashIcon name="building" size={32}/></span><h2>{company.name}</h2><div className="dash-detail-grid"><div><span>Nom de l’entreprise</span><strong>{company.name}</strong></div><div><span>Statut</span><strong>{statusLabel(company.status)}</strong></div><div><span>Rôle du compte</span><strong>{company.role} — {formatRole(company.role)}</strong></div><div><span>Identifiant de l’entreprise</span><code>{company.id}</code></div></div><p className="dash-detail-hint">Les coordonnées légales et la modification des informations de l’entreprise seront ajoutées dans les prochaines briques.</p><button type="button" className="dash-light-button" onClick={() => go('dashboard')}>← Retour au tableau de bord</button></section>{identity ? <CompanyIdentityPanel companyName={company.name} identity={identity} logoUrl={logoUrl} onIdentity={(next, changed) => {setIdentity(next); if (changed) setLogoVersion(v => v + 1);}}/> : <p role={identityError ? "alert" : "status"}>{identityError || "Chargement de l’identité…"}</p>}</>}
        {current === 'account' && <><div className="dash-title-row"><div><span className="dash-kicker">MON PROFIL</span><h1>Mon compte</h1><p>Identité associée à ta session active.</p></div></div><section className="dash-detail-card"><span className="dash-account-avatar">{user.email.charAt(0).toUpperCase()}</span><h2>{user.email}</h2><div className="dash-detail-grid"><div><span>Adresse e-mail</span><strong>{user.email}</strong></div><div><span>État du compte</span><strong>Actif</strong></div><div><span>Entreprise</span><strong>{company.name}</strong></div><div><span>Rôle</span><strong>{company.role}</strong></div></div><div className="dash-action-row"><button type="button" className="dash-light-button" onClick={() => go('dashboard')}>← Tableau de bord</button><button type="button" className="dash-light-button" onClick={logout} disabled={busy}>Se déconnecter</button></div></section></>}
      </main>
      <footer className="dash-footer">GestionPro Maroc V1 · Environnement de développement local · Données métier non encore disponibles</footer>
    </div>
  </div>;
}
