import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import type { AuthQueryDatabase, PublicAuthUser } from './login-service.js';
import { digestSessionToken, SESSION_DURATION_SECONDS, sessionCookie } from './login-service.js';
import type { RegistrationDatabase, RegistrationClient } from './registration-service.js';

export const GOOGLE_STATE_COOKIE = 'gp_google_state';
const FLOW_TTL_SECONDS = 10 * 60;
const GOOGLE_AUTHORIZATION_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;

export interface GoogleOidcConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  webOrigin: string;
}

export interface VerifiedGoogleIdentity {
  sub: string;
  email: string;
  emailVerified: boolean;
  hostedDomain?: string;
}

export interface GoogleCodeExchange {
  exchange(input: { code: string; codeVerifier: string; nonce: string; config: GoogleOidcConfig }): Promise<VerifiedGoogleIdentity>;
}

export interface GoogleDatabase extends RegistrationDatabase, AuthQueryDatabase {}

export class GoogleIdentityConflictError extends Error {
  constructor() { super('google_account_link_required'); }
}
export class InvalidGoogleIdentityError extends Error {
  constructor() { super('invalid_google_identity'); }
}

export function digestGoogleState(state: string): string {
  return createHash('sha256').update(state).digest('hex');
}

export function googleStateCookie(state: string, secure: boolean): string {
  return `${GOOGLE_STATE_COOKIE}=${state}; Path=/api/v1/auth/google; HttpOnly; SameSite=Lax; Max-Age=${FLOW_TTL_SECONDS}${secure ? '; Secure' : ''}`;
}
export function expiredGoogleStateCookie(secure: boolean): string {
  return `${GOOGLE_STATE_COOKIE}=; Path=/api/v1/auth/google; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;
}

export function parseGoogleStateCookie(cookieHeader: string | undefined): string | null {
  if (!cookieHeader) return null;
  const matches = cookieHeader.split(';').map((entry) => entry.trim())
    .filter((entry) => entry.startsWith(`${GOOGLE_STATE_COOKIE}=`));
  if (matches.length !== 1) return null;
  const state = matches[0]!.slice(GOOGLE_STATE_COOKIE.length + 1);
  return TOKEN_PATTERN.test(state) ? state : null;
}

export function statesMatch(a: string, b: string): boolean {
  if (!TOKEN_PATTERN.test(a) || !TOKEN_PATTERN.test(b)) return false;
  const first = Buffer.from(a, 'utf8');
  const second = Buffer.from(b, 'utf8');
  return first.length === second.length && timingSafeEqual(first, second);
}

function isLoopback(url: URL): boolean {
  return ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
}

export function assertGoogleConfig(config: GoogleOidcConfig): void {
  if (!config.clientId.endsWith('.apps.googleusercontent.com') ||
      config.clientId.length < 30 || config.clientId.length > 300 ||
      config.clientSecret.length < 8 || config.clientSecret.length > 1024) {
    throw new Error('invalid_google_configuration');
  }
  const redirect = new URL(config.redirectUri);
  const web = new URL(config.webOrigin);
  if ((redirect.protocol !== 'https:' && !(redirect.protocol === 'http:' && isLoopback(redirect))) ||
      redirect.pathname !== '/api/v1/auth/google/callback' ||
      redirect.search !== '' || redirect.hash !== '' ||
      (web.protocol !== 'https:' && !(web.protocol === 'http:' && isLoopback(web))) ||
      web.pathname !== '/' || web.search !== '' || web.hash !== '') {
    throw new Error('invalid_google_configuration');
  }
}

export async function startGoogleLogin(database: GoogleDatabase, config: GoogleOidcConfig): Promise<{ redirectTo: string; state: string }> {
  assertGoogleConfig(config);
  const state = randomBytes(32).toString('base64url');
  const nonce = randomBytes(32).toString('base64url');
  const codeVerifier = randomBytes(32).toString('base64url');
  const challenge = createHash('sha256').update(codeVerifier).digest('base64url');
  await database.query(
    `INSERT INTO public.google_oidc_flows (state_hash, nonce, code_verifier, expires_at)
      VALUES ($1, $2, $3, now() + ($4::integer * interval '1 second'))`,
    [digestGoogleState(state), nonce, codeVerifier, FLOW_TTL_SECONDS]
  );
  const url = new URL(GOOGLE_AUTHORIZATION_URL);
  for (const [key, value] of Object.entries({
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    response_type: 'code',
    scope: 'openid email',
    state,
    nonce,
    code_challenge: challenge,
    code_challenge_method: 'S256'
  })) url.searchParams.set(key, value);
  return { redirectTo: url.toString(), state };
}

export interface ConsumedGoogleFlow { nonce: string; codeVerifier: string }

/** Atomically consumes the state ONCE, also on a provider-side failure. */
export async function consumeGoogleFlow(database: GoogleDatabase, state: string): Promise<ConsumedGoogleFlow | null> {
  const result = await database.query(
    `UPDATE public.google_oidc_flows SET consumed_at = now()
      WHERE state_hash = $1 AND consumed_at IS NULL AND expires_at > now()
      RETURNING nonce, code_verifier`,
    [digestGoogleState(state)]
  );
  const row = result.rows[0] as { nonce?: unknown; code_verifier?: unknown } | undefined;
  if (typeof row?.nonce !== 'string' || typeof row.code_verifier !== 'string') return null;
  return { nonce: row.nonce, codeVerifier: row.code_verifier };
}

export function normalizeVerifiedGoogleIdentity(identity: VerifiedGoogleIdentity): { sub: string; email: string } {
  if (typeof identity.sub !== 'string' || identity.sub.length < 1 || identity.sub.length > 255 ||
      typeof identity.email !== 'string' || identity.emailVerified !== true) {
    throw new InvalidGoogleIdentityError();
  }
  const email = identity.email.trim().toLowerCase();
  if (email.length < 3 || email.length > 320 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    throw new InvalidGoogleIdentityError();
  }
  // A verified third-party email might have changed hands. Google is authoritative
  // for @gmail.com or a Google Workspace account with a signed hd claim.
  if (!email.endsWith('@gmail.com') &&
      (typeof identity.hostedDomain !== 'string' || identity.hostedDomain.length === 0)) {
    throw new InvalidGoogleIdentityError();
  }
  return { sub: identity.sub, email };
}

async function transact<T>(db: GoogleDatabase, callback: (client: RegistrationClient) => Promise<T>): Promise<T> {
  const client = await db.connect();
  let open = false;
  try {
    await client.query('BEGIN');
    open = true;
    const result = await callback(client);
    await client.query('COMMIT');
    open = false;
    return result;
  } catch (error) {
    if (open) await client.query('ROLLBACK').catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

interface GoogleAuthRow { id: string; email: string; status: string; email_verified_at: Date | null }

/** Never auto-link to an existing password account solely on email equality. */
export async function completeGoogleLogin(
  database: GoogleDatabase,
  identity: VerifiedGoogleIdentity
): Promise<{ user: PublicAuthUser; sessionToken: string }> {
  const { sub, email } = normalizeVerifiedGoogleIdentity(identity);
  return transact(database, async (client) => {
    const known = await client.query(
      `SELECT u.id, u.email, u.status, u.email_verified_at
         FROM public.google_identities g
         JOIN public.users u ON u.id = g.user_id
        WHERE g.google_sub = $1
        FOR UPDATE OF g, u`, [sub]
    );
    let user = known.rows[0] as GoogleAuthRow | undefined;
    if (!user) {
      const sameEmail = await client.query('SELECT id FROM public.users WHERE email = $1 FOR UPDATE', [email]);
      if (sameEmail.rows.length > 0) throw new GoogleIdentityConflictError();
      const created = await client.query(
        `INSERT INTO public.users (email, status, email_verified_at)
          VALUES ($1, 'ACTIVE', now()) RETURNING id, email, status, email_verified_at`, [email]
      );
      user = created.rows[0] as GoogleAuthRow | undefined;
      if (!user) throw new Error('invalid_google_database_result');
      await client.query('INSERT INTO public.google_identities (google_sub, user_id) VALUES ($1, $2)', [sub, user.id]);
    }
    if (user.status !== 'ACTIVE' || user.email_verified_at === null) {
      throw new InvalidGoogleIdentityError();
    }
    const sessionToken = randomBytes(32).toString('base64url');
    await client.query(
      `INSERT INTO public.auth_sessions (token_hash, user_id, expires_at)
       VALUES ($1, $2, now() + ($3::integer * interval '1 second'))`,
      [digestSessionToken(sessionToken), user.id, SESSION_DURATION_SECONDS]
    );
    return { user: { id: user.id, email: user.email, status: 'ACTIVE' as const }, sessionToken };
  }).catch((error: unknown) => {
    if (error instanceof GoogleIdentityConflictError || error instanceof InvalidGoogleIdentityError) throw error;
    // A concurrent enrollment/Google identity insertion must fail closed, not return SQL details.
    if (error && typeof error === 'object' && 'code' in error && (error as {code?: unknown}).code === '23505') {
      throw new GoogleIdentityConflictError();
    }
    throw error;
  });
}

export function safeGoogleOutcomeUrl(config: GoogleOidcConfig, outcome: 'success'|'failed'|'cancelled'|'account_link_required'): string {
  const url = new URL('/login', config.webOrigin);
  url.searchParams.set('google', outcome);
  return url.toString();
}

export function validAuthorizationCode(code: unknown): code is string {
  return typeof code === 'string' && code.length >= 1 && code.length <= 4096 && !/[\s]/.test(code);
}

export function googleProviderError(error: unknown): boolean {
  return error instanceof InvalidGoogleIdentityError;
}

export function asGoogleDatabase(database: GoogleDatabase): GoogleDatabase {
  return database;
}
