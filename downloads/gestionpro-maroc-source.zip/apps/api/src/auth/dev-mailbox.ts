import type { AuthMailTransport, OutgoingAuthEmail } from './email-actions.js';
import type { CompanyInvitationMailTransport, OutgoingInvitationEmail } from '../company/invitation-service.js';

/** Deliberately ephemeral and process-local. Never enable this in production. */
export class DevMailbox implements AuthMailTransport, CompanyInvitationMailTransport {
  private entries: ((OutgoingAuthEmail | OutgoingInvitationEmail) & { createdAt: string })[] = [];

  async send(mail: OutgoingAuthEmail): Promise<void> {
    this.entries.unshift({ ...mail, createdAt: new Date().toISOString() });
    if (this.entries.length > 30) this.entries.length = 30;
  }

  async sendInvitation(mail: OutgoingInvitationEmail): Promise<void> {
    this.entries.unshift({ ...mail, createdAt: new Date().toISOString() });
    if (this.entries.length > 30) this.entries.length = 30;
  }

  list(): ((OutgoingAuthEmail | OutgoingInvitationEmail) & { createdAt: string })[] {
    return this.entries.map((entry) => ({ ...entry }));
  }
}
