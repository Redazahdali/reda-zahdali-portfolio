import { hashPassword } from './password.js';
import { validateRegistration } from './registration-validation.js';

/** Minimal pg PoolClient surface. The real Pool implements this interface. */
export interface RegistrationClient {
  query(sql: string, values?: unknown[]): Promise<{ rows: unknown[] }>;
  release(): void;
}

export interface RegistrationDatabase {
  connect(): Promise<RegistrationClient>;
}

export class EmailAlreadyRegisteredError extends Error {
  constructor() {
    super('email_already_registered');
  }
}

export interface RegisteredUser {
  id: string;
  email: string;
  status: 'PENDING_VERIFICATION';
}

function isEmailUniqueViolation(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false;
  const pgError = error as { code?: unknown; constraint?: unknown };
  return pgError.code === '23505' && pgError.constraint === 'users_email_unique';
}

/**
 * Creates a pending account and its password credential atomically.
 * No company is created until email verification/onboarding is implemented.
 * Does not send mail and does not make the account ACTIVE.
 */
export async function registerUser(
  database: RegistrationDatabase,
  input: unknown
): Promise<RegisteredUser> {
  const { email, password } = validateRegistration(input);
  // Hash before taking a database connection, to avoid holding a connection
  // during the relatively expensive Argon2id operation.
  const passwordHash = await hashPassword(password);
  const client = await database.connect();
  let transactionStarted = false;

  try {
    await client.query('BEGIN');
    transactionStarted = true;

    const result = await client.query(
      `INSERT INTO public.users (email, status)
       VALUES ($1, 'PENDING_VERIFICATION')
       RETURNING id, email, status`,
      [email]
    );

    const user = result.rows[0] as RegisteredUser | undefined;
    if (!user || typeof user.id !== 'string' || user.status !== 'PENDING_VERIFICATION') {
      throw new Error('invalid_registration_database_result');
    }

    await client.query(
      `INSERT INTO public.user_password_credentials (user_id, password_hash)
       VALUES ($1, $2)`,
      [user.id, passwordHash]
    );

    await client.query('COMMIT');
    transactionStarted = false;
    return { id: user.id, email: user.email, status: 'PENDING_VERIFICATION' };
  } catch (error) {
    if (transactionStarted) {
      try {
        await client.query('ROLLBACK');
      } catch {
        // Do not replace the original failure or disclose SQL details.
      }
    }
    if (isEmailUniqueViolation(error)) throw new EmailAlreadyRegisteredError();
    throw error;
  } finally {
    client.release();
  }
}
