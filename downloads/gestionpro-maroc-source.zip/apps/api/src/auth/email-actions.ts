import { createHash, randomBytes } from 'node:crypto';
import { hashPassword } from './password.js';
import type { RegistrationDatabase, RegistrationClient } from './registration-service.js';

export type EmailActionPurpose = 'EMAIL_VERIFICATION' | 'PASSWORD_RESET';
export interface OutgoingAuthEmail {
  to: string;
  purpose: EmailActionPurpose;
  url: string;
}
export interface AuthMailTransport {
  send(message: OutgoingAuthEmail): Promise<void>;
}

export class InvalidOrExpiredActionTokenError extends Error {
  constructor() { super('invalid_or_expired_token'); }
}

const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const REQUEST_COOLDOWN_SECONDS = 60;
const ACTION_EXPIRY_SECONDS: Record<EmailActionPurpose, number> = {
  EMAIL_VERIFICATION: 30 * 60,
  PASSWORD_RESET: 15 * 60
};

export function validateEmailRequest(input: unknown): string {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('invalid_email_request');
  }
  const raw = (input as Record<string, unknown>).email;
  if (typeof raw !== 'string') throw new Error('invalid_email_request');
  const email = raw.trim().toLowerCase();
  if (email.length < 3 || email.length > 320 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    throw new Error('invalid_email_request');
  }
  return email;
}

export function validateActionToken(input: unknown): string {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('invalid_action_input');
  }
  const token = (input as Record<string, unknown>).token;
  if (typeof token !== 'string' || !TOKEN_PATTERN.test(token)) {
    throw new Error('invalid_action_input');
  }
  return token;
}

export function validateResetConfirmation(input: unknown): { token: string; newPassword: string } {
  const token = validateActionToken(input);
  const password = (input as Record<string, unknown>).newPassword;
  if (typeof password !== 'string' || Array.from(password).length < 12 || Array.from(password).length > 128) {
    throw new Error('invalid_password_length');
  }
  return { token, newPassword: password };
}

export function hashActionToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

async function withTransaction<T>(database: RegistrationDatabase, action: (client: RegistrationClient) => Promise<T>): Promise<T> {
  const client = await database.connect();
  let transactionOpen = false;
  try {
    await client.query('BEGIN');
    transactionOpen = true;
    const result = await action(client);
    await client.query('COMMIT');
    transactionOpen = false;
    return result;
  } catch (error) {
    if (transactionOpen) await client.query('ROLLBACK').catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

interface UserRow {
  id: string;
  email: string;
  status: string;
  email_verified_at: Date | null;
}

/** Serializes issuance per user and returns the raw token ONLY to the mail transport. */
export async function requestEmailAction(
  database: RegistrationDatabase,
  transport: AuthMailTransport,
  purpose: EmailActionPurpose,
  input: unknown,
  webOrigin: string
): Promise<void> {
  const email = validateEmailRequest(input);
  const message = await withTransaction(database, async (client) => {
    const userResult = await client.query(
      `SELECT id, email, status, email_verified_at FROM public.users WHERE email = $1 FOR UPDATE`,
      [email]
    );
    const user = userResult.rows[0] as UserRow | undefined;
    if (!user || user.status === 'DISABLED') return null;
    if (purpose === 'EMAIL_VERIFICATION' &&
        (user.status !== 'PENDING_VERIFICATION' || user.email_verified_at !== null)) return null;
    if (purpose === 'PASSWORD_RESET') {
      if (user.status !== 'ACTIVE' || user.email_verified_at === null) return null;
      const hasPassword = await client.query(
        'SELECT 1 FROM public.user_password_credentials WHERE user_id = $1', [user.id]
      );
      if (hasPassword.rows.length === 0) return null;
    }
    const recent = await client.query(
      `SELECT 1 FROM public.email_action_tokens
        WHERE user_id = $1 AND purpose = $2
          AND created_at > now() - ($3::integer * interval '1 second')
        LIMIT 1`, [user.id, purpose, REQUEST_COOLDOWN_SECONDS]
    );
    if (recent.rows.length) return null;

    const token = randomBytes(32).toString('base64url');
    await client.query(
      `UPDATE public.email_action_tokens SET superseded_at = now()
        WHERE user_id = $1 AND purpose = $2
          AND consumed_at IS NULL AND superseded_at IS NULL`,
      [user.id, purpose]
    );
    await client.query(
      `INSERT INTO public.email_action_tokens (user_id, purpose, token_hash, expires_at)
       VALUES ($1, $2, $3, now() + ($4::integer * interval '1 second'))`,
      [user.id, purpose, hashActionToken(token), ACTION_EXPIRY_SECONDS[purpose]]
    );
    const path = purpose === 'EMAIL_VERIFICATION' ? '/verify-email' : '/reset-password';
    return { to: email, purpose, url: `${webOrigin}${path}?token=${encodeURIComponent(token)}` };
  });
  // Always return the same success status for known and unknown email addresses.
  // Mail delivery is intentionally separated from the DB transaction.
  if (message) {
    try {
      await transport.send(message);
    } catch {
      // Do not leak whether this e-mail exists. Retry after the 60s cooldown.
      // Production delivery requires a provider and operational monitoring.
    }
  }
}

interface TokenRow {
  user_id: string;
  purpose: EmailActionPurpose;
  expires_at: Date;
  consumed_at: Date | null;
  superseded_at: Date | null;
}

/** Locks the user first (same order as issuance), rechecks token after the lock. */
async function consumeAction(
  database: RegistrationDatabase,
  purpose: EmailActionPurpose,
  rawToken: string,
  newPasswordHash?: string
): Promise<void> {
  const tokenHash = hashActionToken(rawToken);
  await withTransaction(database, async (client) => {
    const candidate = await client.query(
      'SELECT user_id FROM public.email_action_tokens WHERE token_hash = $1 AND purpose = $2',
      [tokenHash, purpose]
    );
    const userId = (candidate.rows[0] as { user_id?: string } | undefined)?.user_id;
    if (!userId) throw new InvalidOrExpiredActionTokenError();
    const users = await client.query(
      'SELECT id, status, email_verified_at FROM public.users WHERE id = $1 FOR UPDATE', [userId]
    );
    const user = users.rows[0] as UserRow | undefined;
    if (!user || user.status === 'DISABLED') throw new InvalidOrExpiredActionTokenError();
    const tokens = await client.query(
      `SELECT user_id, purpose, expires_at, consumed_at, superseded_at
         FROM public.email_action_tokens WHERE token_hash = $1 AND purpose = $2 FOR UPDATE`,
      [tokenHash, purpose]
    );
    const token = tokens.rows[0] as TokenRow | undefined;
    if (!token || token.consumed_at !== null || token.superseded_at !== null ||
        new Date(token.expires_at).getTime() <= Date.now()) {
      throw new InvalidOrExpiredActionTokenError();
    }
    if (purpose === 'EMAIL_VERIFICATION') {
      if (user.email_verified_at !== null || user.status !== 'PENDING_VERIFICATION') {
        throw new InvalidOrExpiredActionTokenError();
      }
      await client.query(
        `UPDATE public.users SET email_verified_at = now(), status = 'ACTIVE'
         WHERE id = $1 AND status = 'PENDING_VERIFICATION' AND email_verified_at IS NULL`,
        [userId]
      );
    } else {
      if (!newPasswordHash || user.status !== 'ACTIVE' || user.email_verified_at === null) {
        throw new InvalidOrExpiredActionTokenError();
      }
      const updated = await client.query(
        'UPDATE public.user_password_credentials SET password_hash = $1 WHERE user_id = $2 RETURNING user_id',
        [newPasswordHash, userId]
      );
      if (!updated.rows.length) throw new InvalidOrExpiredActionTokenError();
      await client.query(
        `UPDATE public.auth_sessions SET revoked_at = now()
          WHERE user_id = $1 AND revoked_at IS NULL`, [userId]
      );
    }
    await client.query(
      'UPDATE public.email_action_tokens SET consumed_at = now() WHERE token_hash = $1', [tokenHash]
    );
    await client.query(
      `UPDATE public.email_action_tokens SET superseded_at = now()
        WHERE user_id = $1 AND purpose = $2 AND token_hash <> $3
          AND consumed_at IS NULL AND superseded_at IS NULL`,
      [userId, purpose, tokenHash]
    );
  });
}

export async function verifyEmail(database: RegistrationDatabase, input: unknown): Promise<void> {
  const token = validateActionToken(input);
  await consumeAction(database, 'EMAIL_VERIFICATION', token);
}

export async function confirmPasswordReset(database: RegistrationDatabase, input: unknown): Promise<void> {
  const { token, newPassword } = validateResetConfirmation(input);
  // Hash before opening/locking a database transaction.
  const passwordHash = await hashPassword(newPassword);
  await consumeAction(database, 'PASSWORD_RESET', token, passwordHash);
}
