import { createRemoteJWKSet, jwtVerify } from 'jose';
import { InvalidGoogleIdentityError, type GoogleCodeExchange } from './google-oidc.js';

// Only Google's HTTPS endpoint; never accept a token or JWKS URI from the browser.
const GOOGLE_JWKS = createRemoteJWKSet(new URL('https://www.googleapis.com/oauth2/v3/certs'), {
  timeoutDuration: 5000
});

export const googleCodeExchange: GoogleCodeExchange = {
  async exchange({ code, codeVerifier, nonce, config }) {
    const body = new URLSearchParams({
      code,
      client_id: config.clientId,
      client_secret: config.clientSecret,
      redirect_uri: config.redirectUri,
      grant_type: 'authorization_code',
      code_verifier: codeVerifier
    });
    let idToken: string;
    try {
      const response = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: AbortSignal.timeout(7000)
      });
      if (!response.ok) throw new InvalidGoogleIdentityError();
      const payload: unknown = await response.json();
      if (!payload || typeof payload !== 'object' || Array.isArray(payload) ||
          typeof (payload as {id_token?: unknown}).id_token !== 'string') {
        throw new InvalidGoogleIdentityError();
      }
      idToken = (payload as {id_token: string}).id_token;
      if (idToken.length > 16000) throw new InvalidGoogleIdentityError();
    } catch {
      throw new InvalidGoogleIdentityError();
    }
    try {
      const { payload } = await jwtVerify(idToken, GOOGLE_JWKS, {
        algorithms: ['RS256'],
        audience: config.clientId,
        issuer: ['https://accounts.google.com', 'accounts.google.com'],
        clockTolerance: 5
      });
      if (payload.nonce !== nonce || payload.aud !== config.clientId ||
          (payload.azp !== undefined && payload.azp !== config.clientId) ||
          typeof payload.iat !== 'number' || typeof payload.exp !== 'number' ||
          typeof payload.sub !== 'string' ||
          typeof payload.email !== 'string' || payload.email_verified !== true) {
        throw new InvalidGoogleIdentityError();
      }
      return {
        sub: payload.sub,
        email: payload.email,
        emailVerified: true,
        hostedDomain: typeof payload.hd === 'string' ? payload.hd : undefined
      };
    } catch {
      throw new InvalidGoogleIdentityError();
    }
  }
};
