﻿export interface RegistrationInput {
  email: string;
  password: string;
}

export interface ValidatedRegistration {
  email: string;
  password: string;
}

export function validateRegistration(
  input: unknown
): ValidatedRegistration {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('invalid_registration_input');
  }

  const data = input as Record<string, unknown>;

  if (typeof data.email !== 'string' ||
      typeof data.password !== 'string') {
    throw new Error('invalid_registration_input');
  }

  const email = data.email.trim().toLowerCase();
  const password = data.password;

  if (
    email.length < 3 ||
    email.length > 320 ||
    !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)
  ) {
    throw new Error('invalid_email');
  }

  const passwordLength = Array.from(password).length;

  if (passwordLength < 12 || passwordLength > 128) {
    throw new Error('invalid_password_length');
  }

  return { email, password };
}
