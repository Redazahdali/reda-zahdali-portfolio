import { createHash, randomBytes } from 'node:crypto';
import { verifyPassword } from './password.js';

export const SESSION_COOKIE_NAME = 'gp_session';
export const SESSION_DURATION_SECONDS = 8 * 60 * 60;

// A well-formed dummy credential keeps the unknown-email path doing Argon2id work.
// It is NOT a login secret and is never accepted as an account credential.
const DUMMY_ARGON2ID_HASH =
  '$argon2id$v=19$m=19456,t=2,p=1$bByy6BF3qJj49GtPsZ/fZw$5Q0kaed/6bvPHfa2v+cuZEzFOF8tmKpEu/DD7eVHC+8';

export interface AuthQueryDatabase {
  query(sql: string, values?: unknown[]): Promise<{ rows: unknown[]; rowCount?: number | null }>;
}

export interface PublicAuthUser {
  id: string;
  email: string;
  status: 'ACTIVE';
}

interface AuthUserRow {
  id: string;
  email: string;
  status: string;
  email_verified_at: Date | string | null;
  password_hash?: string | null;
}

export class InvalidCredentialsError extends Error {
  constructor() { super('invalid_credentials'); }
}
export class EmailVerificationRequiredError extends Error {
  constructor() { super('email_verification_required'); }
}
export class AccountUnavailableError extends Error {
  constructor() { super('account_unavailable'); }
}

export function validateLogin(input: unknown): { email: string; password: string } {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('invalid_login_input');
  }
  const body = input as Record<string, unknown>;
  if (typeof body.email !== 'string' || typeof body.password !== 'string') {
    throw new Error('invalid_login_input');
  }
  const email = body.email.trim().toLowerCase();
  if (email.length < 3 || email.length > 320 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    throw new Error('invalid_login_input');
  }
  // Login must accept existing credentials: do not reapply registration's 12-char minimum.
  if (body.password.length === 0 || body.password.length > 1024) {
    throw new Error('invalid_login_input');
  }
  return { email, password: body.password };
}

export function digestSessionToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function parseSessionToken(cookieHeader: string | undefined): string | null {
  if (!cookieHeader) return null;
  const values = cookieHeader.split(';').map((part) => part.trim());
  const matches = values.filter((part) => part.startsWith(`${SESSION_COOKIE_NAME}=`));
  if (matches.length !== 1) return null;
  const token = matches[0]?.slice(SESSION_COOKIE_NAME.length + 1) ?? '';
  return /^[A-Za-z0-9_-]{43}$/.test(token) ? token : null;
}

export function sessionCookie(token: string, secure: boolean): string {
  return `${SESSION_COOKIE_NAME}=${token}; Path=/api/v1; HttpOnly; SameSite=Strict; Max-Age=${SESSION_DURATION_SECONDS}${secure ? '; Secure' : ''}`;
}

export function expiredSessionCookie(secure: boolean): string {
  return `${SESSION_COOKIE_NAME}=; Path=/api/v1; HttpOnly; SameSite=Strict; Max-Age=0${secure ? '; Secure' : ''}`;
}

/** Remove the pre-ENT-02A cookie, whose narrower path otherwise creates duplicate names. */
export function expiredLegacySessionCookie(secure: boolean): string {
  return `${SESSION_COOKIE_NAME}=; Path=/api/v1/auth; HttpOnly; SameSite=Strict; Max-Age=0${secure ? '; Secure' : ''}`;
}

function asActiveUser(row: AuthUserRow): PublicAuthUser {
  return { id: row.id, email: row.email, status: 'ACTIVE' };
}

export async function loginUser(
  database: AuthQueryDatabase,
  input: unknown
): Promise<{ user: PublicAuthUser; sessionToken: string }> {
  const { email, password } = validateLogin(input);
  const result = await database.query(
    `SELECT u.id, u.email, u.status, u.email_verified_at, c.password_hash
       FROM public.users u
       LEFT JOIN public.user_password_credentials c ON c.user_id = u.id
      WHERE u.email = $1 LIMIT 1`,
    [email]
  );
  const row = result.rows[0] as AuthUserRow | undefined;
  const encoded = typeof row?.password_hash === 'string'
    ? row.password_hash : DUMMY_ARGON2ID_HASH;
  let valid = false;
  try {
    valid = await verifyPassword(encoded, password);
  } catch {
    // Malformed credential data must not reach the HTTP client.
    valid = false;
  }
  if (!row || !valid || !row.password_hash) throw new InvalidCredentialsError();
  if (row.status === 'DISABLED') throw new AccountUnavailableError();
  if (row.status !== 'ACTIVE' || row.email_verified_at === null) {
    throw new EmailVerificationRequiredError();
  }

  const sessionToken = randomBytes(32).toString('base64url');
  await database.query(
    `INSERT INTO public.auth_sessions (token_hash, user_id, expires_at)
     VALUES ($1, $2, now() + ($3::integer * interval '1 second'))`,
    [digestSessionToken(sessionToken), row.id, SESSION_DURATION_SECONDS]
  );
  return { user: asActiveUser(row), sessionToken };
}

export async function lookupSessionUser(
  database: AuthQueryDatabase,
  token: string
): Promise<PublicAuthUser | null> {
  const result = await database.query(
    `SELECT u.id, u.email, u.status, u.email_verified_at
       FROM public.auth_sessions s
       JOIN public.users u ON u.id = s.user_id
      WHERE s.token_hash = $1
        AND s.revoked_at IS NULL
        AND s.expires_at > now()
        AND u.status = 'ACTIVE'
        AND u.email_verified_at IS NOT NULL
      LIMIT 1`,
    [digestSessionToken(token)]
  );
  const row = result.rows[0] as AuthUserRow | undefined;
  return row ? asActiveUser(row) : null;
}

export async function revokeSession(database: AuthQueryDatabase, token: string): Promise<void> {
  await database.query(
    `UPDATE public.auth_sessions
        SET revoked_at = now()
      WHERE token_hash = $1 AND revoked_at IS NULL`,
    [digestSessionToken(token)]
  );
}
