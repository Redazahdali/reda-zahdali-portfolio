import 'dotenv/config';
import { Pool } from 'pg';
import { createApp } from './app.js';
import { DevMailbox } from './auth/dev-mailbox.js';
import { googleCodeExchange } from './auth/google-provider.js';
import { assertGoogleConfig, type GoogleOidcConfig } from './auth/google-oidc.js';

const portValue = Number(process.env.PORT ?? '5000');
if (!Number.isInteger(portValue) || portValue < 1 || portValue > 65535) {
  throw new Error('PORT doit être un entier entre 1 et 65535.');
}

const host = process.env.HOST ?? '127.0.0.1';
const databaseUrl = process.env.DATABASE_URL?.trim();
const pool = databaseUrl
  ? new Pool({ connectionString: databaseUrl, connectionTimeoutMillis: 2000, max: 5 })
  : null;

// Never expose raw email action links to a non-loopback listener or in production.
const devMailboxEnabled = process.env.GP_DEV_MAILBOX === '1'
  && process.env.NODE_ENV !== 'production'
  && ['127.0.0.1', '::1', 'localhost'].includes(host);
const devMailbox = devMailboxEnabled ? new DevMailbox() : null;
const webOrigin = process.env.GP_WEB_ORIGIN ?? 'http://127.0.0.1:5173';
const googleConfig: GoogleOidcConfig | null =
  process.env.GP_GOOGLE_CLIENT_ID && process.env.GP_GOOGLE_CLIENT_SECRET && process.env.GP_GOOGLE_REDIRECT_URI
    ? {
        clientId: process.env.GP_GOOGLE_CLIENT_ID,
        clientSecret: process.env.GP_GOOGLE_CLIENT_SECRET,
        redirectUri: process.env.GP_GOOGLE_REDIRECT_URI,
        webOrigin
      }
    : null;
if (googleConfig) assertGoogleConfig(googleConfig);
const app = createApp(pool, {
  mailTransport: devMailbox,
  invitationMailTransport: devMailbox,
  devMailbox,
  enableDevMailbox: devMailboxEnabled,
  webOrigin,
  google: googleConfig ? { config: googleConfig, exchange: googleCodeExchange } : null
});
const server = app.listen(portValue, host, () => {
  console.log(`API GestionPro locale : http://${host}:${portValue}/api/v1/health`);
  console.log(`PostgreSQL : ${pool ? 'configuré (vérifier /api/v1/ready)' : 'non configuré'}`);
  if (devMailboxEnabled) console.log('AUTH-03 : boite de test locale active (aucun email reel envoye)');
});

let stopping = false;
async function shutdown(): Promise<void> {
  if (stopping) return;
  stopping = true;
  server.close();
  try {
    await pool?.end();
  } catch {
    // Eviter d'afficher des messages contenant des secrets de connexion.
  }
}
process.once('SIGINT', () => { void shutdown(); });
process.once('SIGTERM', () => { void shutdown(); });
