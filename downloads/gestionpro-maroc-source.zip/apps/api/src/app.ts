import express, { type Express, type ErrorRequestHandler } from 'express';
import {
  assertGoogleConfig, completeGoogleLogin, consumeGoogleFlow,
  expiredGoogleStateCookie, GoogleIdentityConflictError, InvalidGoogleIdentityError,
  googleStateCookie, parseGoogleStateCookie, safeGoogleOutcomeUrl,
  startGoogleLogin, statesMatch, validAuthorizationCode,
  type GoogleCodeExchange, type GoogleOidcConfig
} from './auth/google-oidc.js';
import {
  confirmPasswordReset, InvalidOrExpiredActionTokenError, requestEmailAction,
  verifyEmail, type AuthMailTransport
} from './auth/email-actions.js';
import type { DevMailbox } from './auth/dev-mailbox.js';
import { CompanyAccountUnavailableError, CompanyAlreadyExistsError, createMyCompany, findMyCompany, findMyCompanyMembers } from './company/company-service.js';
import {
  createCompanyInvitation, InvitationAlreadyPendingError, InvitationForbiddenError, InvitationNotFoundError,
  InvitationRecipientAlreadyAssignedError, InvitationRecentlySentError, listMyCompanyInvitations,
  revokeCompanyInvitation, acceptCompanyInvitation, previewCompanyInvitation, InvitationAcceptanceError
} from './company/invitation-service.js';
import type { CompanyInvitationMailTransport } from './company/invitation-service.js';
import { getParty, listParties } from './company/party-read.js';
import { partyCsv } from './company/party-csv.js';
import { getCatalog, listCatalog, saveCatalog, saveCatalogOnce, CatalogWriteError } from './company/catalog.js';
import { listQuotes, readQuote, saveQuote, previewQuote, QuoteError } from './company/quote-service.js';
import { renderQuotePdf, renderInvoicePdf } from './company/quote-pdf.js';
import { listInvoices, readInvoice, readInvoiceDocument, saveInvoice, convertQuote, issueInvoice } from './company/invoice-service.js';
import { getIdentity, getLogo, saveIdentity, saveLogo, getDocumentVisual } from './company/document-identity.js';
import { archiveParty, createParty, getPartyAudit, preparePartyIceConfirmation, reactivateParty, PartyConflictError, PartyForbiddenError, PartyNotFoundError, PartySessionError, updateParty } from './company/party-service.js';
import helmet from 'helmet';
import { EmailAlreadyRegisteredError, registerUser, type RegistrationDatabase } from './auth/registration-service.js';
import {
  AccountUnavailableError,
  EmailVerificationRequiredError,
  InvalidCredentialsError,
  expiredSessionCookie,
  expiredLegacySessionCookie,
  loginUser,
  lookupSessionUser,
  parseSessionToken,
  revokeSession,
  sessionCookie,
  type AuthQueryDatabase
} from './auth/login-service.js';

export interface SqlHealthProbe extends AuthQueryDatabase {
  connect?: RegistrationDatabase['connect'];
}

export interface AuthAppOptions {
  mailTransport?: AuthMailTransport | null;
  devMailbox?: DevMailbox | null;
  enableDevMailbox?: boolean;
  webOrigin?: string;
  invitationMailTransport?: CompanyInvitationMailTransport | null;
  google?: { config: GoogleOidcConfig; exchange: GoogleCodeExchange } | null;
}

/** A local API with injected database and mailer for deterministic tests. */
export function createApp(database: SqlHealthProbe | null, options: AuthAppOptions = {}): Express {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '100kb' }));

  const secureCookie = process.env.NODE_ENV === 'production';
  const authHeaders = (_req: express.Request, res: express.Response, next: express.NextFunction) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  };
  app.use('/api/v1/auth', authHeaders);
  app.use('/api/v1/company', authHeaders);
  app.use('/api/v1/parties', authHeaders);
  app.use('/api/v1/catalog', authHeaders);
  app.use('/api/v1/invoices', authHeaders);

  app.use('/api/v1/catalog', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const statusOnly = req.method === 'POST' && /^\/[0-9a-f-]+\/status$/i.test(req.path);
      const id = req.path === '/' ? null : statusOnly ? req.path.slice(1,-7) : req.path.slice(1);
      if (id && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) { res.status(400).json({ error: 'invalid_id' }); return; }
      if (req.method === 'GET' && !id) {
        const search = req.query.search ?? '';
        const active = req.query.active ?? 'all';
        const kind=req.query.kind ?? 'all', status=req.query.status ?? 'all', category=req.query.category ?? '';
        const limit=Number(req.query.limit ?? 100), offset=Number(req.query.offset ?? 0);
        if (typeof search !== 'string' || search.length > 200 || typeof active !== 'string' || !['all','true'].includes(active) || typeof kind !== 'string' || !['all','PRODUCT','SERVICE'].includes(kind) || typeof status !== 'string' || !['all','active','inactive'].includes(status) || typeof category !== 'string' || category.length>120 || !Number.isInteger(limit) || limit<1 || limit>100 || !Number.isInteger(offset) || offset<0 || offset>100000) { res.status(400).json({ error: 'invalid_query' }); return; }
        res.json({ items: await listCatalog(database, user.id, search, active === 'true', {kind,status,category,limit,offset}) }); return;
      }
      if (req.method === 'GET' && id) {
        const item = await getCatalog(database, user.id, id);
        if (!item) { res.status(404).json({ error: 'not_found' }); return; }
        res.json({ item }); return;
      }
      if (req.method === 'POST') {
        const key=req.get('Idempotency-Key');
        if ((key || statusOnly) && typeof database.connect !== 'function') {res.status(503).json({error:'database_unavailable'});return;}
        const item = key || statusOnly ? await saveCatalogOnce({connect:database.connect!.bind(database)},token,id,req.body,key ?? '',statusOnly) : await saveCatalog(database, user.id, id, req.body);
        if (!item) { res.status(id ? 404 : 403).json({ error: id ? 'not_found' : 'forbidden' }); return; }
        res.status(id ? 200 : 201).json({ item }); return;
      }
      res.status(405).json({ error: 'method_not_allowed' });
    } catch (error) {
      if (error instanceof CatalogWriteError) {res.status(error.status).json({error:error.code});return;}
      if (error instanceof Error && error.message === 'invalid_catalog') { res.status(400).json({ error: 'invalid_catalog' }); return; }
      if (error && typeof error === 'object' && 'code' in error && error.code === '23505') { res.status(409).json({ error: 'duplicate_reference' }); return; }
      next(error);
    }
  });

  app.get('/api/v1/health', (_req, res) => {
    res.status(200).json({ service: 'gestionpro-api', status: 'ok' });
  });

  app.get('/api/v1/ready', async (_req, res) => {
    if (!database) {
      res.status(503).json({ status: 'not_ready', database: 'not_configured' });
      return;
    }
    try {
      await database.query('SELECT 1');
      res.status(200).json({ status: 'ready', database: 'connected' });
    } catch {
      res.status(503).json({ status: 'not_ready', database: 'unavailable' });
    }
  });

  app.post('/api/v1/auth/register', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    try {
      const user = await registerUser({ connect: database.connect.bind(database) }, req.body);
      // Best-effort sending AFTER the account transaction has committed.
      // Failure never rolls back the created account; users can request a new link.
      if (options.mailTransport) {
        try {
          await requestEmailAction(
            { connect: database.connect.bind(database) }, options.mailTransport,
            'EMAIL_VERIFICATION', { email: user.email }, options.webOrigin ?? 'http://127.0.0.1:5173'
          );
        } catch {
          // No account enumeration or SMTP/SQL details in the response.
        }
      }
      res.status(201).json({ user });
    } catch (error) {
      if (error instanceof EmailAlreadyRegisteredError) {
        res.status(409).json({ error: 'email_already_registered' });
        return;
      }
      if (error instanceof Error && [
        'invalid_registration_input', 'invalid_email', 'invalid_password_length'
      ].includes(error.message)) {
        res.status(400).json({ error: error.message });
        return;
      }
      next(error);
    }
  });

  app.post('/api/v1/auth/login', async (req, res, next) => {
    if (!database) {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    try {
      const result = await loginUser(database, req.body);
      res.setHeader('Set-Cookie', [sessionCookie(result.sessionToken, secureCookie), expiredLegacySessionCookie(secureCookie)]);
      res.status(200).json({ user: result.user });
    } catch (error) {
      if (error instanceof InvalidCredentialsError) {
        res.status(401).json({ error: 'invalid_credentials' });
        return;
      }
      if (error instanceof EmailVerificationRequiredError) {
        res.status(403).json({ error: 'email_verification_required' });
        return;
      }
      if (error instanceof AccountUnavailableError) {
        res.status(403).json({ error: 'account_unavailable' });
        return;
      }
      if (error instanceof Error && error.message === 'invalid_login_input') {
        res.status(400).json({ error: 'invalid_login_input' });
        return;
      }
      next(error);
    }
  });

  // AUTH-04: Google authorization code + PKCE. OAuth secrets never enter the browser.
  app.get('/api/v1/auth/google/start', async (_req, res, next) => {
    if (!database || typeof database.connect !== 'function' || !options.google) {
      res.status(503).json({ error: 'google_not_configured' });
      return;
    }
    try {
      assertGoogleConfig(options.google.config);
      const result = await startGoogleLogin({
        query: database.query.bind(database), connect: database.connect.bind(database)
      }, options.google.config);
      res.setHeader('Set-Cookie', googleStateCookie(result.state, secureCookie));
      res.redirect(302, result.redirectTo);
    } catch (error) {
      next(error);
    }
  });

  app.get('/api/v1/auth/google/callback', async (req, res, next) => {
    res.setHeader('Set-Cookie', expiredGoogleStateCookie(secureCookie));
    if (!database || typeof database.connect !== 'function' || !options.google) {
      res.status(503).json({ error: 'google_not_configured' });
      return;
    }
    const state = req.query.state;
    // Google includes the issuer URL (RFC 9207) in the authorization response.
    if (req.query.iss !== undefined && req.query.iss !== 'https://accounts.google.com') {
      res.status(400).json({ error: 'invalid_google_issuer' });
      return;
    }
    const cookieState = parseGoogleStateCookie(req.headers.cookie);
    if (typeof state !== 'string' || !cookieState || !statesMatch(state, cookieState)) {
      res.status(400).json({ error: 'invalid_google_state' });
      return;
    }
    const { config, exchange } = options.google;
    try {
      const flow = await consumeGoogleFlow({
        query: database.query.bind(database), connect: database.connect.bind(database)
      }, state);
      if (!flow) {
        res.status(400).json({ error: 'expired_or_used_google_state' });
        return;
      }
      if (req.query.error !== undefined) {
        res.redirect(303, safeGoogleOutcomeUrl(config, req.query.error === 'access_denied' ? 'cancelled' : 'failed'));
        return;
      }
      if (!validAuthorizationCode(req.query.code)) {
        res.status(400).json({ error: 'invalid_google_code' });
        return;
      }
      const identity = await exchange.exchange({
        code: req.query.code, nonce: flow.nonce, codeVerifier: flow.codeVerifier, config
      });
      const result = await completeGoogleLogin({
        query: database.query.bind(database), connect: database.connect.bind(database)
      }, identity);
      res.setHeader('Set-Cookie', [expiredGoogleStateCookie(secureCookie), sessionCookie(result.sessionToken, secureCookie), expiredLegacySessionCookie(secureCookie)]);
      res.redirect(303, safeGoogleOutcomeUrl(config, 'success'));
    } catch (error) {
      if (error instanceof GoogleIdentityConflictError) {
        res.redirect(303, safeGoogleOutcomeUrl(config, 'account_link_required'));
        return;
      }
      if (error instanceof InvalidGoogleIdentityError) {
        res.redirect(303, safeGoogleOutcomeUrl(config, 'failed'));
        return;
      }
      next(error);
    }
  });

  app.get('/api/v1/auth/me', async (req, res, next) => {
    if (!database) {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) {
      res.status(401).json({ error: 'unauthorized' });
      return;
    }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) {
        res.status(401).json({ error: 'unauthorized' });
        return;
      }
      res.status(200).json({ user });
    } catch (error) {
      next(error);
    }
  });

  app.post('/api/v1/auth/logout', async (req, res, next) => {
    if (!database) {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    const token = parseSessionToken(req.headers.cookie);
    try {
      if (token) await revokeSession(database, token);
      res.setHeader('Set-Cookie', [expiredSessionCookie(secureCookie), expiredLegacySessionCookie(secureCookie)]);
      res.status(204).end();
    } catch (error) {
      next(error);
    }
  });



  // ENT-01: company onboarding is tenant-scoped to the authenticated session.
  // No company IDs, user IDs or role selections are accepted from clients.
  app.get('/api/v1/auth/company', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const company = await findMyCompany(database, user.id);
      res.status(200).json({ company });
    } catch (error) { next(error); }
  });

  app.post('/api/v1/auth/company', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') {
      res.status(503).json({ error: 'database_unavailable' }); return;
    }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const company = await createMyCompany({ connect: database.connect.bind(database) }, user.id, req.body);
      res.status(201).json({ company });
    } catch (error) {
      if (error instanceof CompanyAlreadyExistsError) {
        res.status(409).json({ error: 'company_already_exists' }); return;
      }
      if (error instanceof CompanyAccountUnavailableError) {
        res.status(403).json({ error: 'account_unavailable' }); return;
      }
      if (error instanceof Error && ['invalid_company_input', 'invalid_company_name'].includes(error.message)) {
        res.status(400).json({ error: error.message }); return;
      }
      next(error);
    }
  });

  // ENT-02A: tenant scope is derived exclusively from the authenticated session.
  app.get('/api/v1/parties', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    const search = req.query.search ?? '';
    const role = req.query.role ?? 'all';
    const status = req.query.status ?? 'all';
    const limit = Number(req.query.limit ?? 50);
    const offset = Number(req.query.offset ?? 0);
    if (typeof search !== 'string' || search.length > 200 || typeof role !== 'string' || !['all', 'client', 'supplier'].includes(role) || typeof status !== 'string' || !['all', 'ACTIVE', 'ARCHIVED'].includes(status) || !Number.isInteger(limit) || limit < 1 || limit > 100 || !Number.isInteger(offset) || offset < 0 || offset > 100000) {
      res.status(400).json({ error: 'invalid_query' }); return;
    }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const parties = await listParties(database, user.id, { search, role, status, limit, offset });
      res.status(200).json({ parties, limit, offset });
    } catch (error) { next(error); }
  });

  app.get('/api/v1/parties/export.csv', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    const search = req.query.search ?? '';
    const role = req.query.role ?? 'all';
    const status = req.query.status ?? 'all';
    if (typeof search !== 'string' || search.length > 200 || typeof role !== 'string' || !['all', 'client', 'supplier'].includes(role) || typeof status !== 'string' || !['all', 'ACTIVE', 'ARCHIVED'].includes(status)) {
      res.status(400).json({ error: 'invalid_query' }); return;
    }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const parties = await listParties(database, user.id, { search, role, status, limit: null, offset: 0 });
      const rows = parties.map((item) => {
        const p = item as { display_name: string; kind: string; status: string; is_client: boolean; is_supplier: boolean; city: string | null };
        return [p.display_name, p.kind, p.status, p.is_client ? 'Oui' : 'Non', p.is_supplier ? 'Oui' : 'Non', p.city];
      });
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="clients-fournisseurs.csv"');
      res.status(200).send(partyCsv(['Nom', 'Type', 'Statut', 'Client', 'Fournisseur', 'Ville'], rows));
    } catch (error) { next(error); }
  });

  app.get('/api/v1/parties/:id', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(req.params.id)) {
      res.status(400).json({ error: 'invalid_party_id' }); return;
    }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const party = await getParty(database, user.id, req.params.id);
      if (!party) { res.status(404).json({ error: 'not_found' }); return; }
      res.status(200).json({ party });
    } catch (error) { next(error); }
  });

  const partyRoute = (action: 'prepare' | 'reactivate' | 'audit'): express.RequestHandler => async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    const id = typeof req.params.id === 'string' ? req.params.id : undefined;
    if (id && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) { res.status(400).json({ error: 'invalid_party_id' }); return; }
    const db = { connect: database.connect.bind(database) };
    try {
      if (action === 'prepare') { res.json({ confirmation: await preparePartyIceConfirmation(db, token, req.body, req.get('Idempotency-Key') ?? '', id) }); return; }
      if (action === 'reactivate') { res.json({ party: await reactivateParty(db, token, id!, req.get('Idempotency-Key') ?? '') }); return; }
      res.json({ events: await getPartyAudit(db, token, id!) });
    } catch (error) {
      if (error instanceof PartySessionError) { res.status(401).json({ error: 'unauthorized' }); return; }
      if (error instanceof PartyForbiddenError) { res.status(403).json({ error: 'party_forbidden' }); return; }
      if (error instanceof PartyNotFoundError) { res.status(404).json({ error: 'not_found' }); return; }
      if (error instanceof PartyConflictError) { res.status(409).json({ error: 'party_conflict' }); return; }
      if (error instanceof Error && error.message.startsWith('invalid_')) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  };
  app.post('/api/v1/parties/ice-confirmation', partyRoute('prepare'));
  app.post('/api/v1/parties/:id/ice-confirmation', partyRoute('prepare'));
  app.post('/api/v1/parties/:id/reactivate', partyRoute('reactivate'));
  app.get('/api/v1/parties/:id/audit', partyRoute('audit'));

  app.post('/api/v1/parties', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      res.status(201).json({ party: await createParty({ connect: database.connect.bind(database) }, token, req.body, req.get('Idempotency-Key') ?? '', req.get('ICE-Confirmation') || undefined) });
    } catch (error) {
      if (error instanceof PartyForbiddenError) { res.status(403).json({ error: 'party_forbidden' }); return; }
      if (error instanceof PartySessionError) { res.status(401).json({ error: 'unauthorized' }); return; }
      if (error instanceof PartyConflictError) { res.status(409).json({ error: 'party_conflict' }); return; }
      if (error instanceof Error && error.message.startsWith('invalid_')) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  });

  app.post('/api/v1/parties/:id/update', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(req.params.id)) { res.status(400).json({ error: 'invalid_party_id' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      res.status(200).json({ party: await updateParty({ connect: database.connect.bind(database) }, token, req.params.id, req.body, req.get('Idempotency-Key') ?? '', req.get('ICE-Confirmation') || undefined) });
    } catch (error) {
      if (error instanceof PartyForbiddenError) { res.status(403).json({ error: 'party_forbidden' }); return; }
      if (error instanceof PartySessionError) { res.status(401).json({ error: 'unauthorized' }); return; }
      if (error instanceof PartyNotFoundError) { res.status(404).json({ error: 'not_found' }); return; }
      if (error instanceof PartyConflictError) { res.status(409).json({ error: 'party_conflict' }); return; }
      if (error instanceof Error && error.message.startsWith('invalid_')) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  });

  app.post('/api/v1/parties/:id/archive', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(req.params.id)) { res.status(400).json({ error: 'invalid_party_id' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      await archiveParty({ connect: database.connect.bind(database) }, token, req.params.id, req.get('Idempotency-Key') ?? '');
      res.status(204).end();
    } catch (error) {
      if (error instanceof PartyForbiddenError) { res.status(403).json({ error: 'party_forbidden' }); return; }
      if (error instanceof PartySessionError) { res.status(401).json({ error: 'unauthorized' }); return; }
      if (error instanceof PartyNotFoundError) { res.status(404).json({ error: 'not_found' }); return; }
      if (error instanceof PartyConflictError) { res.status(409).json({ error: 'party_conflict' }); return; }
      if (error instanceof Error && error.message.startsWith('invalid_')) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  });

  const quoteRoute = (action: 'list' | 'read' | 'create' | 'update'): express.RequestHandler => async (req,res,next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error:'database_unavailable' }); return; }
    const token=parseSessionToken(req.headers.cookie); if (!token) { res.status(401).json({error:'unauthorized'}); return; }
    const db={connect:database.connect.bind(database)};
    try {
      if (action==='list') {
        const search=req.query.search ?? '', status=req.query.status ?? 'all';
        if (typeof search !== 'string' || typeof status !== 'string') throw new QuoteError('invalid_quote',400);
        res.json({quotes:await listQuotes(db,token,search,status,Number(req.query.limit ?? 25),Number(req.query.offset ?? 0))}); return;
      }
      const id=typeof req.params.id==='string' ? req.params.id : '';
      if (action==='read') {res.json({quote:await readQuote(db,token,id)}); return;}
      res.status(action==='create'?201:200).json({quote:await saveQuote(db,token,action==='create'?null:id,req.body,req.get('Idempotency-Key') ?? '')});
    } catch (e) { if (e instanceof QuoteError) {res.status(e.status).json({error:e.code}); return;} next(e); }
  };
  app.get('/api/v1/quotes',quoteRoute('list'));
  app.post('/api/v1/quotes/preview', async (req,res,next) => {
    if (!database || typeof database.connect !== 'function') {res.status(503).json({error:'database_unavailable'}); return;}
    const token=parseSessionToken(req.headers.cookie); if (!token) {res.status(401).json({error:'unauthorized'}); return;}
    try {res.json(await previewQuote({connect:database.connect.bind(database)},token,req.body?.lines));}
    catch(e) {if (e instanceof QuoteError) {res.status(e.status).json({error:e.code}); return;} next(e);}
  });
  app.get('/api/v1/quotes/:id/pdf', async (req,res,next) => {
    if (!database || typeof database.connect !== 'function') {res.status(503).json({error:'database_unavailable'}); return;}
    const token=parseSessionToken(req.headers.cookie); if (!token) {res.status(401).json({error:'unauthorized'}); return;}
    try {
      const quote=await readQuote({connect:database.connect.bind(database)},token,req.params.id);
      const pdf=await renderQuotePdf(quote,await getDocumentVisual({connect:database.connect.bind(database)},token));
      res.setHeader('Content-Type','application/pdf'); res.setHeader('Cache-Control','no-store');
      res.setHeader('Content-Disposition',`${req.query.inline === '1' ? 'inline' : 'attachment'}; filename="devis-${String(quote.quote_number ?? 'document').replace(/[^A-Za-z0-9_-]/g,'')}.pdf"`);
      res.send(pdf);
    } catch(e) {if (e instanceof QuoteError) {res.status(e.status).json({error:e.code}); return;} next(e);}
  });
  app.get('/api/v1/quotes/:id',quoteRoute('read'));
  app.post('/api/v1/quotes',quoteRoute('create'));
  app.post('/api/v1/quotes/:id/update',quoteRoute('update'));

  const identityRoute=(action:'get'|'save'|'logo'|'upload'):express.RequestHandler=>async(req,res,next)=>{
    if(!database||typeof database.connect!=='function'){res.status(503).json({error:'database_unavailable'});return;}
    const token=parseSessionToken(req.headers.cookie);if(!token){res.status(401).json({error:'unauthorized'});return;}
    const db={connect:database.connect.bind(database)};
    try{
      if(action==='get'){res.json(await getIdentity(db,token));return;}
      if(action==='logo'){const logo=await getLogo(db,token);if(!logo){res.status(404).json({error:'not_found'});return;}res.type('image/png').send(logo);return;}
      if(action==='upload'){res.json(await saveLogo(db,token,req.body));return;}
      if(!req.body||typeof req.body!=='object'||Array.isArray(req.body)||Object.keys(req.body).some(k=>!['palette','removeLogo'].includes(k)))throw new QuoteError('invalid_document_identity',400);
      res.json(await saveIdentity(db,token,req.body.palette,req.body.removeLogo));
    }catch(e){if(e instanceof QuoteError){res.status(e.status).json({error:e.code});return;}next(e);}
  };
  app.get('/api/v1/company/document-identity',identityRoute('get'));
  app.post('/api/v1/company/document-identity',identityRoute('save'));
  app.get('/api/v1/company/document-identity/logo',identityRoute('logo'));
  app.post('/api/v1/company/document-identity/logo',express.raw({type:['image/png','image/jpeg','image/webp'],limit:'2mb'}),identityRoute('upload'));

  const invoiceRoute=(action:'list'|'read'|'create'|'update'|'convert'|'issue'|'pdf'):express.RequestHandler=>async(req,res,next)=>{
    if(!database||typeof database.connect!=='function'){res.status(503).json({error:'database_unavailable'});return;}
    const token=parseSessionToken(req.headers.cookie);if(!token){res.status(401).json({error:'unauthorized'});return;}
    const db={connect:database.connect.bind(database)},id=typeof req.params.id==='string'?req.params.id:'',key=req.get('Idempotency-Key')??'';
    try{
      if(!await lookupSessionUser(database,token)){res.status(401).json({error:'unauthorized'});return;}
      const schema=await database.query("SELECT to_regclass('public.invoices') AS invoices, to_regclass('public.invoice_lines') AS lines, to_regclass('public.invoice_receipts') AS receipts");
      const available=schema.rows[0] as {invoices:unknown;lines:unknown;receipts:unknown}|undefined;
      if(!available?.invoices||!available.lines||!available.receipts){res.status(503).json({error:'invoice_schema_unavailable'});return;}
      if(action==='list'){const search=req.query.search??'',status=req.query.status??'all',sourceQuoteId=req.query.sourceQuoteId??null;if(typeof search!=='string'||typeof status!=='string'||(sourceQuoteId!==null&&typeof sourceQuoteId!=='string'))throw new QuoteError('invalid_invoice',400);res.json({invoices:await listInvoices(db,token,search,status,Number(req.query.limit??25),Number(req.query.offset??0),sourceQuoteId)});return;}
      if(action==='read'){res.json({invoice:await readInvoice(db,token,id)});return;}
      if(action==='pdf'){const doc=await readInvoiceDocument(db,token,id);const pdf=doc.pdf??await renderInvoicePdf(doc.invoice,doc.visual);res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`${req.query.inline==='1'?'inline':'attachment'}; filename="facture-${String(doc.invoice.invoice_number??'brouillon').replace(/[^A-Za-z0-9_-]/g,'')}.pdf"`);res.send(pdf);return;}
      if(action==='convert'){res.status(201).json({invoice:await convertQuote(db,token,id,key)});return;}
      if(action==='issue'){if(!req.body||typeof req.body!=='object'||Array.isArray(req.body)||Object.keys(req.body).length!==1)throw new QuoteError('invalid_invoice',400);res.json({invoice:await issueInvoice(db,token,id,req.body.version,key)});return;}
      res.status(action==='create'?201:200).json({invoice:await saveInvoice(db,token,action==='create'?null:id,req.body,key)});
    }catch(e){if(e instanceof QuoteError){res.status(e.status).json({error:e.code});return;}next(e);}
  };
  app.get('/api/v1/invoices',invoiceRoute('list'));
  app.get('/api/v1/invoices/:id/pdf',invoiceRoute('pdf'));
  app.get('/api/v1/invoices/:id',invoiceRoute('read'));
  app.post('/api/v1/invoices',invoiceRoute('create'));
  app.post('/api/v1/invoices/from-quote/:id',invoiceRoute('convert'));
  app.post('/api/v1/invoices/:id/update',invoiceRoute('update'));
  app.post('/api/v1/invoices/:id/issue',invoiceRoute('issue'));

  app.get('/api/v1/company/members', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const members = await findMyCompanyMembers(database, user.id);
      res.status(200).json({ members });
    } catch (error) { next(error); }
  });

  app.post('/api/v1/company/invitations/preview', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      res.status(200).json({ invitation: await previewCompanyInvitation(database, user.id, req.body) });
    } catch (error) {
      if (error instanceof InvitationAcceptanceError) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  });

  app.post('/api/v1/company/invitations/accept', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      await acceptCompanyInvitation({ connect: database.connect.bind(database) }, user.id, req.body);
      res.status(204).end();
    } catch (error) {
      if (error instanceof InvitationAcceptanceError) {
        res.status(error.message === 'unauthorized' ? 401 : error.message === 'company_already_exists' ? 409 : 400).json({ error: error.message }); return;
      }
      next(error);
    }
  });

  app.post('/api/v1/company/invitations', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    const transport = options.invitationMailTransport ?? options.devMailbox;
    if (!transport) {
      res.status(503).json({ error: 'service_unavailable' }); return;
    }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      await createCompanyInvitation({ connect: database.connect.bind(database) }, user.id, req.body, transport, options.webOrigin ?? 'http://127.0.0.1:5173');
      res.status(202).json({ status: 'accepted' });
    } catch (error) {
      if (error instanceof InvitationForbiddenError) { res.status(403).json({ error: 'invitation_forbidden' }); return; }
      if (error instanceof InvitationAlreadyPendingError || error instanceof InvitationRecentlySentError) { res.status(409).json({ error: error.message }); return; }
      if (error instanceof InvitationRecipientAlreadyAssignedError) { res.status(409).json({ error: 'invitation_recipient_already_assigned' }); return; }
      if (error instanceof Error && ['invalid_invitation_input', 'invalid_invitation_email', 'invalid_invitation_role', 'invitation_self_forbidden'].includes(error.message)) { res.status(400).json({ error: error.message }); return; }
      next(error);
    }
  });

  app.get('/api/v1/company/invitations', async (req, res, next) => {
    if (!database) { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      const invitations = await listMyCompanyInvitations(database, user.id);
      res.status(200).json({ invitations });
    } catch (error) {
      if (error instanceof InvitationForbiddenError) { res.status(403).json({ error: 'invitation_forbidden' }); return; }
      next(error);
    }
  });

  app.post('/api/v1/company/invitations/:id/revoke', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') { res.status(503).json({ error: 'database_unavailable' }); return; }
    const token = parseSessionToken(req.headers.cookie);
    if (!token) { res.status(401).json({ error: 'unauthorized' }); return; }
    try {
      const user = await lookupSessionUser(database, token);
      if (!user) { res.status(401).json({ error: 'unauthorized' }); return; }
      await revokeCompanyInvitation({ connect: database.connect.bind(database) }, user.id, req.params.id);
      res.status(204).end();
    } catch (error) {
      if (error instanceof InvitationForbiddenError) { res.status(403).json({ error: 'invitation_forbidden' }); return; }
      if (error instanceof InvitationNotFoundError) { res.status(404).json({ error: 'invitation_not_found' }); return; }
      next(error);
    }
  });

  // Both request endpoints use generic 202 for existing and absent addresses.
  for (const [path, purpose] of [
    ['/api/v1/auth/verification/request', 'EMAIL_VERIFICATION'],
    ['/api/v1/auth/password-reset/request', 'PASSWORD_RESET']
  ] as const) {
    app.post(path, async (req, res, next) => {
      if (!database || typeof database.connect !== 'function' || !options.mailTransport) {
        res.status(503).json({ error: 'service_unavailable' });
        return;
      }
      try {
        await requestEmailAction(
          { connect: database.connect.bind(database) }, options.mailTransport, purpose,
          req.body, options.webOrigin ?? 'http://127.0.0.1:5173'
        );
        res.status(202).json({ status: 'accepted' });
      } catch (error) {
        if (error instanceof Error && error.message === 'invalid_email_request') {
          res.status(400).json({ error: 'invalid_email_request' });
          return;
        }
        next(error);
      }
    });
  }

  app.post('/api/v1/auth/verification/confirm', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    try {
      await verifyEmail({ connect: database.connect.bind(database) }, req.body);
      res.status(200).json({ status: 'verified' });
    } catch (error) {
      if (error instanceof InvalidOrExpiredActionTokenError) {
        res.status(400).json({ error: 'invalid_or_expired_token' });
        return;
      }
      if (error instanceof Error && error.message === 'invalid_action_input') {
        res.status(400).json({ error: 'invalid_action_input' });
        return;
      }
      next(error);
    }
  });

  app.post('/api/v1/auth/password-reset/confirm', async (req, res, next) => {
    if (!database || typeof database.connect !== 'function') {
      res.status(503).json({ error: 'database_unavailable' });
      return;
    }
    try {
      await confirmPasswordReset({ connect: database.connect.bind(database) }, req.body);
      res.setHeader('Set-Cookie', [expiredSessionCookie(secureCookie), expiredLegacySessionCookie(secureCookie)]);
      res.status(204).end();
    } catch (error) {
      if (error instanceof InvalidOrExpiredActionTokenError) {
        res.status(400).json({ error: 'invalid_or_expired_token' });
        return;
      }
      if (error instanceof Error && ['invalid_action_input', 'invalid_password_length'].includes(error.message)) {
        res.status(400).json({ error: error.message });
        return;
      }
      next(error);
    }
  });

  // Opt-in only, local-only in-memory developer mailbox. NEVER publicly enabled.
  if (options.enableDevMailbox && options.devMailbox && process.env.NODE_ENV !== 'production') {
    app.get('/api/v1/auth/dev-mailbox', (req, res) => {
      const ip = req.socket.remoteAddress;
      if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(ip ?? '')) {
        res.status(404).json({ error: 'not_found' });
        return;
      }
      res.status(200).json({ messages: options.devMailbox!.list() });
    });
  }

  app.use((_req, res) => {
    res.status(404).json({ error: 'not_found' });
  });

  const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
    if (error && typeof error === 'object' && 'type' in error) {
      if (error.type === 'entity.parse.failed') {
        res.status(400).json({ error: 'invalid_json' });
        return;
      }
      if (error.type === 'entity.too.large') {
        res.status(413).json({ error: 'payload_too_large' });
        return;
      }
    }
    res.status(500).json({ error: 'internal_server_error' });
  };
  app.use(errorHandler);
  return app;
}
