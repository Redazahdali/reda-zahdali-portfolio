/** Presentation only: never parse through a floating-point number or round. */
export function displayQuantity(value: string): string {
  if (!/^[+-]?\d+(?:[.,]\d+)?$/.test(value)) return value;
  const [whole, fraction] = value.replace(',', '.').split('.');
  const significant = fraction?.replace(/0+$/, '');
  return significant ? `${whole},${significant}` : whole!;
}

export function selectedClientAfterTyping(text: string, selected: { id: string; display_name: string } | null) {
  return selected && text === selected.display_name ? selected : null;
}

export function searchRequestGuard() {
  let active = true;
  return { isCurrent: () => active, cancel: () => { active = false; } };
}

export function replaceDocumentItem<T extends {catalogItemId:string|null;name:string;description:string;unit:string}>(line:T,item:{id:string;name:string;description:string;unit:string}):T {
  return {...line,catalogItemId:item.id,name:item.name,description:item.description,unit:item.unit};
}
