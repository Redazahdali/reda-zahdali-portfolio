import { createHash } from 'node:crypto';
import type { RegistrationClient, RegistrationDatabase } from '../auth/registration-service.js';
import { quoteScope, quoteTransaction, validateQuote, QuoteError } from './quote-service.js';
import { calculateQuoteLine } from './quote-calculation.js';
import {schemaAvailable,visualForCompany} from './document-identity.js';
import {renderInvoicePdf} from './quote-pdf.js';

type Db=Pick<RegistrationDatabase,'connect'>;
type Row=Record<string,any>;
const uuid=(v:unknown):v is string=>typeof v==='string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
const invalid=()=>new QuoteError('invalid_invoice',400);
const cents=(v:string)=>BigInt(v.replace('.',''));
const money=(v:bigint)=>`${v/100n}.${String(v%100n).padStart(2,'0')}`;
async function detail(c:RegistrationClient,company:string,id:string):Promise<Row>{
  const row=(await c.query('SELECT i.*,i.issued_on::text AS issued_on FROM invoices i WHERE company_id=$1 AND id=$2',[company,id])).rows[0] as Row|undefined;
  if(!row)throw new QuoteError('not_found',404);
  row.lines=(await c.query('SELECT * FROM invoice_lines WHERE company_id=$1 AND invoice_id=$2 ORDER BY position',[company,id])).rows; return row;
}
async function receipt(c:RegistrationClient,company:string,actor:string,action:string,key:string,fingerprint:string){
  const row=(await c.query('SELECT fingerprint,result FROM invoice_receipts WHERE company_id=$1 AND actor_id=$2 AND action=$3 AND idempotency_key=$4',[company,actor,action,key])).rows[0] as Row|undefined;
  if(row&&row.fingerprint!==fingerprint)throw new QuoteError('invoice_conflict',409);return row?.result;
}
const checkedKey=(key:string)=>{if(!/^[A-Za-z0-9_-]{16,100}$/.test(key))throw invalid();};
const digest=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
async function finish(c:RegistrationClient,s:Row,id:string,action:string,key:string,fp:string,kind:string){
  const result=await detail(c,s.id,id); await c.query('INSERT INTO invoice_history(company_id,invoice_id,actor_id,event_type,details) VALUES($1,$2,$3,$4,$5)',[s.id,id,s.user_id,kind,JSON.stringify({version:result.version})]);
  await c.query('INSERT INTO invoice_receipts(company_id,actor_id,action,idempotency_key,fingerprint,result) VALUES($1,$2,$3,$4,$5,$6)',[s.id,s.user_id,action,key,fp,JSON.stringify(result)]);return result;
}
export async function listInvoices(db:Db,token:string,search:string,status:string,limit:number,offset:number,sourceQuoteId:string|null=null){
  if(search.length>200||!['all','DRAFT','ISSUED'].includes(status)||!Number.isInteger(limit)||limit<1||limit>100||!Number.isInteger(offset)||offset<0||offset>100000||(sourceQuoteId!==null&&!uuid(sourceQuoteId)))throw invalid();
  return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);return (await c.query(`SELECT id,status,invoice_number,issued_on::text AS issued_on,client_snapshot,total_net,total_tax,total_gross,version,created_at
    FROM invoices WHERE company_id=$1 AND ($2='' OR position(lower($2) in lower(coalesce(invoice_number,'')||' '||coalesce(client_snapshot->>'display_name','')))>0) AND ($3='all' OR status=$3) AND ($6::uuid IS NULL OR source_quote_id=$6::uuid) ORDER BY created_at DESC,id DESC LIMIT $4 OFFSET $5`,[s.id,search,status,limit,offset,sourceQuoteId])).rows;});
}
export async function readInvoice(db:Db,token:string,id:string){if(!uuid(id))throw invalid();return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);return detail(c,s.id,id);});}
export async function readInvoiceDocument(db:Db,token:string,id:string){if(!uuid(id))throw invalid();return quoteTransaction(db,async c=>{const s=await quoteScope(c,token),invoice=await detail(c,s.id,id);if(!await schemaAvailable(c))return {invoice};if(invoice.status==='ISSUED'){const archive=(await c.query('SELECT pdf_bytes FROM invoice_pdf_archives WHERE company_id=$1 AND invoice_id=$2',[s.id,id])).rows[0] as Row|undefined;return {invoice,pdf:archive?.pdf_bytes as Buffer|undefined};}return {invoice,visual:await visualForCompany(c,s.id)};});}
export async function saveInvoice(db:Db,token:string,id:string|null,input:unknown,key:string){
  checkedKey(key); if(id&&!uuid(id))throw invalid(); if(!input||typeof input!=='object'||Array.isArray(input))throw invalid();
  const data=input as Row; if(Object.keys(data).some(k=>!['partyId','subject','notes','terms','version','lines'].includes(k)))throw invalid();
  let b;try{b=validateQuote({...data,issuedOn:'2000-01-01',validUntil:'2000-01-01'});}catch{throw invalid();}
  if(id&&(!Number.isInteger(b.version)||b.version<1))throw invalid(); const action=id?'update':'create',fp=digest({id,b});
  return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);const oldReceipt=await receipt(c,s.id,s.user_id,action,key,fp);if(oldReceipt)return oldReceipt;
    let previous:Row|undefined;if(id){previous=(await c.query('SELECT * FROM invoices WHERE company_id=$1 AND id=$2 FOR UPDATE',[s.id,id])).rows[0] as Row|undefined;if(!previous)throw new QuoteError('not_found',404);if(previous.status!=='DRAFT'||previous.version!==b.version)throw new QuoteError('invoice_conflict',409);}
    const client=(await c.query(`SELECT id,display_name,contact_name,address,city,postal_code,phone,email,ice FROM parties WHERE company_id=$1 AND id=$2 AND is_client AND (status='ACTIVE' OR id=$3::uuid) FOR SHARE`,[s.id,b.partyId,previous?.party_id??null])).rows[0];if(!client)throw new QuoteError('invalid_client',400);
    const ids=[...new Set(b.lines.map(l=>l.catalogItemId).filter((v):v is string=>v!==null))];const valid=await c.query(`SELECT i.id FROM catalog_items i WHERE i.company_id=$1 AND i.id=ANY($2::uuid[]) AND (i.active OR EXISTS(SELECT 1 FROM invoice_lines l WHERE l.company_id=$1 AND l.invoice_id=$3::uuid AND l.catalog_item_id=i.id)) FOR SHARE OF i`,[s.id,ids,id]);if(valid.rows.length!==ids.length)throw new QuoteError('invalid_catalog_item',400);
    let net=0n,tax=0n;for(const l of b.lines){net+=cents(l.net);tax+=cents(l.tax);}if(net+tax>999999999999999999n)throw invalid();let invoiceId=id;
    if(!id){invoiceId=((await c.query(`INSERT INTO invoices(company_id,party_id,subject,notes,terms,issuer_snapshot,client_snapshot,total_net,total_tax,total_gross) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,[s.id,b.partyId,b.subject,b.notes,b.terms,JSON.stringify({name:s.name}),JSON.stringify(client),money(net),money(tax),money(net+tax)])).rows[0] as Row).id;}
    else {await c.query(`UPDATE invoices SET party_id=$3,subject=$4,notes=$5,terms=$6,client_snapshot=$7,total_net=$8,total_tax=$9,total_gross=$10,version=version+1,updated_at=now() WHERE company_id=$1 AND id=$2`,[s.id,id,b.partyId,b.subject,b.notes,b.terms,JSON.stringify(previous!.party_id===b.partyId?previous!.client_snapshot:client),money(net),money(tax),money(net+tax)]);await c.query('DELETE FROM invoice_lines WHERE company_id=$1 AND invoice_id=$2',[s.id,id]);}
    for(let i=0;i<b.lines.length;i++){const l=b.lines[i]!;await c.query(`INSERT INTO invoice_lines(company_id,invoice_id,catalog_item_id,position,item_snapshot,quantity,unit_price,discount_rate,tax_rate,net_amount,tax_amount) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[s.id,invoiceId,l.catalogItemId,i+1,JSON.stringify({name:l.name,description:l.description,unit:l.unit}),l.quantity,l.unitPrice,l.discountRate,l.taxRate,l.net,l.tax]);}
    return finish(c,s,invoiceId!,action,key,fp,id?'UPDATED':'CREATED');
  });
}
export async function convertQuote(db:Db,token:string,quoteId:string,key:string){
  checkedKey(key);if(!uuid(quoteId))throw invalid();const action='convert',fp=digest({quoteId});
  return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);const old=await receipt(c,s.id,s.user_id,action,key,fp);if(old)return old;
    const q=(await c.query('SELECT * FROM quotes WHERE company_id=$1 AND id=$2 FOR SHARE',[s.id,quoteId])).rows[0] as Row|undefined;if(!q)throw new QuoteError('not_found',404);
    const lines=await c.query('SELECT * FROM quote_lines WHERE company_id=$1 AND quote_id=$2 ORDER BY position',[s.id,quoteId]);if(!lines.rows.length||!q.quote_number||!q.subject)throw invalid();
    let net=0n,tax=0n;for(const raw of lines.rows){const l=raw as Row;let result;try{result=calculateQuoteLine({quantity:l.quantity,unitPrice:l.unit_price,discountRate:l.discount_rate,taxRate:l.tax_rate});}catch{throw invalid();}if(result.net!==l.net_amount||result.tax!==l.tax_amount)throw new QuoteError('quote_totals_inconsistent',409);net+=cents(result.net);tax+=cents(result.tax);}
    if(money(net)!==q.total_net||money(tax)!==q.total_tax||money(net+tax)!==q.total_gross)throw new QuoteError('quote_totals_inconsistent',409);
    const id=((await c.query(`INSERT INTO invoices(company_id,party_id,source_quote_id,source_quote_number,subject,notes,terms,issuer_snapshot,client_snapshot,total_net,total_tax,total_gross) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,[s.id,q.party_id,quoteId,q.quote_number,q.subject,q.notes,q.terms,JSON.stringify(q.issuer_snapshot),JSON.stringify(q.client_snapshot),q.total_net,q.total_tax,q.total_gross])).rows[0] as Row).id;
    for(const raw of lines.rows){const l=raw as Row;await c.query(`INSERT INTO invoice_lines(company_id,invoice_id,catalog_item_id,position,item_snapshot,quantity,unit_price,discount_rate,tax_rate,net_amount,tax_amount) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[s.id,id,l.catalog_item_id,l.position,JSON.stringify(l.item_snapshot),l.quantity,l.unit_price,l.discount_rate,l.tax_rate,l.net_amount,l.tax_amount]);}
    return finish(c,s,id,action,key,fp,'CREATED_FROM_QUOTE');});
}
export async function issueInvoice(db:Db,token:string,id:string,version:unknown,key:string){
  checkedKey(key);if(!uuid(id)||!Number.isInteger(version)||(version as number)<1)throw invalid();const action='issue',fp=digest({id,version});
  return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);const old=await receipt(c,s.id,s.user_id,action,key,fp);if(old)return old;
    const q=(await c.query('SELECT status,version FROM invoices WHERE company_id=$1 AND id=$2 FOR UPDATE',[s.id,id])).rows[0] as Row|undefined;
    if(!q)throw new QuoteError('not_found',404);if(q.status!=='DRAFT'||q.version!==version)throw new QuoteError('invoice_conflict',409);
    const n=((await c.query(`INSERT INTO invoice_counters(company_id,next_number) VALUES($1,2) ON CONFLICT(company_id) DO UPDATE SET next_number=invoice_counters.next_number+1 RETURNING next_number-1 n`,[s.id])).rows[0] as Row).n;
    await c.query(`UPDATE invoices SET status='ISSUED',invoice_number=$3,issued_on=(clock_timestamp() AT TIME ZONE 'Africa/Casablanca')::date,version=version+1,updated_at=now() WHERE company_id=$1 AND id=$2`,[s.id,id,`FAC-${String(n).padStart(6,'0')}`]);
    if(await schemaAvailable(c)){
      const visual=await visualForCompany(c,s.id),invoice=await detail(c,s.id,id),pdf=await renderInvoicePdf(invoice,visual);
      await c.query('INSERT INTO invoice_pdf_archives(company_id,invoice_id,template_version,visual_snapshot,pdf_bytes) VALUES($1,$2,$3,$4,$5)',[s.id,id,'ENT06D-1',JSON.stringify({palette:visual.palette,colors:visual.colors,logoId:visual.logoId}),pdf]);
    }
    return finish(c,s,id,action,key,fp,'ISSUED');});
}
