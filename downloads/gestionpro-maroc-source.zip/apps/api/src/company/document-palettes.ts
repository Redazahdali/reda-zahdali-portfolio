export const DOCUMENT_PALETTES = {
  EMERALD:{label:'Vert émeraude',primary:'#175b39',accent:'#237a4c',light:'#edf7ef'},
  ROYAL_BLUE:{label:'Bleu royal',primary:'#224d92',accent:'#315fa8',light:'#eff4fb'},
  ELEGANT_BLACK:{label:'Noir élégant',primary:'#222222',accent:'#444444',light:'#f3f3f3'},
  SOLAR_YELLOW:{label:'Jaune solaire',primary:'#634900',accent:'#8a6500',light:'#fff8d9'},
  GRAPHITE_GRAY:{label:'Gris graphite',primary:'#414c55',accent:'#596670',light:'#f0f3f5'},
  BORDEAUX:{label:'Bordeaux',primary:'#722b3e',accent:'#934155',light:'#fbf0f3'},
  DYNAMIC_ORANGE:{label:'Orange dynamique',primary:'#8a3b0c',accent:'#a94b11',light:'#fff3ea'},
  PREMIUM_PURPLE:{label:'Violet premium',primary:'#59367e',accent:'#73519a',light:'#f5f0fa'},
  TURQUOISE:{label:'Turquoise',primary:'#075a61',accent:'#087681',light:'#eaf8f8'},
  NAVY_GOLD:{label:'Bleu nuit et or',primary:'#193659',accent:'#8a660f',light:'#f4f3e9'}
} as const;
export type PaletteId=keyof typeof DOCUMENT_PALETTES;
export function isPalette(value:unknown):value is PaletteId{return typeof value==='string'&&Object.hasOwn(DOCUMENT_PALETTES,value);}
export const DEFAULT_PALETTE:PaletteId='EMERALD';
