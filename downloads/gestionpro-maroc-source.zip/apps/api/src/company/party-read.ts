import type { AuthQueryDatabase } from '../auth/login-service.js';

/** Tenant and authorization are derived again in the query, not from the client. */
export async function listParties(db: AuthQueryDatabase, userId: string, input: { search: string; role: string; status?: string; limit: number | null; offset: number }): Promise<unknown[]> {
  const result = await db.query(`SELECT p.id, p.kind, p.status, p.display_name, p.contact_name,
      p.is_client, p.is_supplier, p.city, p.phone, p.ice, p.version, p.created_at, p.updated_at
    FROM public.parties p
    JOIN public.companies c ON c.id = p.company_id AND c.status = 'ACTIVE'
    JOIN public.company_memberships m ON m.company_id = c.id AND m.user_id = $1 AND m.status = 'ACTIVE'
    JOIN public.users u ON u.id = m.user_id AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
    WHERE ($2 = '' OR p.display_name ILIKE '%' || replace(replace(replace($2, E'\\\\', E'\\\\\\\\'), '%', E'\\\\%'), '_', E'\\\\_') || '%' ESCAPE E'\\\\')
      AND ($3 = 'all' OR ($3 = 'client' AND p.is_client) OR ($3 = 'supplier' AND p.is_supplier))
      AND ($6 = 'all' OR p.status = $6)
    ORDER BY p.created_at DESC, p.id DESC LIMIT $4 OFFSET $5`, [userId, input.search, input.role, input.limit, input.offset, input.status ?? 'all']);
  return result.rows;
}

export async function getParty(db: AuthQueryDatabase, userId: string, partyId: string): Promise<unknown | null> {
  const result = await db.query(`SELECT p.id, p.kind, p.status, p.display_name, p.contact_name,
    p.is_client, p.is_supplier, p.phone, p.email, p.address, p.city, p.postal_code,
    p.ice, p.tax_id, p.trade_register, p.professional_tax, p.country_code, p.version, p.created_at, p.updated_at
    FROM public.parties p JOIN public.companies c ON c.id = p.company_id AND c.status = 'ACTIVE'
    JOIN public.company_memberships m ON m.company_id = c.id AND m.user_id = $1 AND m.status = 'ACTIVE'
    JOIN public.users u ON u.id = m.user_id AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
    WHERE p.id = $2`, [userId, partyId]);
  return result.rows[0] ?? null;
}
