import {createHash} from 'node:crypto';
import sharp from 'sharp';
import type {RegistrationClient,RegistrationDatabase} from '../auth/registration-service.js';
import {quoteScope,quoteTransaction,QuoteError} from './quote-service.js';
import {DEFAULT_PALETTE,DOCUMENT_PALETTES,isPalette,type PaletteId} from './document-palettes.js';

type Db=Pick<RegistrationDatabase,'connect'>;
type Row=Record<string,any>;
export type DocumentVisual={palette:PaletteId;colors:(typeof DOCUMENT_PALETTES)[PaletteId];logo:Buffer|null;logoId:string|null};
export async function schemaAvailable(c:RegistrationClient){const row=(await c.query("SELECT to_regclass('public.company_document_identity') AS identity, to_regclass('public.invoice_pdf_archives') AS archives")).rows[0] as Row|undefined;if(!!row?.identity!==!!row?.archives)throw new QuoteError('document_identity_unavailable',503);return !!row?.identity&&!!row?.archives;}
export async function visualForCompany(c:RegistrationClient,company:string):Promise<DocumentVisual>{
  const row=(await c.query(`SELECT i.palette,i.logo_id,l.png_bytes FROM company_document_identity i LEFT JOIN company_document_logos l ON l.company_id=i.company_id AND l.id=i.logo_id WHERE i.company_id=$1`,[company])).rows[0] as Row|undefined;
  const palette=row?.palette??DEFAULT_PALETTE;if(!isPalette(palette))throw new Error('invalid_stored_palette');
  return {palette,colors:DOCUMENT_PALETTES[palette],logo:row?.png_bytes??null,logoId:row?.logo_id??null};
}
export async function normalizeLogo(input:Buffer):Promise<Buffer>{
  if(!Buffer.isBuffer(input)||input.length<12||input.length>2_000_000)throw new QuoteError('invalid_logo',400);
  const format=input.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))?'png':input[0]===255&&input[1]===216&&input[2]===255?'jpeg':input.toString('ascii',0,4)==='RIFF'&&input.toString('ascii',8,12)==='WEBP'?'webp':null;
  if(!format)throw new QuoteError('invalid_logo',400);
  try{
    const img=sharp(input,{limitInputPixels:8_000_000,animated:false,failOn:'warning'}),meta=await img.metadata();
    if(meta.format!==format||!meta.width||!meta.height||meta.width>4096||meta.height>4096||(meta.pages??1)!==1)throw new Error('invalid');
    const png=await img.rotate().png().toBuffer();if(png.length>2_000_000)throw new Error('large');return png;
  }catch{throw new QuoteError('invalid_logo',400);}
}
function requireManager(s:Row){if(!['OWNER','MANAGER'].includes(s.role))throw new QuoteError('forbidden',403);}
export async function getIdentity(db:Db,token:string){return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);if(!await schemaAvailable(c))throw new QuoteError('document_identity_unavailable',503);const v=await visualForCompany(c,s.id);return {palette:v.palette,hasLogo:!!v.logo,canManage:['OWNER','MANAGER'].includes(s.role),palettes:DOCUMENT_PALETTES};});}
export async function getLogo(db:Db,token:string){return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);if(!await schemaAvailable(c))throw new QuoteError('document_identity_unavailable',503);return (await visualForCompany(c,s.id)).logo;});}
export async function getDocumentVisual(db:Db,token:string){return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);return await schemaAvailable(c)?visualForCompany(c,s.id):undefined;});}
export async function saveIdentity(db:Db,token:string,palette:unknown,removeLogo:unknown){
  if(!isPalette(palette)||typeof removeLogo!=='boolean')throw new QuoteError('invalid_document_identity',400);
  return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);requireManager(s);if(!await schemaAvailable(c))throw new QuoteError('document_identity_unavailable',503);
    const before=await visualForCompany(c,s.id),logoId=removeLogo?null:before.logoId;
    await c.query(`INSERT INTO company_document_identity(company_id,palette,logo_id) VALUES($1,$2,$3) ON CONFLICT(company_id) DO UPDATE SET palette=EXCLUDED.palette,logo_id=EXCLUDED.logo_id,updated_at=now()`,[s.id,palette,logoId]);
    await c.query('INSERT INTO company_document_identity_history(company_id,actor_id,palette,logo_id) VALUES($1,$2,$3,$4)',[s.id,s.user_id,palette,logoId]);return {palette,hasLogo:!!logoId};});
}
export async function saveLogo(db:Db,token:string,input:Buffer){return quoteTransaction(db,async c=>{const s=await quoteScope(c,token);requireManager(s);if(!await schemaAvailable(c))throw new QuoteError('document_identity_unavailable',503);
  const png=await normalizeLogo(input),hash=createHash('sha256').update(png).digest('hex'),old=await visualForCompany(c,s.id);
  const logo=(await c.query('INSERT INTO company_document_logos(company_id,png_bytes,sha256) VALUES($1,$2,$3) RETURNING id',[s.id,png,hash])).rows[0] as Row;
  await c.query(`INSERT INTO company_document_identity(company_id,palette,logo_id) VALUES($1,$2,$3) ON CONFLICT(company_id) DO UPDATE SET logo_id=EXCLUDED.logo_id,updated_at=now()`,[s.id,old.palette,logo.id]);
  await c.query('INSERT INTO company_document_identity_history(company_id,actor_id,palette,logo_id) VALUES($1,$2,$3,$4)',[s.id,s.user_id,old.palette,logo.id]);return {palette:old.palette,hasLogo:true};});}
