/** Curated search aliases; these do not assert identity or validate input. */
export const PARTY_DICTIONARY_VERSION = '1.0.0';
export const PARTY_SEARCH_ALIASES: Readonly<Record<string, string>> = {
  ste: 'societe', societe: 'societe',
  casablanca: 'casablanca', 'الدارالبيضاء': 'casablanca',
  rabat: 'rabat', 'الرباط': 'rabat',
};
