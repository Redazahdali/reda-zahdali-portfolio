import { createHash } from 'node:crypto';
import type { RegistrationClient, RegistrationDatabase } from '../auth/registration-service.js';
import { digestSessionToken } from '../auth/login-service.js';
import { calculateQuoteLine } from './quote-calculation.js';

type Db = Pick<RegistrationDatabase, 'connect'>;
type Row = Record<string, any>;
export class QuoteError extends Error { constructor(public code: string, public status: number) { super(code); } }
const invalid = () => new QuoteError('invalid_quote', 400);
const uuid = (s: unknown): s is string => typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
const cents = (s: string) => BigInt(s.replace('.', ''));
const amount = (n: bigint) => `${n / 100n}.${String(n % 100n).padStart(2,'0')}`;
function text(v: unknown, max: number, required = false, multiline = false): string {
  if (typeof v !== 'string' || /[\p{Cc}\p{Cs}]/u.test(multiline ? v.replace(/\r?\n/g,'') : v)) throw invalid();
  const s = v.trim(); if (Array.from(s).length > max || (required && !s)) throw invalid(); return s;
}
function date(v: unknown): string {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(Date.parse(v)) || new Date(v).toISOString().slice(0,10) !== v) throw invalid();
  return v;
}
export function validateQuote(body: unknown) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw invalid();
  const b = body as Row;
  if (Object.keys(b).some(k => !['partyId','issuedOn','validUntil','subject','notes','terms','version','lines'].includes(k)) || !uuid(b.partyId) || !Array.isArray(b.lines) || b.lines.length < 1 || b.lines.length > 200) throw invalid();
  const issuedOn = date(b.issuedOn), validUntil = date(b.validUntil); if (validUntil < issuedOn) throw invalid();
  const lines = b.lines.map((v: unknown) => {
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw invalid();
    const l = v as Row;
    if (Object.keys(l).some(k => !['catalogItemId','name','description','unit','quantity','unitPrice','discountRate','taxRate'].includes(k)) || (l.catalogItemId !== null && !uuid(l.catalogItemId))) throw invalid();
    const name = text(l.name,200,true), description = text(l.description,2000,false,true), unit = text(l.unit,50,true);
    let result; try { result = calculateQuoteLine({quantity:l.quantity,unitPrice:l.unitPrice,discountRate:l.discountRate,taxRate:l.taxRate}); } catch { throw invalid(); }
    return { catalogItemId:l.catalogItemId, name, description, unit, quantity:l.quantity, unitPrice:l.unitPrice, discountRate:l.discountRate, taxRate:l.taxRate, ...result };
  });
  return { partyId:b.partyId as string, issuedOn, validUntil, subject:text(b.subject,500,true), notes:text(b.notes,5000,false,true), terms:text(b.terms,5000,false,true), version:b.version, lines };
}
export async function quoteTransaction<T>(db: Db, fn: (c: RegistrationClient) => Promise<T>): Promise<T> {
  const c = await db.connect(); try { await c.query('BEGIN'); const r = await fn(c); await c.query('COMMIT'); return r; }
  catch (e) { await c.query('ROLLBACK').catch(() => undefined); throw e; } finally { c.release(); }
}
export async function quoteScope(c: RegistrationClient, token: string) {
  if (!/^[A-Za-z0-9_-]{43}$/.test(token)) throw new QuoteError('unauthorized',401);
  const r = await c.query(`SELECT co.id,co.name,m.user_id,m.role FROM auth_sessions s JOIN users u ON u.id=s.user_id
    JOIN company_memberships m ON m.user_id=u.id JOIN companies co ON co.id=m.company_id
    WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL
    AND m.status='ACTIVE' AND co.status='ACTIVE' FOR UPDATE OF co FOR SHARE OF s,u,m`,[digestSessionToken(token)]);
  if (!r.rows.length) throw new QuoteError('unauthorized',401);
  if (r.rows.length !== 1 || !['OWNER','MANAGER','EMPLOYEE'].includes((r.rows[0] as Row).role)) throw new QuoteError('forbidden',403);
  return r.rows[0] as Row;
}
async function detail(c: RegistrationClient, companyId: string, id: string): Promise<Row> {
  const q = (await c.query('SELECT q.*, q.issued_on::text AS issued_on, q.valid_until::text AS valid_until FROM quotes q WHERE company_id=$1 AND id=$2',[companyId,id])).rows[0] as Row | undefined;
  if (!q) throw new QuoteError('not_found',404);
  q.lines = (await c.query('SELECT * FROM quote_lines WHERE company_id=$1 AND quote_id=$2 ORDER BY position',[companyId,id])).rows;
  return q;
}
export async function readQuote(db: Db, token: string, id: string) { if (!uuid(id)) throw invalid(); return quoteTransaction(db, async c => {const s=await quoteScope(c,token); return detail(c,s.id,id);}); }
export async function listQuotes(db: Db, token: string, search: string, status: string, limit: number, offset: number) {
  if (search.length>200 || !['all','DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED'].includes(status) || !Number.isInteger(limit) || limit<1 || limit>100 || !Number.isInteger(offset) || offset<0 || offset>100000) throw invalid();
  return quoteTransaction(db, async c => { const s=await quoteScope(c,token); return (await c.query(`SELECT id,quote_number,status,client_snapshot,issued_on::text AS issued_on,valid_until::text AS valid_until,total_net,total_tax,total_gross,version,created_at
    FROM quotes WHERE company_id=$1 AND ($2='' OR position(lower($2) in lower(coalesce(quote_number,'') || ' ' || coalesce(client_snapshot->>'display_name',''))) > 0)
    AND ($3='all' OR status=$3) ORDER BY created_at DESC,id DESC LIMIT $4 OFFSET $5`,[s.id,search,status,limit,offset])).rows; });
}
export async function previewQuote(db: Db, token: string, input: unknown) {
  if (!Array.isArray(input) || input.length<1 || input.length>200) throw invalid();
  return quoteTransaction(db, async c => { await quoteScope(c,token); let net=0n,tax=0n,discount=0n;
    const lines=input.map(v => { if (!v || typeof v!=='object' || Array.isArray(v)) throw invalid();
      const l=v as Row; let r; try {r=calculateQuoteLine({quantity:l.quantity,unitPrice:l.unitPrice,discountRate:l.discountRate,taxRate:l.taxRate});} catch {throw invalid();}
      let undiscounted; try {undiscounted=calculateQuoteLine({quantity:l.quantity,unitPrice:l.unitPrice,discountRate:'0',taxRate:'0'});} catch {throw invalid();}
      net+=cents(r.net); tax+=cents(r.tax); discount+=cents(undiscounted.net)-cents(r.net); return r; });
    if (net+tax>999999999999999999n) throw invalid();
    return {lines,net:amount(net),tax:amount(tax),discount:amount(discount),total:amount(net+tax)};
  });
}
export async function saveQuote(db: Db, token: string, id: string | null, input: unknown, key: string) {
  if ((id && !uuid(id)) || !/^[A-Za-z0-9_-]{16,100}$/.test(key)) throw invalid();
  const b=validateQuote(input); if (id && (!Number.isInteger(b.version) || b.version<1)) throw invalid();
  const fingerprint=createHash('sha256').update(JSON.stringify({id,b})).digest('hex');
  return quoteTransaction(db, async c => {
    const s=await quoteScope(c,token), action=id ? 'update' : 'create';
    const receipt=(await c.query('SELECT fingerprint,result FROM quote_receipts WHERE company_id=$1 AND actor_id=$2 AND action=$3 AND idempotency_key=$4',[s.id,s.user_id,action,key])).rows[0] as Row | undefined;
    if (receipt) { if (receipt.fingerprint!==fingerprint) throw new QuoteError('quote_conflict',409); return receipt.result; }
    let previous: Row | undefined;
    if (id) { previous=(await c.query('SELECT * FROM quotes WHERE company_id=$1 AND id=$2 FOR UPDATE',[s.id,id])).rows[0] as Row | undefined;
      if (!previous) throw new QuoteError('not_found',404); if (previous.status!=='DRAFT' || previous.version!==b.version) throw new QuoteError('quote_conflict',409); }
    const client=(await c.query(`SELECT id,display_name,contact_name,address,city,postal_code,phone,email,ice FROM parties WHERE company_id=$1 AND id=$2 AND is_client AND (status='ACTIVE' OR id=$3::uuid) FOR SHARE`,[s.id,b.partyId,previous?.party_id ?? null])).rows[0];
    if (!client) throw new QuoteError('invalid_client',400);
    const ids=[...new Set(b.lines.map(l=>l.catalogItemId).filter((id): id is string => id !== null))];
    const catalog=await c.query(`SELECT i.id FROM catalog_items i WHERE i.company_id=$1 AND i.id=ANY($2::uuid[]) AND (i.active OR EXISTS (SELECT 1 FROM quote_lines l WHERE l.company_id=$1 AND l.quote_id=$3::uuid AND l.catalog_item_id=i.id)) FOR SHARE OF i`,[s.id,ids,id]);
    if (catalog.rows.length!==ids.length) throw new QuoteError('invalid_catalog_item',400);
    let net=0n,tax=0n; for (const line of b.lines) { net+=cents(line.net); tax+=cents(line.tax); }
    if (net>999999999999999999n || tax>999999999999999999n || net+tax>999999999999999999n) throw invalid();
    let quoteId=id;
    if (!id) {
      const num=((await c.query(`INSERT INTO quote_counters(company_id,next_number) VALUES ($1,2) ON CONFLICT(company_id) DO UPDATE SET next_number=quote_counters.next_number+1 RETURNING next_number-1 AS n`,[s.id])).rows[0] as Row).n;
      quoteId=((await c.query(`INSERT INTO quotes(company_id,party_id,client_snapshot,issuer_snapshot,quote_number,issued_on,valid_until,subject,notes,terms,total_net,total_tax,total_gross)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`,[s.id,b.partyId,JSON.stringify(client),JSON.stringify({name:s.name}),`DEV-${String(num).padStart(6,'0')}`,b.issuedOn,b.validUntil,b.subject,b.notes,b.terms,amount(net),amount(tax),amount(net+tax)])).rows[0] as Row).id;
    } else {
      await c.query(`UPDATE quotes SET party_id=$3,client_snapshot=$4,issued_on=$5,valid_until=$6,subject=$7,notes=$8,terms=$9,total_net=$10,total_tax=$11,total_gross=$12,version=version+1,updated_at=now() WHERE company_id=$1 AND id=$2`,[s.id,id,b.partyId,JSON.stringify(previous!.party_id===b.partyId ? previous!.client_snapshot : client),b.issuedOn,b.validUntil,b.subject,b.notes,b.terms,amount(net),amount(tax),amount(net+tax)]);
      await c.query('DELETE FROM quote_lines WHERE company_id=$1 AND quote_id=$2',[s.id,id]);
    }
    for (let i=0;i<b.lines.length;i++) { const l=b.lines[i]!; await c.query(`INSERT INTO quote_lines(company_id,quote_id,catalog_item_id,position,item_snapshot,quantity,unit_price,discount_rate,tax_rate,net_amount,tax_amount)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[s.id,quoteId,l.catalogItemId,i+1,JSON.stringify({name:l.name,description:l.description,unit:l.unit}),l.quantity,l.unitPrice,l.discountRate,l.taxRate,l.net,l.tax]); }
    await c.query('INSERT INTO quote_history(company_id,quote_id,actor_id,event_type,details) VALUES($1,$2,$3,$4,$5)',[s.id,quoteId,s.user_id,id?'UPDATED':'CREATED',JSON.stringify({version:id ? b.version+1 : 1})]);
    const result=await detail(c,s.id,quoteId!); await c.query('INSERT INTO quote_receipts(company_id,actor_id,action,idempotency_key,fingerprint,result) VALUES($1,$2,$3,$4,$5,$6)',[s.id,s.user_id,action,key,fingerprint,JSON.stringify(result)]); return result;
  });
}
