/** Advisory findings do not authorize or apply changes. */
export interface Finding { code: string; fields: readonly string[]; reason: string; action: string }
export type DictionaryCategory = 'cities' | 'legal_forms' | 'commercial' | 'names' | 'accounting' | 'professions' | 'units' | 'business';
export interface Dictionary { category: DictionaryCategory; version: string; entries: readonly { canonical: string; aliases: readonly string[] }[] }

/** Generic vocabulary only, never derived from tenant data. */
export const dictionaries: readonly Dictionary[] = [
  { category: 'cities', version: '1.0.0', entries: [{ canonical: 'Casablanca', aliases: ['الدار البيضاء'] }, { canonical: 'Rabat', aliases: ['الرباط'] }] },
  { category: 'legal_forms', version: '1.0.0', entries: [{ canonical: 'SARL', aliases: ['S.A.R.L.'] }, { canonical: 'SA', aliases: ['S.A.'] }] },
  { category: 'commercial', version: '1.0.0', entries: [{ canonical: 'Société', aliases: ['Sté', 'Ste'] }] },
];
const key = (value: string) => value.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
export function completeDictionary(category: DictionaryCategory, input: string, source: readonly Dictionary[] = dictionaries): string[] {
  const query = key(input);
  if (query.length < 2 || query.length > 100) return [];
  return [...new Set(source.filter((d) => d.category === category).flatMap((d) => d.entries)
    .filter((entry) => [entry.canonical, ...entry.aliases].some((alias) => key(alias).startsWith(query)))
    .map((entry) => entry.canonical))].slice(0, 10);
}

export interface PartyQualityInput { kind: 'PERSON' | 'BUSINESS'; displayName: string; contactName?: string | null; email?: string | null; phone?: string | null }
/** Advisory checks only; the authoritative validator remains separate. */
export function assessPartyQuality(party: PartyQualityInput): Finding[] {
  const findings: Finding[] = [];
  if (!party.displayName.trim()) findings.push({ code: 'name_missing', fields: ['displayName'], reason: 'Le nom est vide.', action: 'Renseigner le nom.' });
  if (party.kind === 'BUSINESS' && !party.contactName?.trim()) findings.push({ code: 'contact_missing', fields: ['contactName'], reason: 'Le contact principal est absent.', action: 'Renseigner le contact principal.' });
  if (!party.email?.trim() && !party.phone?.trim()) findings.push({ code: 'contact_details_missing', fields: ['email', 'phone'], reason: 'Aucune coordonnée de contact n’est renseignée.', action: 'Ajouter une coordonnée si elle est disponible.' });
  if (party.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(party.email.trim())) findings.push({ code: 'email_review', fields: ['email'], reason: 'La forme de l’adresse semble incorrecte.', action: 'Vérifier l’adresse.' });
  return findings;
}
