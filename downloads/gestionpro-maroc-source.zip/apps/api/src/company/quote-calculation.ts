// Positive decimal values only. All arithmetic is integer-based; amounts round
// half up per line, then tax rounds half up on the rounded line net amount.
function scaled(value: string, places: number, maxIntegerDigits: number): bigint {
  if (typeof value !== 'string' || !new RegExp(`^\\d{1,${maxIntegerDigits}}(?:\\.\\d{1,${places}})?$`).test(value)) throw new Error('invalid_decimal');
  const [whole, fraction = ''] = value.split('.');
  return BigInt(whole!) * 10n ** BigInt(places) + BigInt(fraction.padEnd(places, '0'));
}
function round(n: bigint, d: bigint): bigint { return (n + d / 2n) / d; }
function money(cents: bigint): string { return `${cents / 100n}.${String(cents % 100n).padStart(2, '0')}`; }
export function calculateQuoteLine(input: { quantity: string; unitPrice: string; discountRate: string; taxRate: string }) {
  const quantity = scaled(input.quantity, 3, 12);
  const price = scaled(input.unitPrice, 2, 12);
  const discount = scaled(input.discountRate, 2, 3);
  const tax = scaled(input.taxRate, 2, 3);
  if (quantity === 0n || discount > 10000n || tax > 10000n) throw new Error('invalid_decimal');
  const net = round(quantity * price * (10000n - discount), 1000n * 10000n);
  const taxAmount = round(net * tax, 10000n);
  if (net > 999999999999999999n || taxAmount > 999999999999999999n) throw new Error('amount_too_large');
  return { net: money(net), tax: money(taxAmount), total: money(net + taxAmount) };
}
