import type { AuthQueryDatabase } from '../auth/login-service.js';
import type { RegistrationDatabase } from '../auth/registration-service.js';

export type CompanyStatus = 'ACTIVE' | 'SETUP_PENDING' | 'CANCELLATION_PENDING' | 'CLOSED';
export interface MyCompany {
  id: string;
  name: string;
  status: CompanyStatus;
  role: 'OWNER' | 'MANAGER' | 'EMPLOYEE';
}

export type MembershipRole = 'OWNER' | 'MANAGER' | 'EMPLOYEE';
export type MembershipStatus = 'ACTIVE' | 'DISABLED';
export interface CompanyMember {
  id: string;
  email: string;
  role: MembershipRole;
  status: MembershipStatus;
  joinedAt: Date | string;
}

type CompanyRow = MyCompany;
type CompanyMemberRow = {
  id: string;
  email: string;
  role: MembershipRole;
  status: MembershipStatus;
  joined_at: Date | string;
};
export class CompanyAlreadyExistsError extends Error {
  constructor() { super('company_already_exists'); }
}
export class CompanyAccountUnavailableError extends Error {
  constructor() { super('account_unavailable'); }
}

export function validateCompanyCreation(input: unknown): { name: string } {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_company_input');
  const values = input as Record<string, unknown>;
  if (Object.keys(values).some((key) => key !== 'name') || typeof values.name !== 'string') {
    throw new Error('invalid_company_input');
  }
  const name = values.name.trim();
  if (Array.from(name).length < 1 || Array.from(name).length > 200 || /[\u0000-\u001f\u007f]/u.test(name)) {
    throw new Error('invalid_company_name');
  }
  return { name };
}

/** Only returns the caller's company; never accepts tenant/company IDs from the request. */
export async function findMyCompany(database: AuthQueryDatabase, userId: string): Promise<MyCompany | null> {
  const result = await database.query(
    `SELECT c.id, c.name, c.status, m.role
       FROM public.company_memberships m
       JOIN public.companies c ON c.id = m.company_id
      WHERE m.user_id = $1 AND m.status = 'ACTIVE'
      LIMIT 1`, [userId]
  );
  return (result.rows[0] as CompanyRow | undefined) ?? null;
}

/**
 * Lists members only for the authenticated user's active company. The tenant is
 * derived in SQL from userId; no client-controlled company/user ID is accepted.
 */
export async function findMyCompanyMembers(database: AuthQueryDatabase, userId: string): Promise<CompanyMember[]> {
  const result = await database.query(
    `SELECT u.id, u.email, m.role, m.status, m.joined_at
       FROM public.company_memberships m
       JOIN public.users u ON u.id = m.user_id
      WHERE m.company_id = (
        SELECT caller.company_id
          FROM public.company_memberships caller
         WHERE caller.user_id = $1 AND caller.status = 'ACTIVE'
         LIMIT 1
      )
      ORDER BY m.joined_at ASC, u.id ASC`,
    [userId]
  );
  return result.rows.map((row) => {
    const member = row as CompanyMemberRow;
    return {
      id: member.id,
      email: member.email,
      role: member.role,
      status: member.status,
      joinedAt: member.joined_at,
    };
  });
}

/**
 * Serializes company creation for the same user by locking their user row.
 * Exactly one company + OWNER membership, atomically activated in PostgreSQL.
 * Existing DB 0003 triggers enforce verified effective OWNER at activation.
 */
export async function createMyCompany(database: RegistrationDatabase, userId: string, input: unknown): Promise<MyCompany> {
  const { name } = validateCompanyCreation(input);
  const client = await database.connect();
  let transactionStarted = false;
  try {
    await client.query('BEGIN');
    transactionStarted = true;
    const users = await client.query(
      `SELECT id, status, email_verified_at FROM public.users WHERE id = $1 FOR UPDATE`, [userId]
    );
    const currentUser = users.rows[0] as { status: string; email_verified_at: Date | string | null } | undefined;
    if (!currentUser || currentUser.status !== 'ACTIVE' || currentUser.email_verified_at === null) {
      throw new CompanyAccountUnavailableError();
    }
    const previous = await client.query(
      `SELECT id FROM public.company_memberships WHERE user_id = $1 LIMIT 1`, [userId]
    );
    if (previous.rows.length) throw new CompanyAlreadyExistsError();

    const created = await client.query(
      `INSERT INTO public.companies (name, status)
       VALUES ($1, 'SETUP_PENDING') RETURNING id`, [name]
    );
    const companyId = (created.rows[0] as { id?: string } | undefined)?.id;
    if (!companyId) throw new Error('invalid_company_insert_result');

    await client.query(
      `INSERT INTO public.company_memberships (company_id, user_id, role, status)
       VALUES ($1, $2, 'OWNER', 'ACTIVE')`, [companyId, userId]
    );
    const activated = await client.query(
      `UPDATE public.companies SET status = 'ACTIVE' WHERE id = $1
       RETURNING id, name, status`, [companyId]
    );
    const row = activated.rows[0] as { id: string; name: string; status: CompanyStatus } | undefined;
    if (!row || row.status !== 'ACTIVE') throw new Error('company_activation_failed');
    await client.query('COMMIT');
    transactionStarted = false;
    return { id: row.id, name: row.name, status: row.status, role: 'OWNER' };
  } catch (error) {
    if (transactionStarted) await client.query('ROLLBACK').catch(() => undefined);
    if (error && typeof error === 'object' && 'code' in error && error.code === '23505') {
      throw new CompanyAlreadyExistsError();
    }
    throw error;
  } finally {
    client.release();
  }
}
