import { createHash, randomBytes } from 'node:crypto';
import type { AuthQueryDatabase } from '../auth/login-service.js';
import type { RegistrationClient, RegistrationDatabase } from '../auth/registration-service.js';

export type InvitationRole = 'MANAGER' | 'EMPLOYEE';
export type InvitationStatus = 'PENDING' | 'REVOKED' | 'EXPIRED' | 'ACCEPTED';
export interface CompanyInvitation {
  id: string;
  email: string;
  proposedRole: InvitationRole;
  status: InvitationStatus;
  expiresAt: Date | string;
  createdAt: Date | string;
  revokedAt: Date | string | null;
}
export interface OutgoingInvitationEmail { to: string; url: string; role: InvitationRole; }
export interface CompanyInvitationMailTransport { sendInvitation(message: OutgoingInvitationEmail): Promise<void>; }

export class InvitationForbiddenError extends Error { constructor() { super('invitation_forbidden'); } }
export class InvitationAlreadyPendingError extends Error { constructor() { super('invitation_already_pending'); } }
export class InvitationRecipientAlreadyAssignedError extends Error { constructor() { super('invitation_recipient_already_assigned'); } }
export class InvitationRecentlySentError extends Error { constructor() { super('invitation_recently_sent'); } }
export class InvitationNotFoundError extends Error { constructor() { super('invitation_not_found'); } }
export class InvitationAcceptanceError extends Error { constructor(message: string) { super(message); } }

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const INVITATION_EXPIRY_SECONDS = 7 * 24 * 60 * 60;
const INVITATION_COOLDOWN_SECONDS = 60;

export function validateInvitation(input: unknown): { email: string; proposedRole: InvitationRole } {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_invitation_input');
  const body = input as Record<string, unknown>;
  if (Object.keys(body).some((key) => key !== 'email' && key !== 'role') || typeof body.email !== 'string' || typeof body.role !== 'string') {
    throw new Error('invalid_invitation_input');
  }
  const email = body.email.trim().toLowerCase();
  if (email.length < 3 || email.length > 320 || !EMAIL.test(email)) throw new Error('invalid_invitation_email');
  if (body.role !== 'MANAGER' && body.role !== 'EMPLOYEE') throw new Error('invalid_invitation_role');
  return { email, proposedRole: body.role };
}

function hashInvitationToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/** Preview is available only to the authenticated matching recipient. */
export async function previewCompanyInvitation(database: AuthQueryDatabase, actorId: string, input: unknown): Promise<{ companyName: string; role: InvitationRole }> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new InvitationAcceptanceError('invalid_invitation');
  const body = input as Record<string, unknown>;
  if (Object.keys(body).length !== 1 || typeof body.token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(body.token)) throw new InvitationAcceptanceError('invalid_invitation');
  const result = await database.query(`SELECT i.email, i.proposed_role, i.status, i.expires_at > now() AS unexpired, c.status AS company_status, c.name, u.email AS user_email
    FROM public.company_invitations i JOIN public.companies c ON c.id=i.company_id
    JOIN public.users u ON u.id=$2 AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL
    WHERE i.token_hash=$1`, [hashInvitationToken(body.token), actorId]);
  const row = result.rows[0] as { email: string; user_email: string; proposed_role: string; status: string; unexpired: boolean; company_status: string; name: string } | undefined;
  if (!row) throw new InvitationAcceptanceError('invalid_invitation');
  if (row.email !== row.user_email) throw new InvitationAcceptanceError('invitation_wrong_account');
  if (row.status !== 'PENDING' || !row.unexpired || row.company_status !== 'ACTIVE' || !['MANAGER', 'EMPLOYEE'].includes(row.proposed_role)) throw new InvitationAcceptanceError('invitation_unavailable');
  return { companyName: row.name, role: row.proposed_role as InvitationRole };
}

/** Lock the account first, then invitation, then company; all decisions and writes are atomic. */
export async function acceptCompanyInvitation(database: RegistrationDatabase, actorId: string, input: unknown): Promise<void> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new InvitationAcceptanceError('invalid_invitation');
  const body = input as Record<string, unknown>;
  if (Object.keys(body).length !== 1 || typeof body.token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(body.token)) {
    throw new InvitationAcceptanceError('invalid_invitation');
  }
  const client = await database.connect();
  let open = false;
  try {
    await client.query('BEGIN'); open = true;
    const users = await client.query(`SELECT email, status, email_verified_at FROM public.users WHERE id = $1 FOR UPDATE`, [actorId]);
    const user = users.rows[0] as { email: string; status: string; email_verified_at: Date | null } | undefined;
    if (!user || user.status !== 'ACTIVE' || !user.email_verified_at) throw new InvitationAcceptanceError('unauthorized');
    const result = await client.query(`SELECT id, company_id, email, proposed_role, status, expires_at > now() AS unexpired
      FROM public.company_invitations WHERE token_hash = $1 FOR UPDATE`, [hashInvitationToken(body.token)]);
    const invitation = result.rows[0] as { id: string; company_id: string; email: string; proposed_role: string; status: string; unexpired: boolean } | undefined;
    if (!invitation) throw new InvitationAcceptanceError('invalid_invitation');
    if (invitation.email !== user.email) throw new InvitationAcceptanceError('invitation_wrong_account');
    if (invitation.status !== 'PENDING' || !invitation.unexpired) throw new InvitationAcceptanceError('invitation_unavailable');
    if (invitation.proposed_role !== 'MANAGER' && invitation.proposed_role !== 'EMPLOYEE') throw new InvitationAcceptanceError('invitation_unavailable');
    const company = await client.query(`SELECT status FROM public.companies WHERE id = $1 FOR UPDATE`, [invitation.company_id]);
    if ((company.rows[0] as { status?: string } | undefined)?.status !== 'ACTIVE') throw new InvitationAcceptanceError('invitation_unavailable');
    const membership = await client.query('SELECT 1 FROM public.company_memberships WHERE user_id = $1', [actorId]);
    if (membership.rows.length) throw new InvitationAcceptanceError('company_already_exists');
    await client.query(`INSERT INTO public.company_memberships (company_id, user_id, role, status)
      VALUES ($1, $2, $3, 'ACTIVE')`, [invitation.company_id, actorId, invitation.proposed_role]);
    await client.query(`UPDATE public.company_invitations SET status = 'ACCEPTED' WHERE id = $1`, [invitation.id]);
    await client.query('COMMIT'); open = false;
  } catch (error) {
    if (open) await client.query('ROLLBACK').catch(() => undefined);
    if (error && typeof error === 'object' && 'code' in error && error.code === '23505') throw new InvitationAcceptanceError('company_already_exists');
    throw error;
  } finally { client.release(); }
}

async function ownerCompany(database: AuthQueryDatabase | RegistrationClient, userId: string): Promise<string | null> {
  const result = await database.query(
    `SELECT c.id FROM public.company_memberships m JOIN public.companies c ON c.id = m.company_id
      JOIN public.users u ON u.id = m.user_id
     WHERE m.user_id = $1 AND m.role = 'OWNER' AND m.status = 'ACTIVE'
       AND c.status = 'ACTIVE' AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
     LIMIT 1`, [userId]
  );
  return (result.rows[0] as { id?: string } | undefined)?.id ?? null;
}

function mapInvitation(row: Record<string, unknown>): CompanyInvitation {
  return { id: row.id as string, email: row.email as string, proposedRole: row.proposed_role as InvitationRole,
    status: row.status as InvitationStatus, expiresAt: row.expires_at as Date | string,
    createdAt: row.created_at as Date | string, revokedAt: row.revoked_at as Date | string | null };
}

/** Returns invitations only after deriving the ACTIVE tenant from the active verified OWNER. */
export async function listMyCompanyInvitations(database: AuthQueryDatabase, actorId: string): Promise<CompanyInvitation[]> {
  const companyId = await ownerCompany(database, actorId);
  if (!companyId) throw new InvitationForbiddenError();
  await database.query(`UPDATE public.company_invitations SET status = 'EXPIRED'
    WHERE company_id = $1 AND status = 'PENDING' AND expires_at <= now()`, [companyId]);
  const result = await database.query(`SELECT id, email, proposed_role, status, expires_at, created_at, revoked_at
    FROM public.company_invitations WHERE company_id = $1 ORDER BY created_at DESC`, [companyId]);
  return result.rows.map((row) => mapInvitation(row as Record<string, unknown>));
}

/** Raw token is retained only long enough to hand it to the configured mail transport. */
export async function createCompanyInvitation(
  database: RegistrationDatabase, actorId: string, input: unknown, transport: CompanyInvitationMailTransport, webOrigin: string
): Promise<void> {
  const { email, proposedRole } = validateInvitation(input);
  const client = await database.connect();
  let transactionOpen = false;
  let emailToSend: OutgoingInvitationEmail | null = null;
  try {
    await client.query('BEGIN'); transactionOpen = true;
    const companyId = await ownerCompany(client, actorId);
    if (!companyId) throw new InvitationForbiddenError();
    const actor = await client.query('SELECT email FROM public.users WHERE id = $1 FOR UPDATE', [actorId]);
    if ((actor.rows[0] as { email?: string } | undefined)?.email === email) throw new Error('invitation_self_forbidden');
    const assigned = await client.query(`SELECT 1 FROM public.users u JOIN public.company_memberships m ON m.user_id = u.id
      WHERE u.email = $1 LIMIT 1`, [email]);
    if (assigned.rows.length) throw new InvitationRecipientAlreadyAssignedError();
    await client.query(`UPDATE public.company_invitations SET status = 'EXPIRED'
      WHERE company_id = $1 AND email = $2 AND status = 'PENDING' AND expires_at <= now()`, [companyId, email]);
    const recent = await client.query(`SELECT 1 FROM public.company_invitations
      WHERE company_id = $1 AND email = $2 AND created_at > now() - ($3::integer * interval '1 second') LIMIT 1`,
      [companyId, email, INVITATION_COOLDOWN_SECONDS]);
    if (recent.rows.length) throw new InvitationRecentlySentError();
    const pending = await client.query(`SELECT 1 FROM public.company_invitations
      WHERE company_id = $1 AND email = $2 AND status = 'PENDING' LIMIT 1`, [companyId, email]);
    if (pending.rows.length) throw new InvitationAlreadyPendingError();
    const token = randomBytes(32).toString('base64url');
    await client.query(`INSERT INTO public.company_invitations
      (company_id, email, proposed_role, token_hash, expires_at, created_by_user_id)
      VALUES ($1, $2, $3, $4, now() + ($5::integer * interval '1 second'), $6)`,
      [companyId, email, proposedRole, hashInvitationToken(token), INVITATION_EXPIRY_SECONDS, actorId]);
    await client.query('COMMIT'); transactionOpen = false;
    emailToSend = { to: email, role: proposedRole, url: `${webOrigin}/invite?token=${encodeURIComponent(token)}` };
  } catch (error) {
    if (transactionOpen) await client.query('ROLLBACK').catch(() => undefined);
    if (error && typeof error === 'object' && 'code' in error && error.code === '23505') throw new InvitationAlreadyPendingError();
    throw error;
  } finally { client.release(); }
  try { await transport.sendInvitation(emailToSend); } catch { /* delivery details never reach HTTP clients */ }
}

export async function revokeCompanyInvitation(database: RegistrationDatabase, actorId: string, invitationId: string): Promise<void> {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(invitationId)) throw new InvitationNotFoundError();
  const client = await database.connect();
  let transactionOpen = false;
  try {
    await client.query('BEGIN'); transactionOpen = true;
    const companyId = await ownerCompany(client, actorId);
    if (!companyId) throw new InvitationForbiddenError();
    await client.query(`UPDATE public.company_invitations SET status = 'EXPIRED'
      WHERE company_id = $1 AND status = 'PENDING' AND expires_at <= now()`, [companyId]);
    const updated = await client.query(`UPDATE public.company_invitations SET status = 'REVOKED', revoked_at = now()
      WHERE id = $1 AND company_id = $2 AND status = 'PENDING' RETURNING id`, [invitationId, companyId]);
    if (!updated.rows.length) throw new InvitationNotFoundError();
    await client.query('COMMIT'); transactionOpen = false;
  } catch (error) {
    if (transactionOpen) await client.query('ROLLBACK').catch(() => undefined);
    throw error;
  } finally { client.release(); }
}
