/** ENT-03 policy B: preserve display form and derive the 15 ASCII digits. */
export function validatePartyIce(value: unknown): { ice: string; normalized: string } | null {
  if (value === null || value === undefined) return null;
  if (typeof value !== 'string') throw new Error('invalid_ice');
  const spaces = /^[\u0020\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]+|[\u0020\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]+$/gu;
  const ice = value.replace(spaces, '');
  if (!ice) return null;
  if (!/^[0-9](?:[ -]?[0-9])*$/u.test(ice)) throw new Error('invalid_ice');
  const normalized = ice.replace(/[ -]/gu, '');
  if (normalized.length !== 15) throw new Error('invalid_ice');
  return { ice, normalized };
}
