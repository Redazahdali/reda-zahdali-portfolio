import type { AuthQueryDatabase } from '../auth/login-service.js';
import { digestSessionToken } from '../auth/login-service.js';
import type { RegistrationDatabase } from '../auth/registration-service.js';
import { createHash } from 'node:crypto';

export function validateCatalog(input: unknown): unknown[] {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_catalog');
  const p = input as Record<string, unknown>;
  const keys = ['kind','reference','name','description','category','unit','price','tax_rate','active','stock_info'];
  if (Object.keys(p).some(k => !keys.includes(k)) || !['PRODUCT','SERVICE'].includes(String(p.kind)) || typeof p.active !== 'boolean') throw new Error('invalid_catalog');
  const text = (key: string, max: number, required = false) => {
    const value = p[key]; if (typeof value !== 'string' || /[\p{Cc}\p{Cs}]/u.test(key === 'description' ? value.replace(/\r?\n/g,'') : value)) throw new Error('invalid_catalog');
    const s = value.trim(); if (s.length > max || (required && !s)) throw new Error('invalid_catalog'); return s;
  };
  const decimal = (key: string, max: number) => { const v = p[key]; if (typeof v !== 'string' || !/^\d{1,12}(\.\d{1,2})?$/.test(v) || Number(v) > max) throw new Error('invalid_catalog'); return v; };
  return [p.kind,text('reference',100,true),text('name',200,true),text('description',2000),text('category',120),text('unit',50,true),decimal('price',999999999999.99),decimal('tax_rate',100),p.active,text('stock_info',500)];
}
const scope = `JOIN public.companies c ON c.id=i.company_id AND c.status='ACTIVE' JOIN public.company_memberships m ON m.company_id=c.id AND m.user_id=$1 AND m.status='ACTIVE' JOIN public.users u ON u.id=m.user_id AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL`;
export async function listCatalog(db: AuthQueryDatabase, user: string, search: string, activeOnly = false, options: {kind?:string; category?:string; status?:string; limit?:number; offset?:number} = {}) {
  return (await db.query(`SELECT i.* FROM public.catalog_items i ${scope} WHERE ($2='' OR position(lower($2) in lower(i.name))>0 OR position(lower($2) in lower(i.reference))>0) AND (NOT $3::boolean OR i.active)
    AND ($4='all' OR i.kind=$4) AND ($5='' OR lower(i.category)=lower($5)) AND ($6='all' OR i.active=($6='active'))
    ORDER BY i.name,i.id LIMIT $7 OFFSET $8`, [user,search,activeOnly,options.kind ?? 'all',options.category ?? '',options.status ?? 'all',options.limit ?? 100,options.offset ?? 0])).rows;
}
export async function getCatalog(db: AuthQueryDatabase, user: string, id: string) {
  return (await db.query(`SELECT i.* FROM public.catalog_items i ${scope} WHERE i.id=$2`, [user,id])).rows[0] ?? null;
}
export async function saveCatalog(db: AuthQueryDatabase, user: string, id: string | null, body: unknown) {
  const values = validateCatalog(body);
  if (id) return (await db.query(`UPDATE public.catalog_items i SET kind=$3,reference=$4,name=$5,description=$6,category=$7,unit=$8,price=$9,tax_rate=$10,active=$11,stock_info=$12,updated_at=now() FROM public.company_memberships m,public.companies c,public.users u WHERE i.id=$2 AND i.company_id=m.company_id AND m.user_id=$1 AND m.status='ACTIVE' AND m.role IN ('OWNER','MANAGER') AND c.id=m.company_id AND c.status='ACTIVE' AND u.id=m.user_id AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL RETURNING i.*`, [user,id,...values])).rows[0] ?? null;
  return (await db.query(`INSERT INTO public.catalog_items(company_id,kind,reference,name,description,category,unit,price,tax_rate,active,stock_info) SELECT c.id,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11 FROM public.company_memberships m JOIN public.companies c ON c.id=m.company_id JOIN public.users u ON u.id=m.user_id WHERE m.user_id=$1 AND m.status='ACTIVE' AND m.role IN ('OWNER','MANAGER') AND c.status='ACTIVE' AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL RETURNING *`, [user,...values])).rows[0] ?? null;
}

export class CatalogWriteError extends Error { constructor(public code: string, public status: number) { super(code); } }
/** The session and tenant are locked for the full transaction, including receipt replay. */
export async function saveCatalogOnce(db: Pick<RegistrationDatabase,'connect'>, token: string, id: string | null, body: unknown, key: string, statusOnly = false) {
  if (!/^[A-Za-z0-9_-]{16,100}$/.test(key)) throw new CatalogWriteError('invalid_idempotency_key',400);
  let values: unknown[] = [];
  if (statusOnly) {
    if (!id || !body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).length !== 1 || typeof (body as {active?:unknown}).active !== 'boolean') throw new CatalogWriteError('invalid_catalog',400);
  } else values=validateCatalog(body);
  const fingerprint=createHash('sha256').update(JSON.stringify({id,body:statusOnly ? body : values})).digest('hex');
  const action=statusOnly?'status':id?'update':'create'; const client=await db.connect();
  try {
    await client.query('BEGIN');
    const session=await client.query(`SELECT c.id,m.user_id,m.role FROM auth_sessions s JOIN users u ON u.id=s.user_id JOIN company_memberships m ON m.user_id=u.id JOIN companies c ON c.id=m.company_id
      WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>clock_timestamp() AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL AND m.status='ACTIVE' AND c.status='ACTIVE'
      FOR UPDATE OF c FOR SHARE OF s,u,m`,[digestSessionToken(token)]);
    const actor=session.rows[0] as {id:string;user_id:string;role:string}|undefined;
    if (!actor) throw new CatalogWriteError('unauthorized',401);
    if (session.rows.length!==1 || !['OWNER','MANAGER'].includes(actor.role)) throw new CatalogWriteError('forbidden',403);
    const existing=(await client.query('SELECT fingerprint,result FROM catalog_operation_receipts WHERE company_id=$1 AND actor_id=$2 AND action=$3 AND idempotency_key=$4',[actor.id,actor.user_id,action,key])).rows[0] as {fingerprint:string;result:unknown}|undefined;
    if(existing){if(existing.fingerprint!==fingerprint)throw new CatalogWriteError('catalog_conflict',409);await client.query('COMMIT');return existing.result;}
    let result;
    if(statusOnly) result=await client.query('UPDATE catalog_items SET active=$3,updated_at=now() WHERE company_id=$1 AND id=$2 RETURNING *',[actor.id,id,(body as {active:boolean}).active]);
    else if(id) result=await client.query(`UPDATE catalog_items SET kind=$3,reference=$4,name=$5,description=$6,category=$7,unit=$8,price=$9,tax_rate=$10,stock_info=$11,updated_at=now() WHERE company_id=$1 AND id=$2 RETURNING *`,[actor.id,id,...values.slice(0,8),values[9]]);
    else result=await client.query(`INSERT INTO catalog_items(company_id,kind,reference,name,description,category,unit,price,tax_rate,active,stock_info) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[actor.id,...values]);
    const item=result.rows[0]; if(!item)throw new CatalogWriteError('not_found',404);
    await client.query('INSERT INTO catalog_operation_receipts(company_id,actor_id,action,idempotency_key,fingerprint,result) VALUES($1,$2,$3,$4,$5,$6)',[actor.id,actor.user_id,action,key,fingerprint,JSON.stringify(item)]);
    await client.query('COMMIT'); return item;
  } catch(e) {await client.query('ROLLBACK').catch(()=>undefined);throw e;} finally {client.release();}
}
