import { validatePartyIce } from './party-ice.js';
import { unicode17Ranges } from './ent03-unicode-v1.js';

export type PartyCreate = {
  kind: 'PERSON' | 'BUSINESS'; display_name: string; contact_name: string | null;
  is_client: boolean; is_supplier: boolean; phone: string | null; email: string | null;
  address: string | null; city: string | null; postal_code: string | null; ice: string | null;
  tax_id: string | null; trade_register: string | null; professional_tax: string | null;
};

const fields = { display_name: 200, contact_name: 200, phone: 50, email: 320, address: 500, city: 120, postal_code: 30, tax_id: 100, trade_register: 100, professional_tax: 100 } as const;
const edgeSpaces = /^[\u0020\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]+|[\u0020\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]+$/gu;
function inRanges(code: number, ranges: ReadonlyArray<readonly [number, number]>): boolean {
  let low = 0; let high = ranges.length - 1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2); const range = ranges[middle]!;
    if (code < range[0]) high = middle - 1; else if (code > range[1]) low = middle + 1; else return true;
  }
  return false;
}
const has = (text: string, ranges: ReadonlyArray<readonly [number, number]>) => Array.from(text).some(character => inRanges(character.codePointAt(0)!, ranges));
function textField(value: unknown, field: keyof typeof fields): string | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string' || has(value, unicode17Ranges.forbidden)) throw new Error(`invalid_${field}`);
  const text = value.replace(edgeSpaces, '');
  if (!text) return null;
  if (Array.from(text).length > fields[field]) throw new Error(`invalid_${field}`);
  if (['display_name', 'contact_name', 'address'].includes(field) && has(text, unicode17Ranges.pictographic)) throw new Error(`invalid_${field}`);
  return text;
}

export function validatePartyCreate(input: unknown): PartyCreate {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_party_input');
  const data = input as Record<string, unknown>;
  const allowed = new Set([...Object.keys(fields), 'kind', 'is_client', 'is_supplier', 'ice']);
  if (Object.keys(data).some((key) => !allowed.has(key))) throw new Error('invalid_party_input');
  if ((data.kind !== 'PERSON' && data.kind !== 'BUSINESS') || typeof data.is_client !== 'boolean' || typeof data.is_supplier !== 'boolean' || (!data.is_client && !data.is_supplier)) throw new Error('invalid_party_input');
  const display_name = textField(data.display_name, 'display_name');
  const contact_name = textField(data.contact_name, 'contact_name');
  if (!display_name || !has(display_name, unicode17Ranges.alphanumeric)) throw new Error('invalid_display_name');
  if (contact_name && !has(contact_name, unicode17Ranges.alphanumeric)) throw new Error('invalid_contact_name');
  if (data.kind === 'BUSINESS' && !contact_name) throw new Error('invalid_contact_name');
  const ice = validatePartyIce(data.ice)?.ice ?? null;
  return { kind: data.kind, is_client: data.is_client, is_supplier: data.is_supplier, display_name, contact_name,
    phone: textField(data.phone, 'phone'), email: textField(data.email, 'email'), address: textField(data.address, 'address'),
    city: textField(data.city, 'city'), postal_code: textField(data.postal_code, 'postal_code'), ice,
    tax_id: textField(data.tax_id, 'tax_id'), trade_register: textField(data.trade_register, 'trade_register'), professional_tax: textField(data.professional_tax, 'professional_tax') };
}
