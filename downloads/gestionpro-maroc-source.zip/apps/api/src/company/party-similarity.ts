import { PARTY_SEARCH_ALIASES } from './party-dictionaries.js';

export interface SearchParty { id: string; companyId: string; name: string; ice?: string | null; email?: string | null; phone?: string | null }
export interface Suggestion { id: string; score: number; reasons: string[] }

/** Search-only transformation: never use this value for storage or validation. */
export function searchName(name: string): string {
  const words = name.normalize('NFD').toLowerCase().replace(/\p{M}/gu, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim().split(/\s+/u).filter(Boolean);
  return words.map((word) => PARTY_SEARCH_ALIASES[word] ?? word).join(' ');
}

function similarity(a: string, b: string): number {
  if (!a || !b) return 0;
  let previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 0; i < a.length; i++) {
    const next = [i + 1];
    for (let j = 0; j < b.length; j++) next.push(Math.min(next[j]! + 1, previous[j + 1]! + 1, previous[j]! + (a[i] === b[j] ? 0 : 1)));
    previous = next;
  }
  return 1 - previous[b.length]! / Math.max(a.length, b.length);
}

/** Caller must already authorize the tenant; filter again before scoring. */
export function suggestParties(companyId: string, input: Omit<SearchParty, 'id' | 'companyId'>, candidates: readonly SearchParty[]): Suggestion[] {
  const query = searchName(input.name);
  if (query.length > 300) return [];
  return candidates.filter((p) => p.companyId === companyId).flatMap((p) => {
    const name = searchName(p.name);
    if (name.length > 300) return [];
    const reasons: string[] = [];
    let score = 0;
    const sim = similarity(query, name);
    if (query.length >= 4 && sim === 1) { score += 55; reasons.push('nom identique après normalisation de recherche'); }
    else if (query.length >= 6 && sim >= 0.85) { score += 40; reasons.push('nom similaire'); }
    if (input.ice && p.ice && input.ice === p.ice) { score += 100; reasons.push('ICE identique'); }
    if (input.email && p.email && input.email.trim().toLowerCase() === p.email.trim().toLowerCase()) { score += 30; reasons.push('e-mail identique'); }
    if (input.phone && p.phone && input.phone === p.phone) { score += 20; reasons.push('téléphone identique'); }
    if (input.ice && p.ice && input.ice !== p.ice) { score -= 30; reasons.push('ICE différent'); }
    return score >= 40 ? [{ id: p.id, score, reasons }] : [];
  }).sort ( (a, b) => b.score - a.score || a.id.localeCompare(b.id)).slice(0, 10);
}
