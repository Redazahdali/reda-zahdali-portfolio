import { mkdtemp, readFile, rm, writeFile, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { QuoteError } from './quote-service.js';
import { displayQuantity } from './document-display.js';
import type { DocumentVisual } from './document-identity.js';

type Row = Record<string, any>;
const escape = (v: unknown) => String(v ?? '').replace(/[&<>"']/g,c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const cell = (v: unknown) => `<span dir="auto">${escape(v)}</span>`;
const numberCell = (v: unknown) => `<span style="white-space:nowrap;${String(v ?? '').length > 12 ? 'font-size:8px' : ''}" dir="ltr">${escape(v)}</span>`;
const date = (v: unknown) => { const iso=v instanceof Date ? v.toISOString().slice(0,10) : String(v ?? '').slice(0,10); return escape(/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso.slice(8,10)}/${iso.slice(5,7)}/${iso.slice(0,4)}` : ''); };
function html(q: Row, invoice = false, visual?: DocumentVisual): string {
  const client=q.client_snapshot ?? {}, issuer=q.issuer_snapshot ?? {};
  const documentTitle=invoice ? (q.status==='ISSUED'?'FACTURE':'FACTURE · BROUILLON') : 'DEVIS';
  const number=invoice ? (q.invoice_number ?? 'Brouillon') : q.quote_number;
  const lines=(q.lines as Row[]).map(l => `<tr><td>${cell(l.item_snapshot?.name)}${l.item_snapshot?.description ? `<small>${cell(l.item_snapshot.description)}</small>` : ''}</td><td>${numberCell(displayQuantity(String(l.quantity)))}</td><td>${cell(l.item_snapshot?.unit)}</td><td>${numberCell(l.unit_price)}</td><td>${cell(l.discount_rate)} %</td><td>${cell(l.tax_rate)} %</td><td>${numberCell(l.net_amount)}</td></tr>`).join('');
  const info=(v: unknown) => v ? `<div>${cell(v)}</div>` : '';
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><style>
    @page { size:A4 portrait; margin:17mm 14mm 19mm; @bottom-left { content:'${invoice?'Facture':'Devis'} ${escape(number)}'; color:#617569; font:9px Arial; } @bottom-right { content:'Page ' counter(page) ' / ' counter(pages); color:#617569; font:9px Arial; } }
    *{box-sizing:border-box} body{font-family:Arial,'Segoe UI',sans-serif;color:#193b29;font-size:10px;line-height:1.5} h1,h2,p{margin:0} .head{display:flex;justify-content:space-between;gap:20px;border-bottom:3px solid #175b39;padding-bottom:13px;margin-bottom:18px}.head h1{font-size:25px;letter-spacing:.08em;color:#175b39}.head h2{font-size:16px}.meta{text-align:right}.meta p{margin-top:3px}.parties{display:flex;gap:18px;margin-bottom:18px}.box{flex:1;background:#f5f8f5;border:1px solid #dce8dd;border-radius:5px;padding:10px}.label{font-size:9px;color:#52725f;font-weight:bold;text-transform:uppercase;letter-spacing:.06em}.box strong{display:block;font-size:12px;margin:4px 0}.subject{margin:0 0 15px}.subject strong{display:block;margin:3px 0}.table{width:100%;border-collapse:collapse;table-layout:fixed}.table thead{display:table-header-group}.table tr{break-inside:avoid}.table th{background:#175b39;color:white;text-align:left;padding:8px 5px;font-size:9px}.table td{border-bottom:1px solid #dce7df;padding:7px 5px;vertical-align:top;overflow-wrap:anywhere}.table th:not(:first-child),.table td:not(:first-child){text-align:right}.table small{display:block;color:#687f70;white-space:pre-wrap}.totals{width:220px;margin:18px 0 18px auto;break-inside:avoid}.totals div{display:flex;justify-content:space-between;padding:5px 8px}.totals .total{background:#e8f4ea;color:#145b36;font-size:13px;font-weight:bold}.text{white-space:pre-wrap;overflow-wrap:anywhere}.note{margin:16px 0}.note h2{font-size:11px;margin-bottom:4px}.signature{margin:26px 0 0 auto;width:230px;min-height:95px;border:1px solid #dce8dd;padding:10px;break-inside:avoid}.signature strong{font-size:11px}
    body{font-size:11px}.label,.table th{font-size:10px}.box strong{font-size:13px}.table td{font-size:10.5px}.totals{font-size:11px;width:280px}.totals .total{font-size:14px}.totals .total span{white-space:nowrap}.note h2,.signature strong{font-size:12px}
    ${visual?`body{font-size:11pt;color:#202c27;line-height:1.35}.head{border-color:${visual.colors.accent}}.head>div:first-child{min-width:0;flex:1}.head h1{font-size:23pt;color:${visual.colors.primary}}.head h2{font-size:18pt;overflow-wrap:anywhere}.meta{min-width:180px}.meta b{font-size:12pt}.box{background:${visual.colors.light}}.box strong{font-size:13pt}.label{font-size:9pt;color:${visual.colors.primary}}.subject strong{font-size:13pt}.table th{background:${visual.colors.light};color:${visual.colors.primary};border-bottom:2px solid ${visual.colors.accent};font-size:10pt}.table td{font-size:11pt}.table td:nth-child(5),.table td:nth-child(6){white-space:nowrap;font-size:9pt}.table small{font-size:9pt}.totals{font-size:11pt;width:300px}.totals .total{background:${visual.colors.light};color:${visual.colors.primary};font-size:16pt}.doc-logo{display:block;max-width:150px;max-height:60px;object-fit:contain;object-position:left;margin:0 0 8px}.note h2{font-size:11pt}.head h2,.subject strong,.box strong{word-break:break-word}`:''}
    </style></head><body><header class="head"><div>${visual?.logo?`<img class="doc-logo" alt="Logo" src="data:image/png;base64,${visual.logo.toString('base64')}">`:''}<h2>${cell(issuer.name)}</h2>${info(issuer.address)}${info(issuer.phone)}${info(issuer.email)}${info(issuer.ice)}</div><div class="meta"><h1>${documentTitle}</h1><p><b>${invoice && q.status!=='ISSUED'?'Sans numéro définitif':`N° ${cell(number)}`}</b></p><p>${invoice ? (q.issued_on ? `Émise le ${date(q.issued_on)}`:'Non émise') : `Émis le ${date(q.issued_on)} · Valable jusqu’au ${date(q.valid_until)}`}</p>${invoice && q.source_quote_number?`<p>Devis d’origine : ${cell(q.source_quote_number)}</p>`:''}</div></header>
    <section class="parties"><div class="box"><div class="label">Client</div><strong>${cell(client.display_name)}</strong>${info(client.contact_name)}${info(client.address)}${info(client.city)}${info(client.phone)}${info(client.email)}${client.ice ? `<div>ICE : ${cell(client.ice)}</div>` : ''}</div></section>
    <div class="subject"><div class="label">Objet</div><strong>${cell(q.subject)}</strong></div>
    <table class="table"><colgroup><col style="width:26%"><col style="width:12%"><col style="width:8%"><col style="width:16%"><col style="width:9%"><col style="width:9%"><col style="width:20%"></colgroup><thead><tr><th>Désignation</th><th>Qté</th><th>Unité</th><th>Prix HT</th><th>Remise</th><th>TVA</th><th>Total HT</th></tr></thead><tbody>${lines}</tbody></table>
    <div class="totals"><div><span>Total HT</span><b>${cell(q.total_net)} MAD</b></div><div><span>TVA</span><b>${cell(q.total_tax)} MAD</b></div><div class="total"><span>Total TTC</span><span${visual&&String(q.total_gross??'').length>12?' style="font-size:10pt"':''}>${cell(q.total_gross)} MAD</span></div></div>
    ${q.notes ? `<section class="note"><h2>Notes</h2><div class="text" dir="auto">${escape(q.notes)}</div></section>` : ''}${q.terms ? `<section class="note"><h2>Conditions</h2><div class="text" dir="auto">${escape(q.terms)}</div></section>` : ''}
    ${invoice?'':`<section class="signature"><strong>Bon pour accord</strong><p>Signature et cachet</p></section>`}</body></html>`;
}
async function browserPath(): Promise<string> {
  const candidates=[process.env.GP_PDF_BROWSER, process.platform==='win32' ? 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe' : '/usr/bin/chromium', process.platform==='win32' ? 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe' : '/usr/bin/google-chrome'];
  for (const candidate of candidates) if (candidate) { try { await access(candidate); return candidate; } catch { /* try next */ } }
  throw new QuoteError('pdf_unavailable',503);
}
export async function renderQuotePdf(q: Row, visual?:DocumentVisual): Promise<Buffer> { return renderDocument(q,false,visual); }
export async function renderInvoicePdf(q: Row, visual?:DocumentVisual): Promise<Buffer> { return renderDocument(q,true,visual); }
async function renderDocument(q: Row, invoice: boolean, visual?:DocumentVisual): Promise<Buffer> {
  if (activeRenders >= 2) throw new QuoteError('pdf_busy',503);
  activeRenders++;
  try { return await render(q,invoice,visual); } finally { activeRenders--; }
}
let activeRenders = 0;
async function render(q: Row, invoice: boolean, visual?:DocumentVisual): Promise<Buffer> {
  const browser=await browserPath(); const dir=await mkdtemp(join(tmpdir(),'gp-quote-')); const source=join(dir,'quote.html'), target=join(dir,'quote.pdf');
  try {
    await writeFile(source,html(q,invoice,visual),'utf8');
    await new Promise<void>((resolve,reject) => {
      const child=spawn(browser,['--headless','--disable-gpu','--disable-extensions','--disable-background-networking','--no-first-run','--no-pdf-header-footer',`--user-data-dir=${join(dir,'profile')}`,`--print-to-pdf=${target}`,`file:///${source.replace(/\\/g,'/')}`],{stdio:'ignore',windowsHide:true});
      const timer=setTimeout(() => { child.kill(); reject(new Error('pdf_timeout')); },30000);
      child.once('error',e => {clearTimeout(timer); reject(e);}); child.once('exit',code => {clearTimeout(timer); code===0 ? resolve() : reject(new Error('pdf_failed'));});
    });
    const result=await readFile(target); if (!result.subarray(0,5).equals(Buffer.from('%PDF-'))) throw new Error('pdf_failed'); return result;
  } finally { await rm(dir,{recursive:true,force:true}).catch(() => undefined); }
}
