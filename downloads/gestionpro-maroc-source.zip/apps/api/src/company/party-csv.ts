/** CSV cells are always quoted and spreadsheet formula prefixes neutralized. */
export function partyCsv(headers: readonly string[], rows: readonly (readonly (string | null)[])[]): string {
  const cell = (value: string | null): string => {
    let text = value ?? '';
    if (/^[\s\u0000-\u001f]*[=+\-@]/u.test(text)) text = "'" + text;
    return '"' + text.replace(/"/gu, '""') + '"';
  };
  return '\ufeff' + [headers, ...rows].map((row) => row.map(cell).join(';')).join('\r\n') + '\r\n';
}
