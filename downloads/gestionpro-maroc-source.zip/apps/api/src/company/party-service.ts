import { createHash, randomBytes, randomUUID } from 'node:crypto';
import type { RegistrationClient, RegistrationDatabase } from '../auth/registration-service.js';
import { validatePartyCreate, type PartyCreate } from './party-validation.js';
import { digestSessionToken } from '../auth/login-service.js';

export class PartyForbiddenError extends Error { constructor() { super('party_forbidden'); } }
export class PartyNotFoundError extends Error { constructor() { super('party_not_found'); } }
export class PartyConflictError extends Error { constructor() { super('party_conflict'); } }
export class PartySessionError extends Error { constructor() { super('unauthorized'); } }

type PartyDatabase = Pick<RegistrationDatabase, 'connect'>;
type PartyRow = Record<string, unknown>;
const hash = (value: string) => createHash('sha256').update(value).digest('hex');

async function transaction<T>(database: PartyDatabase, work: (client: RegistrationClient) => Promise<T>): Promise<T> {
  const client = await database.connect(); let open = false;
  try { await client.query('BEGIN'); open = true; const result = await work(client); await client.query('COMMIT'); open = false; return result; }
  catch (error) { if (open) await client.query('ROLLBACK').catch(() => undefined); throw error; }
  finally { client.release(); }
}

async function editableCompany(client: RegistrationClient, token: string): Promise<{companyId: string; actorId: string; role: string}> {
  if (!/^[A-Za-z0-9_-]{43}$/.test(token)) throw new PartySessionError();
  const result = await client.query(`SELECT c.id, u.id AS actor_id, m.role
    FROM public.auth_sessions s JOIN public.company_memberships m ON m.user_id=s.user_id JOIN public.companies c ON c.id=m.company_id
    JOIN public.users u ON u.id=m.user_id
    WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at > clock_timestamp() AND m.status='ACTIVE'
      AND c.status='ACTIVE' AND u.status='ACTIVE' AND u.email_verified_at IS NOT NULL
    FOR UPDATE OF c FOR SHARE OF s, m, u`, [digestSessionToken(token)]);
  const row = result.rows[0] as { id: string; actor_id: string; role: string } | undefined;
  if (!row) throw new PartySessionError();
  if (result.rows.length !== 1) throw new PartyForbiddenError();
  if (!['OWNER','MANAGER','EMPLOYEE'].includes(row.role)) throw new PartyForbiddenError();
  return { companyId: row.id, actorId: row.actor_id, role: row.role };
}

function fields(input: PartyCreate): unknown[] {
  return [input.kind, input.is_client, input.is_supplier, input.display_name, input.contact_name, input.phone, input.email,
    input.address, input.city, input.postal_code, input.ice, input.tax_id, input.trade_register, input.professional_tax];
}

/** Staged confirmation preparation. The token itself is never stored in PostgreSQL. */
export async function preparePartyIceConfirmation(database: PartyDatabase, token: string, input: unknown, key: string, partyId?: string): Promise<{ token: string; duplicates: PartyRow[] } | null> {
  const party = validatePartyCreate(input);
  if (!/^[A-Za-z0-9_-]{16,100}$/.test(key)) throw new Error('invalid_idempotency_key');
  return transaction(database, async (client) => {
    const { companyId, actorId } = await editableCompany(client, token);
    let targetVersion: unknown = null;
    if (partyId) {
      const target = await client.query('SELECT version FROM public.parties WHERE company_id=$1 AND id=$2 FOR UPDATE',[companyId,partyId]);
      if (!target.rows.length) throw new PartyNotFoundError();
      targetVersion = (target.rows[0] as {version: unknown}).version;
    }
    if (!party.ice) return null;
    const duplicates = (await client.query(`SELECT id, version, status, display_name FROM public.parties
      WHERE company_id=$1 AND ice_normalized=replace(replace($2,' ',''),'-','') AND ($3::uuid IS NULL OR id<>$3) ORDER BY id FOR SHARE`, [companyId,party.ice,partyId ?? null])).rows as PartyRow[];
    if (!duplicates.length) return null;
    const action = partyId ? 'PARTY_UPDATED' : 'PARTY_CREATED';
    const requestFingerprint = hash(JSON.stringify(partyId ? {partyId,party} : party));
    const duplicateFingerprint = hash(JSON.stringify(duplicates));
    const prior = await client.query(`SELECT id,status,request_fingerprint FROM public.party_operations WHERE company_id=$1 AND actor_id=$2 AND action=$3 AND idempotency_key=$4`,[companyId,actorId,action,key]);
    const previous = prior.rows[0] as {id:string; status:string; request_fingerprint:string} | undefined;
    const confirmation = randomBytes(32).toString('base64url');
    if (previous) {
      if (previous.status !== 'AWAITING_CONFIRMATION' || previous.request_fingerprint !== requestFingerprint) throw new PartyConflictError();
      const refreshed = await client.query(`UPDATE public.party_ice_confirmations SET token_hash=$1
        WHERE company_id=$2 AND operation_id=$3 AND session_hash=$4 AND duplicate_fingerprint=$5
          AND target_party_id IS NOT DISTINCT FROM $6::uuid AND target_version IS NOT DISTINCT FROM $7::bigint
          AND consumed_at IS NULL AND expires_at>clock_timestamp() RETURNING id`,
        [hash(confirmation),companyId,previous.id,digestSessionToken(token),duplicateFingerprint,partyId ?? null,targetVersion]);
      if (!refreshed.rows.length) throw new PartyConflictError();
      return {token:confirmation,duplicates};
    }
    const operation = randomUUID();
    await client.query(`INSERT INTO public.party_operations (id,company_id,operation_reference,idempotency_key,actor_id,action,request_fingerprint,status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,'AWAITING_CONFIRMATION')`,[operation,companyId,randomUUID(),key,actorId,action,requestFingerprint]);
    await client.query(`INSERT INTO public.party_ice_confirmations(company_id,operation_id,token_hash,session_hash,duplicate_fingerprint,target_party_id,target_version,expires_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,now()+interval '5 minutes')`,[companyId,operation,hash(confirmation),digestSessionToken(token),duplicateFingerprint,partyId ?? null,targetVersion]);
    return { token: confirmation, duplicates };
  });
}

/** The company row is already locked, serializing retries and competing writes. */
async function idempotentWrite(client: RegistrationClient, companyId: string, actorId: string, action: string,
  key: string, request: unknown, write: () => Promise<PartyRow>, confirmation?: { token: string; sessionHash: string; duplicatesHash: string; targetId?: string; targetVersion?: unknown }): Promise<PartyRow> {
  if (!/^[A-Za-z0-9_-]{16,100}$/.test(key)) throw new Error('invalid_idempotency_key');
  const fingerprint = createHash('sha256').update(JSON.stringify(request)).digest('hex');
  const previous = await client.query(`SELECT o.id, o.request_fingerprint, o.status, r.result FROM public.party_operations o
    LEFT JOIN public.party_operation_receipts r ON r.company_id=o.company_id AND r.operation_id=o.id
    WHERE o.company_id=$1 AND o.actor_id=$2 AND o.action=$3 AND o.idempotency_key=$4`, [companyId, actorId, action, key]);
  const existing = previous.rows[0] as { id: string; request_fingerprint: string; status: string; result: PartyRow | null } | undefined;
  let operationId: string;
  if (existing) {
    if (existing.request_fingerprint !== fingerprint) throw new PartyConflictError();
    if (existing.status === 'SUCCEEDED' && existing.result) return existing.result;
    if (existing.status !== 'AWAITING_CONFIRMATION' || !confirmation || !/^[A-Za-z0-9_-]{43}$/.test(confirmation.token)) throw new PartyConflictError();
    const consumed = await client.query(`UPDATE public.party_ice_confirmations SET consumed_at=clock_timestamp()
      WHERE company_id=$1 AND operation_id=$2 AND token_hash=$3 AND session_hash=$4 AND duplicate_fingerprint=$5
      AND target_party_id IS NOT DISTINCT FROM $6::uuid AND target_version IS NOT DISTINCT FROM $7::bigint
      AND consumed_at IS NULL AND expires_at>clock_timestamp() RETURNING id`,
      [companyId,existing.id,hash(confirmation.token),confirmation.sessionHash,confirmation.duplicatesHash,confirmation.targetId ?? null,confirmation.targetVersion ?? null]);
    if (!consumed.rows.length) throw new PartyConflictError();
    operationId = existing.id;
  } else {
    if (confirmation) throw new PartyConflictError();
    operationId = randomUUID();
    await client.query(`INSERT INTO public.party_operations (id,company_id,operation_reference,idempotency_key,actor_id,action,request_fingerprint,status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,'PREPARED')`, [operationId,companyId,randomUUID(),key,actorId,action,fingerprint]);
  }
  const row = await write();
  await client.query(`INSERT INTO public.party_audit_events (company_id,party_id,operation_id,actor_id,event_type) VALUES ($1,$2,$3,$4,$5)`, [companyId,row.id,operationId,actorId,action]);
  await client.query(`INSERT INTO public.party_operation_receipts (company_id,operation_id,result,finalized_at) VALUES ($1,$2,$3,now())`, [companyId,operationId,JSON.stringify(row)]);
  await client.query(`UPDATE public.party_operations SET status='SUCCEEDED', finalized_at=now() WHERE company_id=$1 AND id=$2`, [companyId,operationId]);
  return row;
}

export async function createParty(database: PartyDatabase, token: string, input: unknown, key: string, confirmationToken?: string): Promise<PartyRow> {
  const party = validatePartyCreate(input);
  return transaction(database, async (client) => {
    const { companyId, actorId } = await editableCompany(client, token);
    let confirmation: {token:string; sessionHash:string; duplicatesHash:string} | undefined;
    if (confirmationToken) {
      if (!party.ice) throw new PartyConflictError();
      const rows = (await client.query(`SELECT id, version, status, display_name FROM public.parties
        WHERE company_id=$1 AND ice_normalized=replace(replace($2,' ',''),'-','') ORDER BY id FOR SHARE`,[companyId,party.ice])).rows;
      confirmation = { token:confirmationToken, sessionHash:digestSessionToken(token), duplicatesHash:hash(JSON.stringify(rows)) };
    }
    return idempotentWrite(client, companyId, actorId, 'PARTY_CREATED', key, party, async () => {
    if (party.ice) {
      const duplicate = await client.query(`SELECT id FROM public.parties WHERE company_id=$1 AND ice_normalized=replace(replace($2,' ',''),'-','') LIMIT 1 FOR SHARE`, [companyId, party.ice]);
      if (duplicate.rows.length && !confirmation) throw new PartyConflictError();
    }
    const result = await client.query(`INSERT INTO public.parties
      (company_id,kind,is_client,is_supplier,display_name,contact_name,phone,email,address,city,postal_code,ice,tax_id,trade_register,professional_tax)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
      RETURNING id,kind,status,display_name,contact_name,is_client,is_supplier,phone,email,address,city,postal_code,ice,tax_id,trade_register,professional_tax,country_code,version,created_at,updated_at`, [companyId, ...fields(party)]);
    const row = result.rows[0] as PartyRow | undefined;
    if (!row || typeof row.id !== 'string') throw new Error('party_insert_failed');
    return row;
    }, confirmation);
  });
}

export async function updateParty(database: PartyDatabase, token: string, partyId: string, input: unknown, key: string, confirmationToken?: string): Promise<PartyRow> {
  const party = validatePartyCreate(input);
  return transaction(database, async (client) => {
    const { companyId, actorId } = await editableCompany(client, token);
    let confirmation: {token:string; sessionHash:string; duplicatesHash:string; targetId:string; targetVersion:unknown} | undefined;
    if (confirmationToken) {
      if (!party.ice) throw new PartyConflictError();
      const target = await client.query('SELECT version FROM public.parties WHERE company_id=$1 AND id=$2 FOR UPDATE',[companyId,partyId]);
      if (!target.rows.length) throw new PartyNotFoundError();
      const rows = (await client.query(`SELECT id,version,status,display_name FROM public.parties WHERE company_id=$1
        AND ice_normalized=replace(replace($2,' ',''),'-','') AND id<>$3 ORDER BY id FOR SHARE`,[companyId,party.ice,partyId])).rows;
      confirmation={token:confirmationToken,sessionHash:digestSessionToken(token),duplicatesHash:hash(JSON.stringify(rows)),targetId:partyId,targetVersion:(target.rows[0] as {version:unknown}).version};
    }
    return idempotentWrite(client, companyId, actorId, 'PARTY_UPDATED', key, { partyId, party }, async () => {
    if (party.ice) {
      const duplicate = await client.query(`SELECT id FROM public.parties WHERE company_id=$1 AND ice_normalized=replace(replace($2,' ',''),'-','') AND id<>$3 LIMIT 1 FOR SHARE`, [companyId, party.ice, partyId]);
      if (duplicate.rows.length && !confirmation) throw new PartyConflictError();
    }
    const result = await client.query(`UPDATE public.parties SET kind=$3,is_client=$4,is_supplier=$5,display_name=$6,contact_name=$7,phone=$8,email=$9,address=$10,city=$11,postal_code=$12,ice=$13,tax_id=$14,trade_register=$15,professional_tax=$16,version=version+1,updated_at=now()
      WHERE id=$1 AND company_id=$2 RETURNING id,kind,status,display_name,contact_name,is_client,is_supplier,phone,email,address,city,postal_code,ice,tax_id,trade_register,professional_tax,country_code,version,created_at,updated_at`, [partyId, companyId, ...fields(party)]);
    const row = result.rows[0] as PartyRow | undefined;
    if (!row) throw new PartyNotFoundError();
    return row;
    }, confirmation);
  });
}

export async function archiveParty(database: PartyDatabase, token: string, partyId: string, key: string): Promise<void> {
  await transaction(database, async (client) => {
    const { companyId, actorId } = await editableCompany(client, token);
    await idempotentWrite(client, companyId, actorId, 'PARTY_ARCHIVED', key, { partyId }, async () => {
      const result = await client.query(`UPDATE public.parties SET status='ARCHIVED',version=version+1,updated_at=now() WHERE id=$1 AND company_id=$2 AND status='ACTIVE' RETURNING id,status,version`, [partyId, companyId]);
      const row = result.rows[0] as PartyRow | undefined;
      if (!row) throw new PartyNotFoundError();
      return row;
    });
  });
}

export async function reactivateParty(database: PartyDatabase, token: string, partyId: string, key: string): Promise<PartyRow> {
  return transaction(database, async client => {
    const {companyId,actorId,role} = await editableCompany(client,token);
    if (!['OWNER','MANAGER'].includes(role)) throw new PartyForbiddenError();
    return idempotentWrite(client,companyId,actorId,'PARTY_REACTIVATED',key,{partyId},async () => {
      const result = await client.query(`UPDATE public.parties SET status='ACTIVE',version=version+1,updated_at=now()
        WHERE company_id=$1 AND id=$2 AND status='ARCHIVED' RETURNING id,status,version`,[companyId,partyId]);
      const row=result.rows[0] as PartyRow | undefined; if (!row) throw new PartyNotFoundError(); return row;
    });
  });
}

export async function getPartyAudit(database: PartyDatabase, token: string, partyId: string): Promise<unknown[]> {
  return transaction(database, async client => {
    const {companyId,role} = await editableCompany(client,token);
    if (!['OWNER','MANAGER'].includes(role)) throw new PartyForbiddenError();
    const party = await client.query('SELECT id FROM public.parties WHERE company_id=$1 AND id=$2',[companyId,partyId]);
    if (!party.rows.length) throw new PartyNotFoundError();
    return (await client.query(`SELECT id,party_id,actor_id,event_type,occurred_at FROM public.party_audit_events
      WHERE company_id=$1 AND party_id=$2 ORDER BY occurred_at DESC,id DESC LIMIT 100`,[companyId,partyId])).rows;
  });
}
