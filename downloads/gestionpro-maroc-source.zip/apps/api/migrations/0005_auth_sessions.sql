-- GestionPro Maroc V1 / AUTH-02 - Local PostgreSQL session storage.
-- Prerequisites: applied migrations 0001 .. 0004.
-- Apply ONCE to gestionpro_dev only after confirming backup and prerequisites.
BEGIN;

CREATE TABLE public.auth_sessions (
    token_hash text PRIMARY KEY,
    user_id uuid NOT NULL REFERENCES public.users (id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    CONSTRAINT auth_sessions_token_sha256_valid
      CHECK (token_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT auth_sessions_expiration_valid
      CHECK (expires_at > created_at),
    CONSTRAINT auth_sessions_revocation_valid
      CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);

CREATE INDEX auth_sessions_active_user_idx
  ON public.auth_sessions (user_id, expires_at)
  WHERE revoked_at IS NULL;

COMMIT;
