BEGIN;
CREATE TABLE public.catalog_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id),
 kind text NOT NULL CHECK(kind IN ('PRODUCT','SERVICE')), reference text NOT NULL CHECK(length(reference) BETWEEN 1 AND 100),
 name text NOT NULL CHECK(length(name) BETWEEN 1 AND 200), description text NOT NULL DEFAULT '', category text NOT NULL DEFAULT '', unit text NOT NULL,
 price numeric(14,2) NOT NULL CHECK(price >= 0), tax_rate numeric(5,2) NOT NULL CHECK(tax_rate BETWEEN 0 AND 100),
 active boolean NOT NULL DEFAULT true, stock_info text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,reference), UNIQUE(company_id,id)
);
CREATE INDEX catalog_items_company_name_idx ON public.catalog_items(company_id,name);
COMMIT;
