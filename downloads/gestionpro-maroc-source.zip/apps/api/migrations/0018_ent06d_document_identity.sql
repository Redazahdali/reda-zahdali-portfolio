BEGIN;
CREATE TABLE public.company_document_logos (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
 png_bytes bytea NOT NULL CHECK (octet_length(png_bytes) BETWEEN 1 AND 2097152), sha256 text NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'), created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(company_id,id)
);
CREATE TABLE public.company_document_identity (
 company_id uuid PRIMARY KEY REFERENCES public.companies(id) ON DELETE RESTRICT,
 palette text NOT NULL DEFAULT 'EMERALD' CHECK (palette IN ('EMERALD','ROYAL_BLUE','ELEGANT_BLACK','SOLAR_YELLOW','GRAPHITE_GRAY','BORDEAUX','DYNAMIC_ORANGE','PREMIUM_PURPLE','TURQUOISE','NAVY_GOLD')),
 logo_id uuid, updated_at timestamptz NOT NULL DEFAULT now(), FOREIGN KEY(company_id,logo_id) REFERENCES public.company_document_logos(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE public.company_document_identity_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id), actor_id uuid NOT NULL REFERENCES public.users(id), palette text NOT NULL, logo_id uuid,
 occurred_at timestamptz NOT NULL DEFAULT now(), FOREIGN KEY(company_id,logo_id) REFERENCES public.company_document_logos(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE public.invoice_pdf_archives (
 company_id uuid NOT NULL, invoice_id uuid NOT NULL, template_version text NOT NULL, visual_snapshot jsonb NOT NULL, pdf_bytes bytea NOT NULL CHECK(octet_length(pdf_bytes)>0),
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(company_id,invoice_id), FOREIGN KEY(company_id,invoice_id) REFERENCES public.invoices(company_id,id) ON DELETE RESTRICT
);
CREATE FUNCTION public.ent06d_immutable_asset() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'immutable_document_asset' USING ERRCODE='23514'; END $$;
CREATE TRIGGER ent06d_immutable_logo BEFORE UPDATE OR DELETE ON public.company_document_logos FOR EACH ROW EXECUTE FUNCTION public.ent06d_immutable_asset();
CREATE TRIGGER ent06d_immutable_pdf BEFORE UPDATE OR DELETE ON public.invoice_pdf_archives FOR EACH ROW EXECUTE FUNCTION public.ent06d_immutable_asset();
COMMIT;
