-- Internal building block only: no public execution and no write endpoint.
-- The caller must pass a raw gp_session token through a protected parameter;
-- deployment must first review query/parameter logging and role ownership.
BEGIN;
CREATE FUNCTION public.ent03_verify_session(p_token text)
RETURNS TABLE(actor_id uuid, company_id uuid, member_role text)
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $function$
BEGIN
  IF p_token IS NULL OR p_token !~ '^[A-Za-z0-9_-]{43}$' THEN
    RAISE EXCEPTION 'unauthorized' USING ERRCODE = '28000';
  END IF;
  RETURN QUERY
    SELECT u.id, c.id, m.role
    FROM public.auth_sessions AS s
    JOIN public.users AS u ON u.id = s.user_id
    JOIN public.company_memberships AS m ON m.user_id = u.id
    JOIN public.companies AS c ON c.id = m.company_id
    WHERE s.token_hash = pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(p_token, 'UTF8')), 'hex')
      AND s.revoked_at IS NULL AND s.expires_at > pg_catalog.clock_timestamp()
      AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
      AND m.status = 'ACTIVE' AND m.role IN ('OWNER','MANAGER','EMPLOYEE')
      AND c.status = 'ACTIVE'
    FOR SHARE OF s, u, m, c;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'unauthorized' USING ERRCODE = '28000';
  END IF;
END;
$function$;
REVOKE ALL ON FUNCTION public.ent03_verify_session(text) FROM PUBLIC;
COMMIT;
