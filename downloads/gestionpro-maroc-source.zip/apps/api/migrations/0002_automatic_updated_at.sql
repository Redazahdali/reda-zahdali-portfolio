-- GestionPro Maroc V1 — DB-03.1
-- Horodatage automatique des mises à jour, PostgreSQL 17.
-- Appliquer UNE SEULE FOIS après 0001_companies_users_memberships.sql.
-- Ne crée ni comptes, ni rôles, ni mécanismes d'authentification.
-- Aucune 2FA, TOTP ni SMS.
-- Attention: cette migration ne garantit PAS la présence d'un OWNER actif.
-- Cette protection sera conçue/testée séparément.

BEGIN;

CREATE FUNCTION public.gestionpro_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at := statement_timestamp();
  RETURN NEW;
END;
$function$;

CREATE TRIGGER companies_set_updated_at
BEFORE UPDATE ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_set_updated_at();

CREATE TRIGGER users_set_updated_at
BEFORE UPDATE ON public.users
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_set_updated_at();

CREATE TRIGGER company_memberships_set_updated_at
BEFORE UPDATE ON public.company_memberships
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_set_updated_at();

COMMIT;
