BEGIN;
CREATE TABLE public.catalog_operation_receipts (
 company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
 actor_id uuid NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
 action text NOT NULL, idempotency_key text NOT NULL,
 fingerprint text NOT NULL, result jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(company_id,actor_id,action,idempotency_key)
);
COMMIT;
