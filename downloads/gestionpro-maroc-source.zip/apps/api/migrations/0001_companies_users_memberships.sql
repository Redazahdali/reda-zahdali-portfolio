-- GestionPro Maroc V1 — DB-02.1 — projet de migration initiale (PostgreSQL 17)
-- REVUE REQUISE AVANT EXECUTION. Ne pas appliquer automatiquement.
-- Tables strictement limitees a companies, users et company_memberships.
-- Les mots de passe, Google, sessions, invitations et permissions viennent ensuite.
-- Aucune 2FA / TOTP / SMS dans GestionPro.
-- L'application doit mettre updated_at a jour lors des modifications.
-- Aucune table n'existe au debut. Migration prevue pour etre executee UNE FOIS
-- par un futur mecanisme de migrations, apres validation.

BEGIN;

CREATE TABLE public.companies (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    status text NOT NULL DEFAULT 'SETUP_PENDING',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT companies_name_valid
      CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
    CONSTRAINT companies_status_valid
      CHECK (status IN ('SETUP_PENDING', 'ACTIVE', 'CANCELLATION_PENDING', 'CLOSED'))
);

CREATE TABLE public.users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text NOT NULL,
    email_verified_at timestamptz,
    status text NOT NULL DEFAULT 'PENDING_VERIFICATION',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT users_email_unique UNIQUE (email),
    CONSTRAINT users_email_normalized
      CHECK (email = lower(btrim(email))),
    CONSTRAINT users_email_shape_valid
      CHECK (
        char_length(email) BETWEEN 3 AND 320
        AND email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'
      ),
    CONSTRAINT users_status_valid
      CHECK (status IN ('PENDING_VERIFICATION', 'ACTIVE', 'DISABLED'))
);

CREATE TABLE public.company_memberships (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text NOT NULL,
    status text NOT NULL DEFAULT 'ACTIVE',
    joined_at timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT company_memberships_company_fk FOREIGN KEY (company_id)
      REFERENCES public.companies (id) ON DELETE RESTRICT,
    CONSTRAINT company_memberships_user_fk FOREIGN KEY (user_id)
      REFERENCES public.users (id) ON DELETE RESTRICT,
    CONSTRAINT company_memberships_one_company_per_user UNIQUE (user_id),
    CONSTRAINT company_memberships_role_valid
      CHECK (role IN ('OWNER', 'MANAGER', 'EMPLOYEE')),
    CONSTRAINT company_memberships_status_valid
      CHECK (status IN ('ACTIVE', 'DISABLED'))
);

CREATE INDEX company_memberships_company_lookup_idx
    ON public.company_memberships (company_id, status, role);

COMMIT;

-- Points a couvrir DANS LES PROCHAINES MICRO-ETAPES (non implementes ici) :
-- 1) Toujours au moins un OWNER actif par entreprise : protection transactionnelle
--    de toutes les operations de role/desactivation/suppression, avec verrouillage.
--    Un CHECK sur une ligne ne peut pas garantir cette condition inter-lignes.
-- 2) Creation atomique entreprise + OWNER, verif. email avant gestion d'entreprise.
-- 3) Autorisations serveur, RLS/tenant_id sur futures tables, journal d'audit.
-- 4) Gestion coherente des statuts, modification updated_at, politique de retention.
-- 5) Tester la migration sur la base LOCALE apres revue explicite, puis verifier
--    les contraintes et la compatibilite du futur moteur de migration.
