-- GestionPro Maroc V1 / AUTH-03 - one-time email verification and password reset.
-- Requires migrations 0001 .. 0005. Apply ONCE to local gestionpro_dev.
BEGIN;

CREATE TABLE public.email_action_tokens (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES public.users (id) ON DELETE RESTRICT,
    purpose text NOT NULL,
    token_hash text NOT NULL UNIQUE,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    superseded_at timestamptz,
    CONSTRAINT email_action_tokens_purpose_valid
      CHECK (purpose IN ('EMAIL_VERIFICATION', 'PASSWORD_RESET')),
    CONSTRAINT email_action_tokens_hash_valid
      CHECK (token_hash ~ '^[a-f0-9]{64}$'),
    CONSTRAINT email_action_tokens_expiry_valid
      CHECK (expires_at > created_at),
    CONSTRAINT email_action_tokens_consumed_valid
      CHECK (consumed_at IS NULL OR consumed_at >= created_at),
    CONSTRAINT email_action_tokens_superseded_valid
      CHECK (superseded_at IS NULL OR superseded_at >= created_at),
    CONSTRAINT email_action_tokens_terminal_exclusive
      CHECK (consumed_at IS NULL OR superseded_at IS NULL)
);

CREATE INDEX email_action_tokens_user_purpose_idx
  ON public.email_action_tokens (user_id, purpose, created_at DESC);

CREATE INDEX email_action_tokens_expiry_idx
  ON public.email_action_tokens (expires_at);

COMMIT;
