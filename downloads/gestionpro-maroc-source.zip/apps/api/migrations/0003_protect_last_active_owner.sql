-- GestionPro Maroc V1 - DB-04.2
-- Migration 0003: protection du dernier OWNER actif et habilite.
-- Requires 0001 and 0002. PostgreSQL 17.
-- PREPARATION: do not execute without explicit review and a local test plan.
-- No MFA/TOTP/SMS, no change to passwords, no change to BricoNow.
-- An effective OWNER has membership(role=OWNER,status=ACTIVE) AND
-- user(status=ACTIVE,email_verified_at IS NOT NULL).
-- Companies with status SETUP_PENDING may have no effective owner while onboarding.
-- Companies with status ACTIVE or CANCELLATION_PENDING must retain >=1.
-- Serializable/repeatable-read retry policy and service permissions: future API work.

BEGIN;

-- Refuse installation if protected companies already violate this invariant.
DO $check$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.companies c
    WHERE c.status IN ('ACTIVE', 'CANCELLATION_PENDING')
      AND NOT EXISTS (
        SELECT 1 FROM public.company_memberships m
        JOIN public.users u ON u.id = m.user_id
        WHERE m.company_id = c.id
          AND m.role = 'OWNER' AND m.status = 'ACTIVE'
          AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
      )
  ) THEN
    RAISE EXCEPTION 'Existing company without a verified active OWNER; repair data before applying migration 0003'
      USING ERRCODE = '23514';
  END IF;
END;
$check$;

-- Serialize potentially competing removals of the last effective OWNER
-- by locking the shared company row BEFORE the effective-owner check.
CREATE FUNCTION public.gestionpro_require_other_active_owner(
    p_company_id uuid,
    p_excluded_membership_id uuid
)
RETURNS void
LANGUAGE plpgsql
AS $function$
DECLARE
  v_company_status text;
  v_has_other boolean;
BEGIN
  SELECT status INTO v_company_status
  FROM public.companies
  WHERE id = p_company_id
  FOR UPDATE;

  IF NOT FOUND OR v_company_status NOT IN ('ACTIVE', 'CANCELLATION_PENDING') THEN
    RETURN;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM public.company_memberships m
    JOIN public.users u ON u.id = m.user_id
    WHERE m.company_id = p_company_id
      AND m.id <> p_excluded_membership_id
      AND m.role = 'OWNER'
      AND m.status = 'ACTIVE'
      AND u.status = 'ACTIVE'
      AND u.email_verified_at IS NOT NULL
  ) INTO v_has_other;

  IF NOT v_has_other THEN
    RAISE EXCEPTION 'Cannot remove the last effective OWNER of an active company'
      USING ERRCODE = '23514';
  END IF;
END;
$function$;

-- Prevent deleting, demoting, or disabling the last active OWNER membership.
-- Membership identity is immutable; account/ownership transfers use audited
-- role changes, not reassignment of an existing membership to another person.
CREATE FUNCTION public.gestionpro_guard_owner_membership()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF NEW.user_id IS DISTINCT FROM OLD.user_id
       OR NEW.company_id IS DISTINCT FROM OLD.company_id THEN
      RAISE EXCEPTION 'Membership identity cannot be changed'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  IF OLD.role = 'OWNER' AND OLD.status = 'ACTIVE' THEN
    IF TG_OP = 'DELETE' THEN
      PERFORM public.gestionpro_require_other_active_owner(OLD.company_id, OLD.id);
    ELSIF NEW.role <> 'OWNER' OR NEW.status <> 'ACTIVE' THEN
      PERFORM public.gestionpro_require_other_active_owner(OLD.company_id, OLD.id);
    END IF;
  END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER company_memberships_guard_last_owner
BEFORE UPDATE OR DELETE ON public.company_memberships
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_guard_owner_membership();

-- Disabling an account or removing its verified-email status must not
-- bypass the last-owner rule by leaving an unchanged membership row.
CREATE FUNCTION public.gestionpro_guard_owner_user()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
  v_membership_id uuid;
  v_company_id uuid;
BEGIN
  IF OLD.status = 'ACTIVE'
     AND OLD.email_verified_at IS NOT NULL
     AND (NEW.status <> 'ACTIVE' OR NEW.email_verified_at IS NULL) THEN
    SELECT m.id, m.company_id INTO v_membership_id, v_company_id
    FROM public.company_memberships m
    WHERE m.user_id = OLD.id
      AND m.role = 'OWNER' AND m.status = 'ACTIVE';

    IF FOUND THEN
      PERFORM public.gestionpro_require_other_active_owner(v_company_id, v_membership_id);
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER users_guard_last_owner
BEFORE UPDATE OF status, email_verified_at ON public.users
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_guard_owner_user();

-- A protected company cannot become ACTIVE/CANCELLATION_PENDING before
-- a verified, enabled OWNER has been created within its setup transaction.
CREATE FUNCTION public.gestionpro_guard_company_activation()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
  v_has_owner boolean;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status IN ('ACTIVE', 'CANCELLATION_PENDING') THEN
      RAISE EXCEPTION 'Create company in SETUP_PENDING; activate after verified OWNER exists'
        USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.status IN ('ACTIVE', 'CANCELLATION_PENDING')
     AND OLD.status NOT IN ('ACTIVE', 'CANCELLATION_PENDING') THEN
    SELECT EXISTS (
      SELECT 1 FROM public.company_memberships m
      JOIN public.users u ON u.id = m.user_id
      WHERE m.company_id = NEW.id
        AND m.role = 'OWNER' AND m.status = 'ACTIVE'
        AND u.status = 'ACTIVE' AND u.email_verified_at IS NOT NULL
    ) INTO v_has_owner;

    IF NOT v_has_owner THEN
      RAISE EXCEPTION 'Company activation requires an active verified OWNER'
        USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER companies_guard_activation
BEFORE INSERT OR UPDATE OF status ON public.companies
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_guard_company_activation();

COMMIT;

-- Remaining security work: OWNER transfer through authenticated support
-- workflow and audit, revocations, session enforcement, RLS/tenant isolation,
-- permission-limited DB role (no TRUNCATE/ALTER/DISABLE TRIGGER privileges),
-- and tested concurrency handling in the future API.
