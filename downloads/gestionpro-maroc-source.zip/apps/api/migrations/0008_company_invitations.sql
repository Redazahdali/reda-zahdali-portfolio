-- GestionPro Maroc V1 / ENT-02B - tenant-scoped, one-time collaborator invitations.
-- Requires migrations 0001 through 0007. Apply ONCE to local gestionpro_dev only.
BEGIN;

CREATE TABLE public.company_invitations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id uuid NOT NULL REFERENCES public.companies (id) ON DELETE RESTRICT,
    email text NOT NULL,
    proposed_role text NOT NULL,
    status text NOT NULL DEFAULT 'PENDING',
    token_hash text NOT NULL UNIQUE,
    created_by_user_id uuid NOT NULL REFERENCES public.users (id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    CONSTRAINT company_invitations_email_normalized CHECK (email = lower(btrim(email))),
    CONSTRAINT company_invitations_email_shape CHECK (
      char_length(email) BETWEEN 3 AND 320
      AND email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'
    ),
    CONSTRAINT company_invitations_role_valid CHECK (proposed_role IN ('MANAGER', 'EMPLOYEE')),
    CONSTRAINT company_invitations_status_valid CHECK (status IN ('PENDING', 'REVOKED', 'EXPIRED', 'ACCEPTED')),
    CONSTRAINT company_invitations_token_hash_valid CHECK (token_hash ~ '^[a-f0-9]{64}$'),
    CONSTRAINT company_invitations_expiry_valid CHECK (expires_at > created_at),
    CONSTRAINT company_invitations_revocation_valid CHECK (revoked_at IS NULL OR revoked_at >= created_at),
    CONSTRAINT company_invitations_revocation_state CHECK ((status = 'REVOKED') = (revoked_at IS NOT NULL))
);

-- At most one usable invitation per tenant/email; expired invitations are transitioned before issuance.
CREATE UNIQUE INDEX company_invitations_one_pending_email_idx
  ON public.company_invitations (company_id, email) WHERE status = 'PENDING';
CREATE INDEX company_invitations_company_status_idx
  ON public.company_invitations (company_id, status, created_at DESC);
CREATE INDEX company_invitations_expiry_idx ON public.company_invitations (expires_at) WHERE status = 'PENDING';

COMMIT;
