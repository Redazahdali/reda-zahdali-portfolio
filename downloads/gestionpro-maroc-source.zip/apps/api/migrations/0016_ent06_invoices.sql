BEGIN;
CREATE TABLE public.invoice_counters (company_id uuid PRIMARY KEY REFERENCES public.companies(id) ON DELETE RESTRICT, next_number bigint NOT NULL CHECK(next_number>0));
CREATE TABLE public.invoices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
 party_id uuid NOT NULL, source_quote_id uuid, source_quote_number text, status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','ISSUED')),
 invoice_number text, issued_on date, subject text NOT NULL, notes text NOT NULL DEFAULT '', terms text NOT NULL DEFAULT '',
 issuer_snapshot jsonb NOT NULL CHECK(jsonb_typeof(issuer_snapshot)='object'), client_snapshot jsonb NOT NULL CHECK(jsonb_typeof(client_snapshot)='object'),
 total_net numeric(18,2) NOT NULL CHECK(total_net>=0), total_tax numeric(18,2) NOT NULL CHECK(total_tax>=0), total_gross numeric(18,2) NOT NULL CHECK(total_gross>=0),
 version integer NOT NULL DEFAULT 1 CHECK(version>0), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,id), FOREIGN KEY(company_id,party_id) REFERENCES public.parties(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,source_quote_id) REFERENCES public.quotes(company_id,id) ON DELETE RESTRICT,
 CHECK ((status='DRAFT' AND invoice_number IS NULL AND issued_on IS NULL) OR (status='ISSUED' AND invoice_number IS NOT NULL AND issued_on IS NOT NULL))
);
CREATE UNIQUE INDEX invoices_number_unique ON public.invoices(company_id,invoice_number) WHERE invoice_number IS NOT NULL;
CREATE UNIQUE INDEX invoices_source_quote_unique ON public.invoices(company_id,source_quote_id) WHERE source_quote_id IS NOT NULL;
CREATE TABLE public.invoice_lines (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL, invoice_id uuid NOT NULL, catalog_item_id uuid, position integer NOT NULL CHECK(position>0),
 item_snapshot jsonb NOT NULL CHECK(jsonb_typeof(item_snapshot)='object'), quantity numeric(15,3) NOT NULL CHECK(quantity>0), unit_price numeric(14,2) NOT NULL CHECK(unit_price>=0),
 discount_rate numeric(5,2) NOT NULL CHECK(discount_rate BETWEEN 0 AND 100), tax_rate numeric(5,2) NOT NULL CHECK(tax_rate BETWEEN 0 AND 100),
 net_amount numeric(18,2) NOT NULL CHECK(net_amount>=0), tax_amount numeric(18,2) NOT NULL CHECK(tax_amount>=0),
 FOREIGN KEY(company_id,invoice_id) REFERENCES public.invoices(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,catalog_item_id) REFERENCES public.catalog_items(company_id,id) ON DELETE RESTRICT, UNIQUE(company_id,invoice_id,position)
);
CREATE TABLE public.invoice_receipts (company_id uuid NOT NULL REFERENCES public.companies(id), actor_id uuid NOT NULL REFERENCES public.users(id), action text NOT NULL, idempotency_key text NOT NULL, fingerprint text NOT NULL, result jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(company_id,actor_id,action,idempotency_key));
CREATE TABLE public.invoice_history (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL, invoice_id uuid NOT NULL, actor_id uuid NOT NULL REFERENCES public.users(id), event_type text NOT NULL, occurred_at timestamptz NOT NULL DEFAULT now(), details jsonb NOT NULL DEFAULT '{}'::jsonb, FOREIGN KEY(company_id,invoice_id) REFERENCES public.invoices(company_id,id) ON DELETE RESTRICT);
CREATE FUNCTION public.ent06_protect_invoice() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.status='ISSUED' THEN RAISE EXCEPTION 'issued_invoice_immutable' USING ERRCODE='23514'; END IF;
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'invoice_deletion_forbidden' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER ent06_invoice_immutable BEFORE UPDATE OR DELETE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.ent06_protect_invoice();
CREATE FUNCTION public.ent06_protect_invoice_line() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE parent_company uuid; parent_id uuid; parent_status text;
BEGIN
 IF TG_OP='INSERT' THEN parent_company:=NEW.company_id; parent_id:=NEW.invoice_id; ELSE parent_company:=OLD.company_id; parent_id:=OLD.invoice_id; END IF;
 SELECT status INTO parent_status FROM public.invoices WHERE company_id=parent_company AND id=parent_id FOR UPDATE;
 IF parent_status IS DISTINCT FROM 'DRAFT' THEN RAISE EXCEPTION 'issued_invoice_immutable' USING ERRCODE='23514'; END IF;
 IF TG_OP='UPDATE' AND (NEW.company_id,NEW.invoice_id) IS DISTINCT FROM (OLD.company_id,OLD.invoice_id) THEN RAISE EXCEPTION 'invoice_line_move_forbidden' USING ERRCODE='23514'; END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;
CREATE TRIGGER ent06_invoice_line_immutable BEFORE INSERT OR UPDATE OR DELETE ON public.invoice_lines FOR EACH ROW EXECUTE FUNCTION public.ent06_protect_invoice_line();
COMMIT;
