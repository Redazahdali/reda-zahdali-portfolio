-- GestionPro Maroc V1 - AUTH-01
-- Password credentials, separate from user identity.
-- Requires migrations 0001 and 0002.
BEGIN;

CREATE TABLE public.user_password_credentials (
    user_id uuid PRIMARY KEY,
    password_hash text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),

    CONSTRAINT user_password_credentials_user_fk
      FOREIGN KEY (user_id)
      REFERENCES public.users (id)
      ON DELETE RESTRICT,

    CONSTRAINT user_password_credentials_hash_valid
      CHECK (
        char_length(password_hash) BETWEEN 50 AND 512
        AND password_hash LIKE '$argon2id$%'
      )
);

CREATE TRIGGER user_password_credentials_set_updated_at
BEFORE UPDATE ON public.user_password_credentials
FOR EACH ROW
EXECUTE FUNCTION public.gestionpro_set_updated_at();

COMMIT;