BEGIN;
CREATE TABLE public.quotes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
 party_id uuid NOT NULL, status text NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SENT','ACCEPTED','REJECTED','CANCELLED')),
 client_snapshot jsonb NOT NULL CHECK(jsonb_typeof(client_snapshot)='object'),
 currency char(3) NOT NULL DEFAULT 'MAD', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,id), FOREIGN KEY(company_id,party_id) REFERENCES public.parties(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE public.quote_lines (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL, quote_id uuid NOT NULL, catalog_item_id uuid,
 position integer NOT NULL CHECK(position > 0), item_snapshot jsonb NOT NULL CHECK(jsonb_typeof(item_snapshot)='object'),
 quantity numeric(15,3) NOT NULL CHECK(quantity > 0), unit_price numeric(14,2) NOT NULL CHECK(unit_price >= 0),
 discount_rate numeric(5,2) NOT NULL CHECK(discount_rate BETWEEN 0 AND 100), tax_rate numeric(5,2) NOT NULL CHECK(tax_rate BETWEEN 0 AND 100),
 net_amount numeric(18,2) NOT NULL CHECK(net_amount >= 0), tax_amount numeric(18,2) NOT NULL CHECK(tax_amount >= 0),
 FOREIGN KEY(company_id,quote_id) REFERENCES public.quotes(company_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(company_id,catalog_item_id) REFERENCES public.catalog_items(company_id,id) ON DELETE RESTRICT,
 UNIQUE(company_id,quote_id,position)
);
CREATE TABLE public.quote_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL, quote_id uuid NOT NULL,
 actor_id uuid NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT, event_type text NOT NULL,
 occurred_at timestamptz NOT NULL DEFAULT now(), details jsonb NOT NULL DEFAULT '{}'::jsonb,
 FOREIGN KEY(company_id,quote_id) REFERENCES public.quotes(company_id,id) ON DELETE RESTRICT
);
COMMIT;
