BEGIN;
DROP INDEX IF EXISTS public.invoices_source_quote_unique;
CREATE INDEX IF NOT EXISTS invoices_source_quote_lookup ON public.invoices(company_id, source_quote_id) WHERE source_quote_id IS NOT NULL;
COMMIT;
