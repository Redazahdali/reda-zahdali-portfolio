BEGIN;
ALTER TABLE public.quotes ADD COLUMN quote_number text;
ALTER TABLE public.quotes ADD COLUMN issued_on date;
ALTER TABLE public.quotes ADD COLUMN valid_until date;
ALTER TABLE public.quotes ADD COLUMN subject text NOT NULL DEFAULT '';
ALTER TABLE public.quotes ADD COLUMN notes text NOT NULL DEFAULT '';
ALTER TABLE public.quotes ADD COLUMN terms text NOT NULL DEFAULT '';
ALTER TABLE public.quotes ADD COLUMN version integer NOT NULL DEFAULT 1 CHECK (version > 0);
ALTER TABLE public.quotes ADD COLUMN issuer_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(issuer_snapshot) = 'object');
ALTER TABLE public.quotes ADD COLUMN total_net numeric(18,2) NOT NULL DEFAULT 0 CHECK (total_net >= 0);
ALTER TABLE public.quotes ADD COLUMN total_tax numeric(18,2) NOT NULL DEFAULT 0 CHECK (total_tax >= 0);
ALTER TABLE public.quotes ADD COLUMN total_gross numeric(18,2) NOT NULL DEFAULT 0 CHECK (total_gross >= 0);
CREATE UNIQUE INDEX quotes_company_number_idx ON public.quotes(company_id,quote_number) WHERE quote_number IS NOT NULL;
CREATE TABLE public.quote_counters (company_id uuid PRIMARY KEY REFERENCES public.companies(id), next_number bigint NOT NULL CHECK (next_number > 0));
CREATE TABLE public.quote_receipts (
 company_id uuid NOT NULL REFERENCES public.companies(id), actor_id uuid NOT NULL REFERENCES public.users(id),
 action text NOT NULL, idempotency_key text NOT NULL, fingerprint text NOT NULL, result jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(company_id,actor_id,action,idempotency_key)
);
COMMIT;
