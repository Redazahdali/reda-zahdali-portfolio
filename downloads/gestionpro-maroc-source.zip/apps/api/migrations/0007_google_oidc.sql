-- GestionPro Maroc V1 / AUTH-04 - Google OIDC: server-side PKCE flow + stable subject link.
-- Requires migrations 0001 through 0006. Apply ONCE, local gestionpro_dev only.
-- No OAuth refresh/access/ID token or Google client secret is stored in these tables.
BEGIN;

CREATE TABLE public.google_oidc_flows (
    state_hash text PRIMARY KEY,
    nonce text NOT NULL,
    code_verifier text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    consumed_at timestamptz,
    CONSTRAINT google_oidc_flow_state_hash_valid CHECK (state_hash ~ '^[a-f0-9]{64}$'),
    CONSTRAINT google_oidc_flow_nonce_valid CHECK (nonce ~ '^[A-Za-z0-9_-]{43}$'),
    CONSTRAINT google_oidc_flow_pkce_valid CHECK (code_verifier ~ '^[A-Za-z0-9_-]{43,128}$'),
    CONSTRAINT google_oidc_flow_expires_valid CHECK (expires_at > created_at),
    CONSTRAINT google_oidc_flow_consumed_valid CHECK (consumed_at IS NULL OR consumed_at >= created_at)
);
CREATE INDEX google_oidc_flows_expiry_idx ON public.google_oidc_flows (expires_at);

CREATE TABLE public.google_identities (
    google_sub text PRIMARY KEY,
    user_id uuid NOT NULL UNIQUE REFERENCES public.users (id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT google_identities_sub_valid CHECK (char_length(google_sub) BETWEEN 1 AND 255)
);

COMMIT;
