-- ENT-03 structural preparation only. Do not expose writes until controlled
-- functions, Unicode parity and privileges have been reviewed and tested.
BEGIN;
CREATE TABLE public.parties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
  kind text NOT NULL CHECK (kind IN ('PERSON','BUSINESS')),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','ARCHIVED')),
  is_client boolean NOT NULL, is_supplier boolean NOT NULL,
  display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 200),
  contact_name text CHECK (char_length(contact_name) BETWEEN 1 AND 200),
  phone text CHECK (char_length(phone) BETWEEN 1 AND 50),
  email text CHECK (char_length(email) BETWEEN 1 AND 320),
  address text CHECK (char_length(address) BETWEEN 1 AND 500),
  city text CHECK (char_length(city) BETWEEN 1 AND 120),
  postal_code text CHECK (char_length(postal_code) BETWEEN 1 AND 30),
  ice text CHECK (char_length(ice) BETWEEN 1 AND 100),
  ice_normalized text GENERATED ALWAYS AS (replace(replace(ice, ' ', ''), '-', '')) STORED,
  tax_id text CHECK (char_length(tax_id) BETWEEN 1 AND 100),
  trade_register text CHECK (char_length(trade_register) BETWEEN 1 AND 100),
  professional_tax text CHECK (char_length(professional_tax) BETWEEN 1 AND 100),
  country_code text NOT NULL DEFAULT 'MA' CHECK (country_code = 'MA'),
  version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id,id),
  CHECK (is_client OR is_supplier),
  CHECK (kind <> 'BUSINESS' OR contact_name IS NOT NULL),
  CHECK (ice IS NULL OR (ice ~ '^[0-9]([ -]?[0-9])*$' AND length(replace(replace(ice, ' ', ''), '-', '')) = 15))
);
CREATE INDEX parties_company_status_idx ON public.parties(company_id,status,id);
CREATE INDEX parties_company_ice_idx ON public.parties(company_id,ice_normalized) WHERE ice IS NOT NULL;
CREATE TABLE public.party_document_usage (
  company_id uuid NOT NULL, party_id uuid NOT NULL, first_used_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(company_id,party_id),
  FOREIGN KEY(company_id,party_id) REFERENCES public.parties(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE public.party_operations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE RESTRICT,
  operation_reference uuid NOT NULL UNIQUE, idempotency_key text NOT NULL,
  actor_id uuid NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  action text NOT NULL, request_fingerprint text NOT NULL,
  status text NOT NULL CHECK(status IN ('PREPARED','AWAITING_CONFIRMATION','SUCCEEDED','EXPIRED','CANCELLED')),
  created_at timestamptz NOT NULL DEFAULT now(), finalized_at timestamptz,
  UNIQUE(company_id,id), UNIQUE(company_id,actor_id,action,idempotency_key)
);
CREATE TABLE public.party_audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL,
  party_id uuid, operation_id uuid NOT NULL, actor_id uuid, event_type text NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(company_id,operation_id) REFERENCES public.party_operations(company_id,id) ON DELETE RESTRICT
);
CREATE INDEX party_audit_events_company_party_idx ON public.party_audit_events(company_id,party_id,occurred_at);
CREATE TABLE public.party_ice_confirmations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL, operation_id uuid NOT NULL,
  token_hash text NOT NULL UNIQUE CHECK(token_hash ~ '^[0-9a-f]{64}$'),
  session_hash text NOT NULL CHECK(session_hash ~ '^[0-9a-f]{64}$'),
  target_party_id uuid, target_version bigint, duplicate_fingerprint text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL,
  consumed_at timestamptz,
  FOREIGN KEY(company_id,operation_id) REFERENCES public.party_operations(company_id,id) ON DELETE RESTRICT,
  CHECK(expires_at > created_at), CHECK(consumed_at IS NULL OR consumed_at >= created_at)
);
CREATE TABLE public.party_operation_receipts (
  company_id uuid NOT NULL, operation_id uuid NOT NULL, result jsonb NOT NULL,
  finalized_at timestamptz NOT NULL, PRIMARY KEY(company_id,operation_id),
  FOREIGN KEY(company_id,operation_id) REFERENCES public.party_operations(company_id,id) ON DELETE RESTRICT
);
CREATE TABLE public.ent03_security_state (
  singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton), generation bigint NOT NULL DEFAULT 1 CHECK(generation > 0),
  suspended boolean NOT NULL DEFAULT false, changed_at timestamptz NOT NULL DEFAULT now()
);
COMMIT;
