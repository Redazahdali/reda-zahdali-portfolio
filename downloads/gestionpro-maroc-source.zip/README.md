# GestionPro Maroc — code source

Application web React et API Express/TypeScript avec PostgreSQL. Export de développement ; les tests, données et configurations locales ne sont pas inclus.

## Démarrage local

Prérequis : Node.js 22.12 ou supérieur, npm et Docker Compose. Depuis le dossier extrait dans PowerShell :

```powershell
Copy-Item .env.compose.example .env.compose
Copy-Item apps/api/.env.example apps/api/.env
docker compose --env-file .env.compose up -d db
npm ci
npm run dev
```

L’interface est accessible sur http://127.0.0.1:5173 et la santé de la base via http://127.0.0.1:5000/api/v1/ready. Les identifiants fournis sont fictifs et réservés au développement local. Les migrations SQL sont dans `apps/api/migrations` ; examinez leurs dépendances et appliquez-les dans l’ordre avant d’utiliser les fonctions métier. L’authentification externe et l’envoi de courriels nécessitent votre propre configuration ; aucun identifiant réel n’est fourni. Ce projet est en cours de développement.
