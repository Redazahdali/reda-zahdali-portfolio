ALTER TABLE parcel_orders DROP CONSTRAINT parcel_orders_status_check;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_orders_status_check CHECK (status IN ('DRAFT','DISCOVERY'));
ALTER TABLE parcel_orders ADD COLUMN description varchar(500);
ALTER TABLE parcel_orders ADD COLUMN discovery_published_at timestamptz;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_orders_discovery_check CHECK (status <> 'DISCOVERY' OR (description IS NOT NULL AND char_length(trim(description)) >= 3 AND discovery_published_at IS NOT NULL));
CREATE INDEX parcel_orders_discovery_idx ON parcel_orders (discovery_published_at DESC) WHERE status='DISCOVERY';
