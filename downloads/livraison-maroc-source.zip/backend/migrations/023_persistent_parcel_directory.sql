-- Published requests stay available until they are assigned or cancelled.
-- Keep the previous deadline for audit and leave cancelled/assigned orders alone.
ALTER TABLE parcel_searches ADD COLUMN previous_search_deadline timestamptz;
ALTER TABLE parcel_searches ALTER COLUMN deadline DROP NOT NULL;

UPDATE parcel_searches s
SET previous_search_deadline = s.deadline,
    deadline = NULL,
    status = CASE WHEN s.status = 'EXHAUSTED' THEN 'SEARCHING' ELSE s.status END,
    updated_at = now()
FROM parcel_orders o, parcel_manual_prices m
WHERE s.order_id = o.id
  AND m.order_id = o.id
  AND s.status IN ('SEARCHING', 'EXHAUSTED', 'OFFER_PENDING')
  AND o.status = 'DRAFT'
  AND m.delivery_status IS NULL;
