CREATE TABLE parcel_manual_messages (
 id uuid PRIMARY KEY,
 order_id uuid NOT NULL REFERENCES parcel_manual_prices(order_id),
 sender_id uuid NOT NULL REFERENCES auth_accounts(id),
 body varchar(1000) NOT NULL CHECK(char_length(trim(body)) BETWEEN 1 AND 1000),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX parcel_manual_messages_order_idx ON parcel_manual_messages(order_id,created_at);
