ALTER TABLE parcel_manual_prices ADD COLUMN pickup_requested_at timestamptz;
ALTER TABLE parcel_manual_prices ADD COLUMN delivery_requested_at timestamptz;
