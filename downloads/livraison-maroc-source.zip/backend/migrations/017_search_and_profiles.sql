CREATE TABLE account_contact_profiles (
 account_id uuid PRIMARY KEY REFERENCES auth_accounts(id),
 name varchar(120) NOT NULL CHECK (char_length(trim(name)) BETWEEN 2 AND 120),
 phone varchar(25) NOT NULL,
 vehicle text CHECK(vehicle IN ('MOTO','VOITURE','PICK-UP')),
 capacity_kg numeric(7,2) CHECK(capacity_kg > 0 AND capacity_kg <= 10000),
 max_size text CHECK(max_size IN ('SMALL','MEDIUM','LARGE')),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK ((vehicle IS NULL AND capacity_kg IS NULL AND max_size IS NULL) OR (vehicle IS NOT NULL AND capacity_kg IS NOT NULL AND max_size IS NOT NULL))
);
ALTER TABLE driver_profiles ADD COLUMN location_latitude double precision CHECK(location_latitude BETWEEN -90 AND 90);
ALTER TABLE driver_profiles ADD COLUMN location_longitude double precision CHECK(location_longitude BETWEEN -180 AND 180);
ALTER TABLE parcel_manual_prices ADD COLUMN weight_kg numeric(7,2) CHECK(weight_kg > 0 AND weight_kg <= 10000);
CREATE TABLE parcel_searches (
 order_id uuid PRIMARY KEY REFERENCES parcel_orders(id),
 status text NOT NULL CHECK(status IN ('SEARCHING','OFFER_PENDING','EXHAUSTED','ASSIGNED','CANCELLED')),
 started_at timestamptz NOT NULL DEFAULT now(),
 cycle integer NOT NULL DEFAULT 1,
 deadline timestamptz NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE parcel_solicitations (
 id uuid PRIMARY KEY, order_id uuid NOT NULL REFERENCES parcel_searches(order_id), driver_id uuid NOT NULL REFERENCES auth_accounts(id),
 cycle integer NOT NULL, status text NOT NULL CHECK(status IN ('PENDING','DECLINED','EXPIRED','OFFERED','REJECTED','ACCEPTED','CLOSED')),
 offered_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL,
 counter_price_dh integer CHECK(counter_price_dh BETWEEN 1 AND 100000), counter_expires_at timestamptz,
 approach_m double precision NOT NULL CHECK(approach_m>=0),
 UNIQUE(order_id,driver_id,cycle)
);
CREATE UNIQUE INDEX parcel_one_solicitation_per_order ON parcel_solicitations(order_id) WHERE status IN ('PENDING','OFFERED');
CREATE UNIQUE INDEX parcel_one_solicitation_per_driver ON parcel_solicitations(driver_id) WHERE status IN ('PENDING','OFFERED');
