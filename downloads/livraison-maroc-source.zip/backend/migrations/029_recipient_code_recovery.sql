ALTER TABLE recipient_tracking_codes ADD COLUMN encrypted_code text;
