ALTER TABLE parcel_orders DROP CONSTRAINT parcel_orders_status_check;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_orders_status_check CHECK (status IN ('DRAFT','DISCOVERY','ASSIGNED'));
ALTER TABLE parcel_orders ADD COLUMN assignment_disclosure_at timestamptz;
ALTER TABLE parcel_orders ADD COLUMN assigned_driver_id uuid REFERENCES auth_accounts(id);
ALTER TABLE parcel_orders ADD COLUMN assigned_at timestamptz;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_assignment_integrity CHECK ((status='ASSIGNED' AND assigned_driver_id IS NOT NULL AND assigned_at IS NOT NULL AND assignment_disclosure_at IS NOT NULL) OR (status<>'ASSIGNED' AND assigned_driver_id IS NULL AND assigned_at IS NULL));
CREATE UNIQUE INDEX parcel_orders_one_active_per_driver ON parcel_orders(assigned_driver_id) WHERE status='ASSIGNED';
CREATE TABLE parcel_assignment_events(id uuid PRIMARY KEY,order_id uuid NOT NULL REFERENCES parcel_orders(id),driver_id uuid NOT NULL REFERENCES auth_accounts(id),event_type text NOT NULL CHECK (event_type='ASSIGNED'),created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(order_id,event_type));
