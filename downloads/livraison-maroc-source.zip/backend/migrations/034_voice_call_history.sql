CREATE TABLE parcel_voice_call_history (
 id uuid PRIMARY KEY,
 order_id uuid NOT NULL REFERENCES parcel_orders(id) ON DELETE CASCADE,
 caller_id uuid NOT NULL REFERENCES auth_accounts(id),
 callee_id uuid NOT NULL REFERENCES auth_accounts(id),
 started_at timestamptz NOT NULL DEFAULT now(),
 CHECK (caller_id <> callee_id)
);
CREATE INDEX parcel_voice_call_history_caller ON parcel_voice_call_history(caller_id, started_at DESC);
CREATE INDEX parcel_voice_call_history_callee ON parcel_voice_call_history(callee_id, started_at DESC);
