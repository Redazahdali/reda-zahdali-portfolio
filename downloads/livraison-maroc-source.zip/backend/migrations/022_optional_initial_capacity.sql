-- Allow a driver to complete the initial profile before entering capacity.
DO $$
DECLARE constraint_name text;
BEGIN
 SELECT conname INTO constraint_name FROM pg_constraint
 WHERE conrelid = 'account_contact_profiles'::regclass AND contype = 'c'
   AND pg_get_constraintdef(oid) LIKE '%vehicle IS NULL%capacity_kg IS NULL%max_size IS NULL%';
 IF constraint_name IS NOT NULL THEN
  EXECUTE format('ALTER TABLE account_contact_profiles DROP CONSTRAINT %I', constraint_name);
 END IF;
END $$;
ALTER TABLE account_contact_profiles ADD CONSTRAINT account_contact_profiles_vehicle_size_check
 CHECK ((vehicle IS NULL AND capacity_kg IS NULL AND max_size IS NULL) OR (vehicle IS NOT NULL AND max_size IS NOT NULL));
