CREATE TABLE auth_firebase_identities (
  role text NOT NULL CHECK (role IN ('CLIENT','LIVREUR')),
  firebase_uid text NOT NULL,
  account_id uuid NOT NULL UNIQUE,
  PRIMARY KEY (role, firebase_uid),
  FOREIGN KEY (account_id, role) REFERENCES auth_accounts(id, role) ON DELETE CASCADE
);
