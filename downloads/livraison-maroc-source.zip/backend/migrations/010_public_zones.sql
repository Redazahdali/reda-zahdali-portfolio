ALTER TABLE parcel_orders ADD COLUMN pickup_public_zone text;
ALTER TABLE parcel_orders ADD COLUMN destination_public_zone text;
ALTER TABLE parcel_orders ADD COLUMN public_zones_consented_at timestamptz;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_public_zones_integrity CHECK ((public_zones_consented_at IS NULL AND pickup_public_zone IS NULL AND destination_public_zone IS NULL) OR (public_zones_consented_at IS NOT NULL AND pickup_public_zone IS NOT NULL AND destination_public_zone IS NOT NULL));
