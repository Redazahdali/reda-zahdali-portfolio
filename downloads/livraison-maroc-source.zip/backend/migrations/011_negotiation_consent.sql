ALTER TABLE parcel_orders ADD COLUMN negotiation_consented_at timestamptz;
