-- Keep all missions; replace the one-active-mission constraint with a lookup index.
CREATE INDEX parcel_manual_active_driver
  ON parcel_manual_prices(assigned_driver_id)
  WHERE delivery_status IN ('ASSIGNED', 'PICKED_UP');
DROP INDEX parcel_manual_one_active_driver;

-- Previously, accepting a manual mission automatically set the driver to BUSY.
-- Restore the availability they had at acceptance; never change an offline driver.
UPDATE driver_profiles d
SET availability = 'AVAILABLE', updated_at = now()
WHERE d.approval_status = 'APPROVED'
  AND d.availability = 'BUSY'
  AND EXISTS (
    SELECT 1 FROM parcel_manual_prices m
    WHERE m.assigned_driver_id = d.account_id
      AND m.delivery_status IN ('ASSIGNED', 'PICKED_UP')
  )
  AND NOT EXISTS (
    SELECT 1 FROM parcel_orders o
    WHERE o.assigned_driver_id = d.account_id AND o.status = 'ASSIGNED'
  );
