CREATE TABLE parcel_voice_calls (
 id uuid PRIMARY KEY,
 order_id uuid NOT NULL REFERENCES parcel_orders(id) ON DELETE CASCADE,
 caller_id uuid NOT NULL REFERENCES auth_accounts(id),
 callee_id uuid NOT NULL REFERENCES auth_accounts(id),
 state text NOT NULL CHECK (state IN ('ringing','active','ended')),
 created_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL,
 ended_at timestamptz,
 CHECK (caller_id <> callee_id)
);
CREATE UNIQUE INDEX parcel_voice_calls_one_active_order ON parcel_voice_calls(order_id) WHERE state IN ('ringing','active');
CREATE INDEX parcel_voice_calls_cleanup ON parcel_voice_calls(expires_at);
CREATE TABLE parcel_voice_signals (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 call_id uuid NOT NULL REFERENCES parcel_voice_calls(id) ON DELETE CASCADE,
 sender_id uuid NOT NULL REFERENCES auth_accounts(id),
 kind text NOT NULL CHECK (kind IN ('offer','answer','candidate')),
 payload jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX parcel_voice_signals_call_id ON parcel_voice_signals(call_id,id);
