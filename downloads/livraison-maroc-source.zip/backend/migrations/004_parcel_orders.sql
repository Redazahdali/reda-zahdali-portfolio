CREATE TABLE parcel_orders (
 id uuid PRIMARY KEY,
 client_id uuid NOT NULL REFERENCES auth_accounts(id),
 request_key varchar(100) NOT NULL,
 request_hash char(64) NOT NULL,
 status text NOT NULL DEFAULT 'DRAFT' CHECK (status = 'DRAFT'),
 pickup_address varchar(300) NOT NULL,
 pickup_longitude double precision NOT NULL CHECK (pickup_longitude BETWEEN -180 AND 180),
 pickup_latitude double precision NOT NULL CHECK (pickup_latitude BETWEEN -90 AND 90),
 destination_address varchar(300) NOT NULL,
 destination_longitude double precision NOT NULL CHECK (destination_longitude BETWEEN -180 AND 180),
 destination_latitude double precision NOT NULL CHECK (destination_latitude BETWEEN -90 AND 90),
 recipient_name varchar(120) NOT NULL,
 recipient_phone varchar(25) NOT NULL,
 weight_category text NOT NULL CHECK (weight_category IN ('UNDER_1_KG','ONE_TO_5_KG','FIVE_TO_20_KG','OVER_20_KG')),
 size_category text NOT NULL CHECK (size_category IN ('SMALL','MEDIUM','LARGE')),
 fragile boolean NOT NULL DEFAULT false,
 instructions varchar(1000) NOT NULL DEFAULT '',
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(client_id, request_key)
);
CREATE INDEX parcel_orders_client_created_idx ON parcel_orders (client_id, created_at DESC);
