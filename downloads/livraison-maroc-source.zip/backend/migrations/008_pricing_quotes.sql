CREATE TABLE pricing_quotes (
 id uuid PRIMARY KEY, client_id uuid NOT NULL REFERENCES auth_accounts(id), points_hash char(64) NOT NULL,
 distance_m integer NOT NULL CHECK(distance_m>=0), recommended_dh integer NOT NULL CHECK(recommended_dh>=10),
 rate_version text NOT NULL, rounding_rule text NOT NULL, minimum_dh integer NOT NULL, maximum_dh integer NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL
);
ALTER TABLE parcel_orders ADD COLUMN pricing_quote_id uuid REFERENCES pricing_quotes(id);
ALTER TABLE parcel_orders ADD COLUMN proposed_price_dh integer;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_price_integrity CHECK ((pricing_quote_id IS NULL AND proposed_price_dh IS NULL) OR (pricing_quote_id IS NOT NULL AND proposed_price_dh BETWEEN 1 AND 100000));
CREATE TABLE parcel_pricing_history(id uuid PRIMARY KEY,order_id uuid NOT NULL REFERENCES parcel_orders(id),quote_id uuid NOT NULL REFERENCES pricing_quotes(id),proposed_price_dh integer NOT NULL,created_at timestamptz NOT NULL DEFAULT now());
