ALTER TABLE pricing_quotes ADD COLUMN route_source text;
ALTER TABLE pricing_quotes ADD CONSTRAINT pricing_quote_route_source_check CHECK (route_source IS NULL OR route_source IN ('OSRM_DEMO','TEST_DOUBLE'));
