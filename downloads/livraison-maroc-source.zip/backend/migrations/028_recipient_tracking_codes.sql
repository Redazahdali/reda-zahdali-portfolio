CREATE TABLE recipient_tracking_codes (
 order_id uuid PRIMARY KEY REFERENCES parcel_orders(id) ON DELETE CASCADE,
 code_hash text NOT NULL UNIQUE,
 expires_at timestamptz NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
