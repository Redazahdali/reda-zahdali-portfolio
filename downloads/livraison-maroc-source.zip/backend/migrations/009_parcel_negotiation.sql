ALTER TABLE parcel_orders DROP CONSTRAINT parcel_orders_status_check;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_orders_status_check CHECK (status IN ('DRAFT','DISCOVERY','ASSIGNED','CANCELLED'));
ALTER TABLE parcel_orders ADD COLUMN agreed_price_dh integer CHECK (agreed_price_dh BETWEEN 1 AND 100000);
CREATE TABLE parcel_negotiation_offers (
 id uuid PRIMARY KEY, order_id uuid NOT NULL REFERENCES parcel_orders(id), driver_id uuid NOT NULL REFERENCES auth_accounts(id),
 request_key varchar(100) NOT NULL, amount_dh integer NOT NULL CHECK(amount_dh BETWEEN 1 AND 100000),
 status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','ACCEPTED','REJECTED','EXPIRED','CLOSED')),
 created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL DEFAULT now()+interval '10 minutes',
 UNIQUE(driver_id,request_key)
);
CREATE UNIQUE INDEX parcel_one_pending_offer_per_driver ON parcel_negotiation_offers(order_id,driver_id) WHERE status='PENDING';
CREATE TABLE parcel_negotiation_events (
 id uuid PRIMARY KEY, order_id uuid NOT NULL REFERENCES parcel_orders(id), offer_id uuid REFERENCES parcel_negotiation_offers(id),
 actor_id uuid NOT NULL REFERENCES auth_accounts(id), event_type text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
