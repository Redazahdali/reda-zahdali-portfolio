CREATE TABLE parcel_manual_location (
 order_id uuid PRIMARY KEY REFERENCES parcel_manual_prices(order_id),
 driver_id uuid NOT NULL REFERENCES auth_accounts(id),
 latitude double precision NOT NULL CHECK(latitude BETWEEN -90 AND 90),
 longitude double precision NOT NULL CHECK(longitude BETWEEN -180 AND 180),
 captured_at timestamptz NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
