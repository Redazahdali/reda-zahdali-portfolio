ALTER TABLE parcel_manual_prices ADD COLUMN location_sharing boolean NOT NULL DEFAULT false;
