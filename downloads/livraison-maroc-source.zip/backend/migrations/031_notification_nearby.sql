CREATE FUNCTION notify_search_published() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.status='SEARCHING' AND (TG_OP='INSERT' OR NEW.cycle IS DISTINCT FROM OLD.cycle) THEN
  INSERT INTO app_notifications(account_id,order_id,kind,event_key)
  SELECT d.account_id,NEW.order_id,'delivery_available','available:'||NEW.order_id||':'||NEW.cycle
  FROM parcel_orders o JOIN driver_profiles d ON d.approval_status='APPROVED' AND d.availability='AVAILABLE' AND d.location_confirmed_at>now()-interval '5 minutes' AND d.location_latitude IS NOT NULL AND d.location_longitude IS NOT NULL
  WHERE o.id=NEW.order_id AND ST_DistanceSphere(ST_SetSRID(ST_MakePoint(d.location_longitude,d.location_latitude),4326),ST_SetSRID(ST_MakePoint(o.pickup_longitude,o.pickup_latitude),4326))<=30000
  ON CONFLICT DO NOTHING;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER notification_search_published AFTER INSERT OR UPDATE ON parcel_searches FOR EACH ROW EXECUTE FUNCTION notify_search_published();
CREATE OR REPLACE FUNCTION notify_solicitation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE client uuid;
BEGIN
 IF NEW.status='PENDING' AND (TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.driver_id,NEW.order_id,'delivery_available','available:'||NEW.order_id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 IF NEW.status='OFFERED' AND (TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN SELECT client_id INTO client FROM parcel_orders WHERE id=NEW.order_id;INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(client,NEW.order_id,'offer_received','offer:'||NEW.id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 IF TG_OP='UPDATE' AND OLD.status='OFFERED' AND NEW.status IN ('REJECTED','EXPIRED','CLOSED') THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.driver_id,NEW.order_id,CASE WHEN NEW.status='REJECTED' THEN 'offer_rejected' WHEN NEW.status='EXPIRED' THEN 'offer_expired' ELSE 'search_closed' END,'offer-result:'||NEW.id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
