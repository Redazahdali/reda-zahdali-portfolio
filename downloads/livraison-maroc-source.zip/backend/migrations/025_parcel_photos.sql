CREATE TABLE parcel_photos (
 order_id uuid NOT NULL REFERENCES parcel_orders(id) ON DELETE CASCADE,
 slot smallint NOT NULL CHECK (slot BETWEEN 1 AND 3),
 object_key text NOT NULL UNIQUE,
 content_type text NOT NULL DEFAULT 'image/jpeg',
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(order_id,slot)
);
