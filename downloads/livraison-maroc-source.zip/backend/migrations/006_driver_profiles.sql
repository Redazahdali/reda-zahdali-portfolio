CREATE TABLE driver_profiles (
 account_id uuid PRIMARY KEY REFERENCES auth_accounts(id),
 approval_status text NOT NULL DEFAULT 'PENDING_APPROVAL' CHECK (approval_status IN ('PENDING_APPROVAL','APPROVED','SUSPENDED','REJECTED')),
 availability text NOT NULL DEFAULT 'OFFLINE' CHECK (availability IN ('OFFLINE','AVAILABLE','BUSY')),
 location_confirmed_at timestamptz,
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK (approval_status = 'APPROVED' OR availability = 'OFFLINE')
);
CREATE TABLE driver_approval_audit (
 id uuid PRIMARY KEY,
 account_id uuid NOT NULL REFERENCES auth_accounts(id),
 actor_db_role text NOT NULL,
 previous_status text NOT NULL,
 new_status text NOT NULL,
 reason text NOT NULL CHECK (length(trim(reason)) BETWEEN 5 AND 500),
 created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO driver_profiles(account_id) SELECT id FROM auth_accounts WHERE role='LIVREUR' ON CONFLICT DO NOTHING;
CREATE FUNCTION create_driver_profile() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.role='LIVREUR' THEN INSERT INTO driver_profiles(account_id) VALUES(NEW.id) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER auth_account_driver_profile AFTER INSERT ON auth_accounts FOR EACH ROW EXECUTE FUNCTION create_driver_profile();
