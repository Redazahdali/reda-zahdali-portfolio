-- Durable work list for interrupted uploads and replaced/removed photos.
CREATE TABLE parcel_photo_cleanup (
 object_key text PRIMARY KEY,
 not_before timestamptz NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
