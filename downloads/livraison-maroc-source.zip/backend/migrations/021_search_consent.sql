ALTER TABLE parcel_searches ADD COLUMN precise_consent_at timestamptz;
ALTER TABLE parcel_searches ADD COLUMN assignment_consent_at timestamptz;
