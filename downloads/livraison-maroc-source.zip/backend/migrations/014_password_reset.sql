CREATE TABLE auth_password_reset_tokens (
 token_hash text PRIMARY KEY,
 account_id uuid NOT NULL REFERENCES auth_accounts(id) ON DELETE CASCADE,
 expires_at timestamptz NOT NULL,
 consumed_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX auth_password_reset_account_idx ON auth_password_reset_tokens(account_id);
