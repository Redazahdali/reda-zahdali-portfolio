CREATE TABLE app_notifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 account_id uuid NOT NULL REFERENCES auth_accounts(id) ON DELETE CASCADE,
 order_id uuid REFERENCES parcel_orders(id) ON DELETE CASCADE,
 kind text NOT NULL,
 event_key text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 read_at timestamptz,
 UNIQUE(account_id,event_key)
);
CREATE INDEX app_notifications_account_idx ON app_notifications(account_id,created_at DESC,id DESC);
CREATE TABLE notification_devices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 account_id uuid NOT NULL REFERENCES auth_accounts(id) ON DELETE CASCADE,
 token text NOT NULL UNIQUE,
 language text NOT NULL CHECK(language IN ('fr','ar')),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE notification_push_queue (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 notification_id uuid NOT NULL REFERENCES app_notifications(id) ON DELETE CASCADE,
 device_id uuid NOT NULL REFERENCES notification_devices(id) ON DELETE CASCADE,
 state text NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','receipt','sent','failed')),
 attempts integer NOT NULL DEFAULT 0,
 next_attempt_at timestamptz NOT NULL DEFAULT now(),
 ticket_id text,
 last_error text,
 UNIQUE(notification_id,device_id)
);
CREATE INDEX notification_push_due_idx ON notification_push_queue(state,next_attempt_at);
CREATE FUNCTION queue_notification_push() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO notification_push_queue(notification_id,device_id)
 SELECT NEW.id,id FROM notification_devices WHERE account_id=NEW.account_id ON CONFLICT DO NOTHING;
 RETURN NEW;
END $$;
CREATE TRIGGER app_notification_push AFTER INSERT ON app_notifications FOR EACH ROW EXECUTE FUNCTION queue_notification_push();
CREATE FUNCTION notify_new_message() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE target uuid;
BEGIN
 SELECT CASE WHEN o.client_id=NEW.sender_id THEN p.assigned_driver_id ELSE o.client_id END INTO target FROM parcel_orders o JOIN parcel_manual_prices p ON p.order_id=o.id WHERE o.id=NEW.order_id;
 IF target IS NOT NULL AND target<>NEW.sender_id THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(target,NEW.order_id,'message','message:'||NEW.id) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER notification_message AFTER INSERT ON parcel_manual_messages FOR EACH ROW EXECUTE FUNCTION notify_new_message();
CREATE FUNCTION notify_manual_delivery() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE client uuid;
BEGIN
 SELECT client_id INTO client FROM parcel_orders WHERE id=NEW.order_id;
 IF NEW.delivery_status='ASSIGNED' AND OLD.delivery_status IS DISTINCT FROM NEW.delivery_status THEN
  INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(client,NEW.order_id,'driver_assigned','assigned-client:'||NEW.order_id),(NEW.assigned_driver_id,NEW.order_id,'mission_assigned','assigned-driver:'||NEW.order_id) ON CONFLICT DO NOTHING;
 END IF;
 IF NEW.pickup_requested_at IS NOT NULL AND OLD.pickup_requested_at IS NULL AND NEW.assigned_driver_id IS NOT NULL THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.assigned_driver_id,NEW.order_id,'pickup_requested','pickup-request:'||NEW.order_id) ON CONFLICT DO NOTHING; END IF;
 IF NEW.delivery_status='PICKED_UP' AND OLD.delivery_status IS DISTINCT FROM NEW.delivery_status THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(client,NEW.order_id,'pickup_confirmed','pickup-confirmed:'||NEW.order_id) ON CONFLICT DO NOTHING; END IF;
 IF NEW.delivery_requested_at IS NOT NULL AND OLD.delivery_requested_at IS NULL AND NEW.assigned_driver_id IS NOT NULL THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.assigned_driver_id,NEW.order_id,'delivery_requested','delivery-request:'||NEW.order_id) ON CONFLICT DO NOTHING; END IF;
 IF NEW.delivery_status='DELIVERED' AND OLD.delivery_status IS DISTINCT FROM NEW.delivery_status THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(client,NEW.order_id,'delivery_confirmed','delivery-confirmed:'||NEW.order_id) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER notification_delivery AFTER UPDATE ON parcel_manual_prices FOR EACH ROW EXECUTE FUNCTION notify_manual_delivery();
CREATE FUNCTION notify_solicitation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE client uuid;
BEGIN
 IF NEW.status='PENDING' AND (TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.driver_id,NEW.order_id,'delivery_available','solicitation:'||NEW.id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 IF NEW.status='OFFERED' AND (TG_OP='INSERT' OR OLD.status IS DISTINCT FROM NEW.status) THEN SELECT client_id INTO client FROM parcel_orders WHERE id=NEW.order_id;INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(client,NEW.order_id,'offer_received','offer:'||NEW.id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 IF TG_OP='UPDATE' AND OLD.status='OFFERED' AND NEW.status IN ('REJECTED','EXPIRED','CLOSED') THEN INSERT INTO app_notifications(account_id,order_id,kind,event_key) VALUES(NEW.driver_id,NEW.order_id,CASE WHEN NEW.status='REJECTED' THEN 'offer_rejected' WHEN NEW.status='EXPIRED' THEN 'offer_expired' ELSE 'search_closed' END,'offer-result:'||NEW.id||':'||NEW.cycle) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER notification_solicitation AFTER INSERT OR UPDATE ON parcel_solicitations FOR EACH ROW EXECUTE FUNCTION notify_solicitation();
CREATE FUNCTION notify_driver_approval() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.approval_status IS DISTINCT FROM NEW.approval_status AND NEW.approval_status IN ('APPROVED','SUSPENDED','REJECTED') THEN INSERT INTO app_notifications(account_id,kind,event_key) VALUES(NEW.account_id,'account_'||lower(NEW.approval_status),'approval:'||NEW.account_id||':'||NEW.approval_status||':'||clock_timestamp()::text) ON CONFLICT DO NOTHING; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER notification_driver_approval AFTER UPDATE OF approval_status ON driver_profiles FOR EACH ROW EXECUTE FUNCTION notify_driver_approval();
