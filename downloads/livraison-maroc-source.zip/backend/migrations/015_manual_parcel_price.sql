CREATE TABLE parcel_manual_prices (
 order_id uuid PRIMARY KEY REFERENCES parcel_orders(id) ON DELETE CASCADE,
 amount_dh integer NOT NULL CHECK (amount_dh BETWEEN 1 AND 100000),
 updated_at timestamptz NOT NULL DEFAULT now()
);
