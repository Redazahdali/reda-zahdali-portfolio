ALTER TABLE auth_accounts ALTER COLUMN password_hash DROP NOT NULL;
ALTER TABLE auth_accounts ADD CONSTRAINT auth_accounts_id_role_unique UNIQUE (id, role);
CREATE TABLE auth_google_identities (
  role text NOT NULL CHECK (role IN ('CLIENT','LIVREUR')),
  google_sub text NOT NULL,
  account_id uuid NOT NULL UNIQUE,
  PRIMARY KEY (role, google_sub),
  FOREIGN KEY (account_id, role) REFERENCES auth_accounts(id, role) ON DELETE CASCADE
);
