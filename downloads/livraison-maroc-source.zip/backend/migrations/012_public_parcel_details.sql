ALTER TABLE parcel_orders ADD COLUMN parcel_name varchar(120);
ALTER TABLE parcel_orders ADD COLUMN public_description varchar(500);
ALTER TABLE parcel_orders ADD COLUMN precise_disclosure_at timestamptz;
ALTER TABLE parcel_orders ADD CONSTRAINT parcel_public_details_valid CHECK (
  precise_disclosure_at IS NULL OR (
    parcel_name IS NOT NULL AND char_length(trim(parcel_name)) >= 2
    AND public_description IS NOT NULL AND char_length(trim(public_description)) >= 3
    AND pricing_quote_id IS NOT NULL AND proposed_price_dh IS NOT NULL
  )
);
