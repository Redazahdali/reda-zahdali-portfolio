import {createHmac,timingSafeEqual} from 'node:crypto';

export function photoProof(secret:string,driverId:string,orderId:string,expires:number):string {
 return expires+'.'+createHmac('sha256',secret).update(`parcel-photo:${driverId}:${orderId}:${expires}`).digest('base64url');
}
export function validPhotoProof(secret:string|undefined,driverId:string,orderId:string,proof:unknown):boolean {
 if(!secret||secret.length<32||typeof proof!=='string')return false;
 const m=/^(\d{10})\.([A-Za-z0-9_-]{43})$/.exec(proof);if(!m)return false;
 const expires=Number(m[1]),now=Math.floor(Date.now()/1000);
 if(expires<now||expires>now+600)return false;
 const expected=Buffer.from(photoProof(secret,driverId,orderId,expires)),actual=Buffer.from(proof);
 return expected.length===actual.length&&timingSafeEqual(expected,actual);
}
