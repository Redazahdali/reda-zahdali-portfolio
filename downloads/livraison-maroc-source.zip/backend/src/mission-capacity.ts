import type {PoolClient} from 'pg';

export const MAX_ACTIVE_MISSIONS = 10;

// Legacy assignments count too, even though they use a separate table.
export function activeMissionCountSql(driverAlias:'d'|'driver_profiles'):string {
 return `((SELECT count(*) FROM parcel_manual_prices m_active WHERE m_active.assigned_driver_id=${driverAlias}.account_id AND m_active.delivery_status IN ('ASSIGNED','PICKED_UP')) + (SELECT count(*) FROM parcel_orders o_active WHERE o_active.assigned_driver_id=${driverAlias}.account_id AND o_active.status='ASSIGNED'))::int`;
}

// Call while holding the driver's profile row FOR UPDATE when deciding assignment.
export async function activeMissionCount(client:PoolClient,driverId:string):Promise<number> {
 const result=await client.query(`SELECT ${activeMissionCountSql('d')} AS active_missions FROM driver_profiles d WHERE d.account_id=$1`,[driverId]);
 return result.rows[0]?.active_missions ?? 0;
}
