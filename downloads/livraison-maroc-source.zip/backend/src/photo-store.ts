import {S3Client,PutObjectCommand,GetObjectCommand,DeleteObjectCommand} from '@aws-sdk/client-s3';

export interface PhotoStore {
 put(key:string,data:Buffer):Promise<void>;
 get(key:string):Promise<Buffer>;
 delete(key:string):Promise<void>;
}

export function createR2PhotoStore(env:NodeJS.ProcessEnv):PhotoStore|undefined {
 const {R2_ACCOUNT_ID:account,R2_ACCESS_KEY_ID:accessKeyId,R2_SECRET_ACCESS_KEY:secretAccessKey,R2_PARCEL_BUCKET:bucket}=env;
 if(!account||!accessKeyId||!secretAccessKey||!bucket)return undefined;
 if(!/^[a-f0-9]{32}$/i.test(account)||!/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(bucket))throw Error('Invalid R2 photo configuration');
 const client=new S3Client({region:'auto',endpoint:`https://${account}.r2.cloudflarestorage.com`,credentials:{accessKeyId,secretAccessKey}});
 return {
  async put(key,data){await client.send(new PutObjectCommand({Bucket:bucket,Key:key,Body:data,ContentType:'image/jpeg'}));},
  async get(key){const result=await client.send(new GetObjectCommand({Bucket:bucket,Key:key}));if(!result.Body)throw Error('empty photo');return Buffer.from(await result.Body.transformToByteArray());},
  async delete(key){await client.send(new DeleteObjectCommand({Bucket:bucket,Key:key}));}
 };
}
