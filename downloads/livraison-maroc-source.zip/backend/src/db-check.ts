import 'dotenv/config';
import { Pool } from 'pg';
import { readConfig } from './config.js';
const pool = new Pool({ connectionString: readConfig(process.env).DATABASE_URL });
try { const result = await pool.query("SELECT current_database() AS database, PostGIS_Version() AS postgis, ST_AsText(ST_SetSRID(ST_MakePoint(-7.5898,33.5731),4326)) AS point"); console.log(result.rows[0]); } finally { await pool.end(); }
