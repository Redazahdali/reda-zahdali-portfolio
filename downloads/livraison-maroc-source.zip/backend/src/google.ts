import { OAuth2Client, type TokenPayload } from 'google-auth-library';
export type GoogleVerifier = (token: string, audience: string) => Promise<TokenPayload>;
const client = new OAuth2Client();
export const verifyGoogleToken: GoogleVerifier = async (idToken, audience) => {
 const ticket = await client.verifyIdToken({idToken, audience});
 const payload = ticket.getPayload();
 if (!payload) throw new Error('Invalid Google token');
 return payload;
};
export function trustedGoogleIdentity(p: TokenPayload, audience: string) {
 if (p.aud !== audience || (p.iss !== 'accounts.google.com' && p.iss !== 'https://accounts.google.com') || !p.exp || p.exp <= Math.floor(Date.now()/1000) || !p.sub || p.sub.length > 255 || !p.email || p.email_verified !== true) return null;
 const address=p.email.trim().toLowerCase();
 if (!address.endsWith('@gmail.com') && !p.hd) return null;
 return {sub:p.sub,email:address};
}
