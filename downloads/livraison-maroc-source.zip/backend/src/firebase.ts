import { createVerify } from 'node:crypto';

export type FirebaseIdentity = { uid:string; email:string; emailVerified:boolean; authTime:number };
export type FirebaseVerifier = (token:string)=>Promise<FirebaseIdentity>;
const certUrl='https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

// Firebase publishes rotating public signing certificates. Never trust the JWT header to select a URL.
export function firebaseVerifier(projectId:string):FirebaseVerifier {
 let certs:Record<string,string>={}; let expires=0;
 return async token=>{
  const parts=token.split('.'); if(parts.length!==3)throw Error('invalid token');
  let header:{alg?:string;kid?:string},payload:{aud?:string;iss?:string;sub?:string;exp?:number;iat?:number;auth_time?:number;email?:string;email_verified?:boolean};
  try{header=JSON.parse(Buffer.from(parts[0],'base64url').toString());payload=JSON.parse(Buffer.from(parts[1],'base64url').toString());}catch{throw Error('invalid token');}
  if(header.alg!=='RS256'||typeof header.kid!=='string'||!header.kid)throw Error('invalid token');
  if(Date.now()>=expires){
   const response=await fetch(certUrl,{signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('certificates unavailable');
   const body=await response.json() as Record<string,string>;if(!body||typeof body!=='object')throw Error('invalid certificates');
   certs=body;const maxAge=/max-age=(\d+)/i.exec(response.headers.get('cache-control')||'');expires=Date.now()+Math.min(Number(maxAge?.[1]||300),86400)*1000;
  }
  const cert=certs[header.kid];if(typeof cert!=='string')throw Error('unknown certificate');
  const verifier=createVerify('RSA-SHA256');verifier.update(parts[0]+'.'+parts[1]);verifier.end();
  if(!verifier.verify(cert,Buffer.from(parts[2],'base64url')))throw Error('invalid signature');
  const now=Math.floor(Date.now()/1000);
  if(payload.aud!==projectId||payload.iss!=='https://securetoken.google.com/'+projectId||typeof payload.sub!=='string'||!payload.sub||payload.sub.length>128||typeof payload.exp!=='number'||payload.exp<=now||typeof payload.iat!=='number'||payload.iat>now||typeof payload.auth_time!=='number'||payload.auth_time>now||typeof payload.email!=='string')throw Error('invalid claims');
  return {uid:payload.sub,email:payload.email.trim().toLowerCase(),emailVerified:payload.email_verified===true,authTime:payload.auth_time};
 };
}
