/** Generates short-lived Cloudflare TURN credentials on the server only. */
export type IceServer = { urls: string[]; username?: string; credential?: string };
export type TurnConfig = { keyId: string; apiToken: string; ttlSeconds?: number };

type Fetcher = typeof fetch;
export async function createTurnCredentials(config: TurnConfig, request: Fetcher = fetch): Promise<IceServer[]> {
 const {keyId, apiToken} = config;
 const ttl = config.ttlSeconds ?? 7500;
 if (!/^[a-zA-Z0-9_-]{1,128}$/.test(keyId) || !apiToken || !Number.isInteger(ttl) || ttl < 60 || ttl > 86400) throw new Error('turn_not_configured');
 let response: Response;
 try {
  response = await request(`https://rtc.live.cloudflare.com/v1/turn/keys/${keyId}/credentials/generate-ice-servers`, {
   method: 'POST', headers: {Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json'},
   body: JSON.stringify({ttl}), signal: AbortSignal.timeout(10000),
  });
 } catch { throw new Error('turn_unavailable'); }
 if (!response.ok) throw new Error('turn_unavailable');
 let body: unknown;
 try { body = await response.json(); } catch { throw new Error('turn_unavailable'); }
 const servers = (body as {iceServers?:unknown})?.iceServers;
 if (!Array.isArray(servers) || servers.length === 0 || servers.length > 10) throw new Error('turn_unavailable');
 const clean: IceServer[] = [];
 for (const entry of servers) {
  if (!entry || typeof entry !== 'object') throw new Error('turn_unavailable');
  const {urls,username,credential} = entry as Record<string,unknown>;
  if (!Array.isArray(urls) || !urls.length || urls.length > 20 || !urls.every(url=>typeof url==='string' && /^(stun|turn|turns):[a-z0-9.-]+(?::\d+)?(?:\?transport=(?:udp|tcp))?$/i.test(url))) throw new Error('turn_unavailable');
  const hasTurn=urls.some(url=>/^turns?:/i.test(url));
  if (hasTurn && (typeof username!=='string' || !username || typeof credential!=='string' || !credential)) throw new Error('turn_unavailable');
  clean.push({urls,...(hasTurn?{username:username as string,credential:credential as string}:{})});
 }
 if (!clean.some(server=>server.urls.some(url=>/^turns?:/i.test(url)))) throw new Error('turn_unavailable');
 return clean;
}
