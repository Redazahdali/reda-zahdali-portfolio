import { z } from 'zod';
const schema = z.object({ PORT: z.coerce.number().int().min(1).max(65535).default(3000), DATABASE_URL: z.string().url().refine(s => s.startsWith('postgresql://') || s.startsWith('postgres://'), 'PostgreSQL URL required') });
export function readConfig(env: NodeJS.ProcessEnv) { return schema.parse({ PORT: env.PORT, DATABASE_URL: env.DATABASE_URL }); }
