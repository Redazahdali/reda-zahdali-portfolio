export function usableVerificationUrl(value:string):boolean {
 try {
  const u=new URL(value); const h=u.hostname.toLowerCase().replace(/^\[|\]$/g,'');
  if(u.protocol!=='https:' || u.username || u.password || u.hash || u.search) return false;
  if(h==='localhost' || h.endsWith('.localhost') || h==='::1' || h==='0.0.0.0' || /^127\./.test(h)) return false;
  return u.pathname==='/api/v1/auth/verify-email';
 } catch {return false;}
}
