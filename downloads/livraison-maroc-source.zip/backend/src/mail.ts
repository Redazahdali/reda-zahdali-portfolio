import nodemailer from 'nodemailer';
export interface Mailer { sendVerification(email: string, url: string): Promise<void>; sendPasswordReset?(email:string, url:string):Promise<void> }
export function smtpMailer(env: NodeJS.ProcessEnv): Mailer {
 const { BREVO_SMTP_HOST: host, BREVO_SMTP_PORT: port, BREVO_SMTP_USER: user, BREVO_SMTP_KEY: pass, MAIL_FROM: from } = env;
 const send = async (email:string,url:string,reset:boolean) => {
  if (!host || port !== '587' || !user || !pass || !from) throw new Error('SMTP configuration incomplete');
  const transport = nodemailer.createTransport({host, port:587, secure:false, requireTLS:true, auth:{user,pass}, tls:{rejectUnauthorized:true}, connectionTimeout:10000, greetingTimeout:10000, socketTimeout:15000});
  await transport.sendMail({from,to:email,subject:reset?'Réinitialisation du mot de passe | إعادة تعيين كلمة المرور':'Vérifiez votre adresse e-mail | تأكيد بريدك الإلكتروني',text:reset?`Réinitialisez votre mot de passe : ${url}\nCe lien expire dans 15 minutes.\nإعادة تعيين كلمة المرور: ${url}\nتنتهي صلاحية الرابط خلال 15 دقيقة.`:`Bienvenue sur Livraison Maroc. Confirmez votre adresse : ${url}\n\nمرحباً بك في ليفريزون المغرب. أكد بريدك الإلكتروني: ${url}\n\nCe lien expire dans 24 heures. / تنتهي صلاحية الرابط خلال 24 ساعة.`});
 };
 return {sendVerification:(email,url)=>send(email,url,false),sendPasswordReset:(email,url)=>send(email,url,true)};
}
