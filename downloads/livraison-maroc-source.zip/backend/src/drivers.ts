import {activeMissionCountSql,MAX_ACTIVE_MISSIONS} from './mission-capacity.js';
import type {Express, Request} from 'express';
import type {Pool} from 'pg';
import {z} from 'zod';

type Account={id:string;role:string};
const location=z.object({latitude:z.number().finite().min(-90).max(90),longitude:z.number().finite().min(-180).max(180),accuracy:z.number().finite().min(0).max(1000),capturedAt:z.number().finite()}).strict();
const update=z.discriminatedUnion('availability',[
 z.object({availability:z.literal('OFFLINE')}).strict(),
 z.object({availability:z.literal('AVAILABLE'),consent:z.literal(true),location}).strict()
]);
const loopback=(req:Request)=>['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress||'') && !req.get('x-forwarded-for') && !req.get('x-forwarded-proto') && !req.get('forwarded');
const columns=`approval_status, CASE WHEN availability='AVAILABLE' AND EXISTS (SELECT 1 FROM parcel_solicitations s WHERE s.driver_id=driver_profiles.account_id AND s.status='OFFERED' AND s.counter_expires_at>now()) THEN 'RESERVED' ELSE availability END AS availability, location_confirmed_at, CASE WHEN availability='AVAILABLE' AND location_confirmed_at IS NOT NULL THEN GREATEST(0, EXTRACT(EPOCH FROM (location_confirmed_at + interval '5 minutes' - now())) * 1000)::int ELSE 0 END AS location_valid_for_ms, ${activeMissionCountSql('driver_profiles')} AS active_missions, ${MAX_ACTIVE_MISSIONS}::int AS max_active_missions, updated_at`;
export function registerDriverRoutes(app:Express,pool:Pool,session:(req:Request)=>Promise<Account|null>) {
 const driver=async(req:Request,res:import('express').Response)=>{const u=await session(req);if(!u){res.status(401).json({error:'unauthorized'});return null;}if(u.role!=='LIVREUR'){res.status(403).json({error:'forbidden'});return null;}return u;};
 app.get('/api/v1/driver/me',async(req,res)=>{const u=await driver(req,res);if(!u)return;const r=await pool.query(`SELECT ${columns} FROM driver_profiles WHERE account_id=$1`,[u.id]);if(!r.rowCount){res.status(503).json({error:'driver_profile_unavailable'});return;}res.set('Cache-Control','no-store').json({profile:r.rows[0]});});
 app.post('/api/v1/driver/availability',async(req,res)=>{const u=await driver(req,res);if(!u)return;const parsed=update.safeParse(req.body);if(!parsed.success){res.status(400).json({error:'invalid_input'});return;}const d=parsed.data;
  if(d.availability==='AVAILABLE'){
   if(!req.secure&&!loopback(req)){res.status(403).json({error:'secure_transport_required'});return;}
   const age=Date.now()-d.location.capturedAt;if(age< -30000||age>120000){res.status(400).json({error:'location_stale'});return;}
   const eligibility=await pool.query("SELECT 1 FROM driver_profiles WHERE account_id=$1 AND approval_status='APPROVED' AND availability<>'BUSY'",[u.id]);if(!eligibility.rowCount){res.status(403).json({error:'driver_not_approved_or_busy'});return;}
   const profile=await pool.query('SELECT 1 FROM account_contact_profiles WHERE account_id=$1 AND vehicle IS NOT NULL AND max_size IS NOT NULL',[u.id]);if(!profile.rowCount){res.status(409).json({error:'profile_incomplete'});return;}
  }
  const r=await pool.query(`UPDATE driver_profiles SET availability=$2,location_confirmed_at=CASE WHEN $2='AVAILABLE' THEN now() ELSE NULL END,location_latitude=$3,location_longitude=$4,updated_at=now() WHERE account_id=$1 AND approval_status='APPROVED' AND availability<>'BUSY' RETURNING ${columns}`,[u.id,d.availability,d.availability==='AVAILABLE'?d.location.latitude:null,d.availability==='AVAILABLE'?d.location.longitude:null]);if(!r.rowCount){res.status(403).json({error:'driver_not_approved_or_busy'});return;}res.set('Cache-Control','no-store').json({profile:r.rows[0]});
 });
 app.post('/api/v1/driver/location',async(req,res)=>{const u=await driver(req,res);if(!u)return;if(!req.secure&&!loopback(req)){res.status(403).json({error:'secure_transport_required'});return;}const parsed=location.safeParse(req.body);if(!parsed.success){res.status(400).json({error:'invalid_input'});return;}const d=parsed.data,age=Date.now()-d.capturedAt;if(age< -30000||age>120000){res.status(400).json({error:'location_stale'});return;}const r=await pool.query(`UPDATE driver_profiles SET location_confirmed_at=now(),location_latitude=$2,location_longitude=$3,updated_at=now() WHERE account_id=$1 AND approval_status='APPROVED' AND availability='AVAILABLE' RETURNING ${columns}`,[u.id,d.latitude,d.longitude]);if(!r.rowCount){res.status(409).json({error:'driver_unavailable'});return;}res.set('Cache-Control','no-store').json({profile:r.rows[0]});});
}
