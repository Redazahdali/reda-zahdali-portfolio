import { randomBytes, randomUUID, createHash } from 'node:crypto';
import express, { type ErrorRequestHandler } from 'express';
import { Pool } from 'pg';
import { z } from 'zod';
import argon2 from 'argon2';
import type { Mailer } from './mail.js';
import { registerPasswordReset } from './password-reset.js';
import { registerNotifications } from './notifications.js';
import { registerRecipientTracking } from './recipient-tracking.js';
import { registerDeliveryProgress } from './delivery-progress.js';
import { registerVoiceCalls } from './voice-calls.js';
import { registerContactProfiles } from './contact-profiles.js';
import { registerManualSearch } from './manual-search.js';
import {registerParcelPhotos} from './parcel-photos.js';
import type {PhotoStore} from './photo-store.js';
import { registerParcelRoutes } from './parcels.js';
import { registerDriverRoutes } from './drivers.js';
import { registerDispatchRoutes } from './dispatch.js';
import { registerNegotiationRoutes } from './negotiation.js';
import { registerPricingRoutes, type PricingTestConfig } from './pricing.js';
import { usableVerificationUrl } from './verification-url.js';
import { trustedGoogleIdentity, type GoogleVerifier } from './google.js';
import type { FirebaseVerifier } from './firebase.js';
import type { IceServer } from './turn-credentials.js';
const role = z.enum(['CLIENT','LIVREUR']);
const email = z.string().trim().toLowerCase().email().max(254);
const password = z.string().min(12).max(128).refine(s => Buffer.byteLength(s,'utf8') <= 256);
const input = z.object({email,role,password});
const identity = z.object({email,role});
const hash = (s:string) => createHash('sha256').update(s).digest('hex');
const token = () => randomBytes(32).toString('base64url');
export function createApp(options?: {pool:Pool; mailer:Mailer; verificationUrl:string; googleAudience?:string; googleVerifier?:GoogleVerifier; firebaseVerifier?:FirebaseVerifier; turnCredentials?:()=>Promise<IceServer[]>; voiceCallsEnabled?:boolean; diagnostics?:boolean; isolatedDispatchTest?:boolean; isolatedPricingTest?:boolean; isolatedNegotiationTest?:boolean; pricingTestConfig?:PricingTestConfig; handoffSecret?:string; photoStore?:PhotoStore; enforceAuthTransport?:boolean; allowLocalAuth?:boolean; trustLocalProxy?:boolean; routeDistance?:(a:{longitude:number;latitude:number},b:{longitude:number;latitude:number})=>Promise<number>}) {
 const app=express(); app.use(express.json({limit:'16kb'}));
 app.get('/api/v1/health', (_req,res)=>res.json({status:'ok',service:'livraison-maroc-api',version:'v1'}));
 if(options) {
 const {pool,mailer,verificationUrl}=options;
 if(options.trustLocalProxy) app.set('trust proxy','loopback');
 if(options.enforceAuthTransport) app.use('/api/v1/auth',(req,res,next)=>{const local=['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress||'');const forwarded=!!(req.get('x-forwarded-for')||req.get('x-forwarded-proto')||req.get('forwarded'));if(req.secure||(options.allowLocalAuth&&local&&!forwarded)){next();return;}res.status(403).json({error:'secure_transport_required'});});
 if(options.diagnostics) app.use('/api/v1/auth',(req,res,next)=>{const safe=new Set(['/signup','/verify-email','/login','/logout','/me','/resend-verification','/google','/google/link']);const route=safe.has(req.path)?req.path:'other';res.on('finish',()=>console.log('auth',req.method==='GET'||req.method==='POST'?req.method:'OTHER',route,res.statusCode));next();});
 const dummyHash=argon2.hash('dummy-password-for-timing', {type:argon2.argon2id});
 const rate=async(key:string,limit:number,minutes:number) => {
  const r=await pool.query(`INSERT INTO auth_rate_limits(key) VALUES($1) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN auth_rate_limits.window_start < now()-($2 * interval '1 minute') THEN 1 ELSE auth_rate_limits.attempts+1 END, window_start=CASE WHEN auth_rate_limits.window_start < now()-($2 * interval '1 minute') THEN now() ELSE auth_rate_limits.window_start END RETURNING attempts`,[key,minutes]); return r.rows[0].attempts <= limit;
 };
 registerPasswordReset(app,pool,mailer,verificationUrl,rate,!!options.firebaseVerifier);
 const send=async(accountId:string,address:string) => {
  const raw=token(); const url=new URL(verificationUrl); url.searchParams.set('token',raw);
  await pool.query("INSERT INTO auth_verification_tokens(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '24 hours')",[hash(raw),accountId]);
  try { await mailer.sendVerification(address,url.toString()); } catch { console.error('Verification email delivery failed; resend remains available.'); }
 };
 app.post('/api/v1/auth/signup',async(req,res)=>{
  const parsed=input.safeParse(req.body); if(!parsed.success) {res.status(400).json({error:'invalid_input'});return;}
  const {email,role,password}=parsed.data;
  if(!usableVerificationUrl(verificationUrl)){res.status(503).json({error:'verification_unavailable'});return;}
  if(!await rate(`signup:${hash(req.ip || '')}`,20,60)) {res.status(429).json({error:'rate_limited'});return;}
  const passwordHash=await argon2.hash(password,{type:argon2.argon2id});
  const result=await pool.query('INSERT INTO auth_accounts(id,role,email,password_hash) VALUES($1,$2,$3,$4) ON CONFLICT(role,email) DO NOTHING RETURNING id',[randomUUID(),role,email,passwordHash]);
  if(result.rowCount) await send(result.rows[0].id,email);
  res.status(202).json({message:'verification_if_eligible'});
 });
 app.post('/api/v1/auth/resend-verification',async(req,res)=>{
  const parsed=identity.safeParse(req.body); if(!parsed.success) {res.status(400).json({error:'invalid_input'});return;}
  const {email,role}=parsed.data;
  if(!usableVerificationUrl(verificationUrl)){res.status(503).json({error:'verification_unavailable'});return;}
  const allowed=await rate(`resend:${hash(role+':'+email)}`,3,60); const ipAllowed=await rate(`resend-ip:${hash(req.ip || '')}`,20,60);
  if(!allowed || !ipAllowed) {res.status(429).json({error:'rate_limited'});return;}
  const result=await pool.query('SELECT id FROM auth_accounts WHERE role=$1 AND email=$2 AND email_verified_at IS NULL',[role,email]);
  if(result.rowCount) await send(result.rows[0].id,email);
  res.status(202).json({message:'verification_if_eligible'});
 });
 app.get('/api/v1/auth/verify-email',async(req,res)=>{
  const raw=typeof req.query.token==='string'?req.query.token:'';
  if(!/^[A-Za-z0-9_-]{43}$/.test(raw)) {res.status(400).send('Lien invalide ou expiré. / الرابط غير صالح أو منتهي الصلاحية.');return;}
  const client=await pool.connect(); let success=false;
  try {await client.query('BEGIN'); const r=await client.query('UPDATE auth_verification_tokens SET consumed_at=now() WHERE token_hash=$1 AND consumed_at IS NULL AND expires_at>now() RETURNING account_id',[hash(raw)]);
   if(r.rowCount) { await client.query('UPDATE auth_accounts SET email_verified_at=COALESCE(email_verified_at,now()) WHERE id=$1',[r.rows[0].account_id]); await client.query('UPDATE auth_verification_tokens SET consumed_at=now() WHERE account_id=$1 AND consumed_at IS NULL',[r.rows[0].account_id]); success=true; } await client.query('COMMIT');
  } catch(e) {await client.query('ROLLBACK');throw e;} finally {client.release();}
  res.set('Referrer-Policy','no-referrer').set('Cache-Control','no-store');
  res.status(success?200:400).type('html').send(success?'<!doctype html><html><meta name="viewport" content="width=device-width"><p>Adresse vérifiée. Vous pouvez ouvrir l’application et vous connecter.</p><p dir="rtl">تم تأكيد البريد الإلكتروني. يمكنك فتح التطبيق وتسجيل الدخول.</p><a href="livraisonmaroc://verified">Ouvrir l’application / فتح التطبيق</a></html>':'Lien invalide ou expiré. / الرابط غير صالح أو منتهي الصلاحية.');
 });
 app.post('/api/v1/auth/login',async(req,res)=>{
  const parsed=input.safeParse(req.body); if(!parsed.success) {res.status(400).json({error:'invalid_input'});return;}
  const {email,role,password}=parsed.data;
  const allowed=await rate(`login:${hash(role+':'+email)}`,5,15); const ipAllowed=await rate(`login-ip:${hash(req.ip || '')}`,50,15);
  if(!allowed || !ipAllowed) {res.status(429).json({error:'rate_limited'});return;}
  const c=await pool.connect();try{await c.query('BEGIN');
  const result=await c.query('SELECT id,role,email,password_hash,email_verified_at FROM auth_accounts WHERE role=$1 AND email=$2'+(options.firebaseVerifier?' AND NOT EXISTS (SELECT 1 FROM auth_firebase_identities f WHERE f.account_id=auth_accounts.id)':'')+' FOR UPDATE',[role,email]);
  const account=result.rows[0];
  const matches=await argon2.verify(account?.password_hash || await dummyHash,password);
  if(!account || !account.password_hash || !matches || !account.email_verified_at) {await c.query('ROLLBACK');res.status(401).json({error:'invalid_credentials_or_unverified'});return;}
  const raw=token(); await c.query("INSERT INTO auth_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '30 days')",[hash(raw),account.id]);
  await c.query('COMMIT');res.set('Cache-Control','no-store').json({token:raw,expiresIn:2592000,user:{id:account.id,email:account.email,role:account.role}});
  }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 });
 const session=async(req:express.Request) => {const m=/^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.get('authorization') || ''); if(!m) return null; const r=await pool.query('SELECT a.id,a.email,a.role FROM auth_sessions s JOIN auth_accounts a ON a.id=s.account_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() AND a.email_verified_at IS NOT NULL',[hash(m[1])]); return r.rows[0] || null;};
 const firebaseIdentity=async(raw:string)=>{try{const user=await options.firebaseVerifier!(raw);return user.emailVerified&&email.safeParse(user.email).success?user:null;}catch{return null;}};
 app.post('/api/v1/auth/firebase',async(req,res)=>{
  const data=z.object({idToken:z.string().min(1).max(16384),role}).strict().safeParse(req.body);if(!data.success){res.status(400).json({error:'invalid_input'});return;}
  if(!options.firebaseVerifier){res.status(503).json({error:'firebase_unavailable'});return;}
  if(!await rate('firebase-ip:'+hash(req.ip||''),50,15)){res.status(429).json({error:'rate_limited'});return;}
  const ident=await firebaseIdentity(data.data.idToken);if(!ident){res.status(401).json({error:'firebase_auth_failed'});return;}
  const c=await pool.connect();try{await c.query('BEGIN');await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['firebase:'+data.data.role+':'+ident.uid]);await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['email:'+data.data.role+':'+ident.email]);
   let result=await c.query('SELECT a.id,a.email,a.role FROM auth_firebase_identities f JOIN auth_accounts a ON a.id=f.account_id WHERE f.role=$1 AND f.firebase_uid=$2',[data.data.role,ident.uid]);
   if(!result.rowCount){result=await c.query('INSERT INTO auth_accounts(id,role,email,password_hash,email_verified_at) VALUES($1,$2,$3,NULL,now()) ON CONFLICT(role,email) DO NOTHING RETURNING id,email,role',[randomUUID(),data.data.role,ident.email]);if(!result.rowCount){await c.query('ROLLBACK');res.status(409).json({error:'account_link_required'});return;}await c.query('INSERT INTO auth_firebase_identities(role,firebase_uid,account_id) VALUES($1,$2,$3)',[data.data.role,ident.uid,result.rows[0].id]);}
   const user=result.rows[0],raw=token();await c.query("INSERT INTO auth_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '30 days')",[hash(raw),user.id]);await c.query('COMMIT');res.set('Cache-Control','no-store').json({token:raw,expiresIn:2592000,user});
  }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 });
 app.post('/api/v1/auth/firebase/link',async(req,res)=>{
  const user=await session(req);if(!user){res.status(401).json({error:'unauthorized'});return;}
  const data=z.object({idToken:z.string().min(1).max(16384),password}).strict().safeParse(req.body);if(!data.success){res.status(400).json({error:'invalid_input'});return;}
  if(!options.firebaseVerifier){res.status(503).json({error:'firebase_unavailable'});return;}
  if(!await rate('firebase-link:'+hash(user.id),5,15)){res.status(429).json({error:'rate_limited'});return;}
  const ident=await firebaseIdentity(data.data.idToken);const account=(await pool.query('SELECT password_hash FROM auth_accounts WHERE id=$1',[user.id])).rows[0];const matches=await argon2.verify(account?.password_hash||await dummyHash,data.data.password);if(!ident||ident.email!==user.email||ident.authTime<Math.floor(Date.now()/1000)-300||!account?.password_hash||!matches){res.status(401).json({error:'firebase_link_failed'});return;}
  const result=await pool.query('INSERT INTO auth_firebase_identities(role,firebase_uid,account_id) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING account_id',[user.role,ident.uid,user.id]);
  if(!result.rowCount){res.status(409).json({error:'firebase_link_failed'});return;}res.status(204).end();
 });
 app.locals.tickNotifications=registerNotifications(app,pool,session);
 registerRecipientTracking(app,pool,session,options.handoffSecret,rate,options.photoStore);
 registerPricingRoutes(app,pool,session,options.isolatedPricingTest===true,options.routeDistance,options.pricingTestConfig);
 registerContactProfiles(app,pool,session);
 registerDriverRoutes(app,pool,session);
 registerDispatchRoutes(app,pool,session,options.isolatedDispatchTest===true);
 registerNegotiationRoutes(app,pool,session,options.isolatedNegotiationTest===true);
 app.locals.tickPhotoCleanup=registerParcelPhotos(app,pool,session,options.photoStore,options.handoffSecret,async id=>rate('photo:'+hash(id),30,15));
 registerParcelRoutes(app,pool,session,undefined,options.isolatedPricingTest===true);
 registerDeliveryProgress(app,pool,session,options.voiceCallsEnabled&&options.turnCredentials?{credentials:options.turnCredentials,allow:accountId=>rate('turn:'+hash(accountId),20,15)}:undefined);
 if(options.voiceCallsEnabled&&options.turnCredentials)app.locals.tickVoiceCalls=registerVoiceCalls(app,pool,session,accountId=>rate('voice:'+hash(accountId),500,15));
 const tickManualSearch=registerManualSearch(app,pool,session,options.handoffSecret); app.locals.tickManualSearch=tickManualSearch;
 const googleInput=z.object({idToken:z.string().min(1).max(16384),role});
 const googleIdentity=async(raw:string)=>{if(!options.googleAudience || !options.googleVerifier)return null; try {const claims=await options.googleVerifier(raw,options.googleAudience);const found=trustedGoogleIdentity(claims,options.googleAudience);if(!found || !email.safeParse(found.email).success)return null;return found;} catch{return null;}};
 app.post('/api/v1/auth/firebase/google-link-check',async(req,res)=>{
  const user=await session(req);if(!user){res.status(401).json({error:'unauthorized'});return;}
  const data=z.object({googleToken:z.string().min(1).max(16384),firebaseToken:z.string().min(1).max(16384)}).strict().safeParse(req.body);if(!data.success){res.status(400).json({error:'invalid_input'});return;}
  if(!options.firebaseVerifier||!options.googleAudience||!options.googleVerifier){res.status(503).json({error:'google_unavailable'});return;}
  if(!await rate('firebase-google-link:'+hash(user.id),5,15)){res.status(429).json({error:'rate_limited'});return;}
  const google=await googleIdentity(data.data.googleToken),firebase=await firebaseIdentity(data.data.firebaseToken);
  if(!google||!firebase||google.email!==user.email||firebase.email!==user.email||firebase.authTime<Math.floor(Date.now()/1000)-300){res.status(401).json({error:'google_link_failed'});return;}
  const linked=await pool.query('SELECT 1 FROM auth_firebase_identities WHERE account_id=$1 AND role=$2 AND firebase_uid=$3',[user.id,user.role,firebase.uid]);
  if(!linked.rowCount){res.status(401).json({error:'google_link_failed'});return;}res.status(204).end();
 });
 app.post('/api/v1/auth/google',async(req,res)=>{
  const data=googleInput.safeParse(req.body);if(!data.success){res.status(400).json({error:'invalid_input'});return;}
  if(!options.googleAudience || !options.googleVerifier){res.status(503).json({error:'google_unavailable'});return;}
  if(!await rate('google-ip:'+hash(req.ip || ''),50,15)){res.status(429).json({error:'rate_limited'});return;}
  const identity=await googleIdentity(data.data.idToken);if(!identity){res.status(401).json({error:'google_auth_failed'});return;}
  const {role}=data.data;const client=await pool.connect();let user;
  try{await client.query('BEGIN');await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['google:'+role+':'+identity.sub]);await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['email:'+role+':'+identity.email]);
   let result=await client.query('SELECT a.id,a.email,a.role FROM auth_google_identities g JOIN auth_accounts a ON a.id=g.account_id WHERE g.role=$1 AND g.google_sub=$2',[role,identity.sub]);
   if(result.rowCount && options.firebaseVerifier && (await client.query('SELECT 1 FROM auth_firebase_identities WHERE account_id=$1',[result.rows[0].id])).rowCount){await client.query('ROLLBACK');res.status(409).json({error:'firebase_account_required'});return;}
   if(!result.rowCount){result=await client.query('INSERT INTO auth_accounts(id,role,email,password_hash,email_verified_at) VALUES($1,$2,$3,NULL,now()) ON CONFLICT(role,email) DO NOTHING RETURNING id,email,role',[randomUUID(),role,identity.email]);if(!result.rowCount){await client.query('ROLLBACK');res.status(409).json({error:'account_link_required'});return;}await client.query('INSERT INTO auth_google_identities(role,google_sub,account_id) VALUES($1,$2,$3)',[role,identity.sub,result.rows[0].id]);}
   user=result.rows[0];const raw=token();await client.query("INSERT INTO auth_sessions(token_hash,account_id,expires_at) VALUES($1,$2,now()+interval '30 days')",[hash(raw),user.id]);await client.query('COMMIT');res.set('Cache-Control','no-store').json({token:raw,expiresIn:2592000,user});
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
 });
 app.post('/api/v1/auth/google/link',async(req,res)=>{
  const user=await session(req);if(!user){res.status(401).json({error:'unauthorized'});return;}
  const data=z.object({idToken:z.string().min(1).max(16384),password}).safeParse(req.body);if(!data.success){res.status(400).json({error:'invalid_input'});return;}
  if(!options.googleAudience || !options.googleVerifier){res.status(503).json({error:'google_unavailable'});return;}
  if(!await rate('google-link:'+hash(user.id),5,15)){res.status(429).json({error:'rate_limited'});return;}
  const identity=await googleIdentity(data.data.idToken);const account=(await pool.query('SELECT password_hash FROM auth_accounts WHERE id=$1',[user.id])).rows[0];
  const matches=await argon2.verify(account?.password_hash || await dummyHash,data.data.password);
  if(!identity || identity.email!==user.email || !account?.password_hash || !matches){res.status(401).json({error:'google_link_failed'});return;}
  const r=await pool.query('INSERT INTO auth_google_identities(role,google_sub,account_id) VALUES($1,$2,$3) ON CONFLICT DO NOTHING RETURNING account_id',[user.role,identity.sub,user.id]);
  if(!r.rowCount){res.status(409).json({error:'google_link_failed'});return;}res.status(204).end();
 });
 app.get('/api/v1/auth/me',async(req,res)=>{const user=await session(req); if(!user){res.status(401).json({error:'unauthorized'});return;} const firebase=(await pool.query('SELECT 1 FROM auth_firebase_identities WHERE account_id=$1',[user.id])).rowCount!==0;const googleLinked=(await pool.query('SELECT 1 FROM auth_google_identities WHERE account_id=$1',[user.id])).rowCount!==0;res.set('Cache-Control','no-store').json({user,firebase,googleLinked});});
 app.post('/api/v1/auth/logout',async(req,res)=>{const user=await session(req); if(!user){res.status(401).json({error:'unauthorized'});return;} const raw=req.get('authorization')!.slice(7); await pool.query('UPDATE auth_sessions SET revoked_at=now() WHERE token_hash=$1',[hash(raw)]); res.status(204).end();});
 }
 app.use((_req,res)=>res.status(404).json({error:'not_found'}));
 const errors:ErrorRequestHandler=(err,_req,res,_next)=>{const status=err?.type==='entity.too.large'?413:err?.type==='entity.parse.failed'?400:500;res.status(status).json({error:status===413?'photo_too_large':status===400?'invalid_json':'internal_error'});}; app.use(errors); return app;
}
export const app=createApp();
