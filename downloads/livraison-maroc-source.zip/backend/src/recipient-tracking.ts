import {createHmac,randomInt,randomBytes,createHash,createCipheriv,createDecipheriv} from 'node:crypto';
import type {Express,Request} from 'express';
import type {Pool} from 'pg';
import {z} from 'zod';
import type {PhotoStore} from './photo-store.js';
type User={id:string;role:string};
const secure=(r:Request)=>r.secure||(['127.0.0.1','::1','::ffff:127.0.0.1'].includes(r.socket.remoteAddress||'')&&!r.get('x-forwarded-for')&&!r.get('x-forwarded-proto')&&!r.get('forwarded'));
export function registerRecipientTracking(app:Express,pool:Pool,session:(r:Request)=>Promise<User|null>,secret:string|undefined,rate:(key:string,limit:number,minutes:number)=>Promise<boolean>,store?:PhotoStore){
 const digest=(code:string)=>createHmac('sha256',secret!).update(code).digest('hex');
 const encryptionKey=()=>createHmac('sha256',secret!).update('recipient-code-encryption-v1').digest();
 const encrypt=(code:string)=>{const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',encryptionKey(),iv);const encrypted=Buffer.concat([cipher.update(code,'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),encrypted]).toString('base64url');};
 const decrypt=(value:string)=>{const data=Buffer.from(value,'base64url'),decipher=createDecipheriv('aes-256-gcm',encryptionKey(),data.subarray(0,12));decipher.setAuthTag(data.subarray(12,28));return Buffer.concat([decipher.update(data.subarray(28)),decipher.final()]).toString('utf8');};
 app.post('/api/v1/parcels/:id/recipient-code',async(req,res)=>{
  if(!secure(req)){res.status(403).json({error:'secure_transport_required'});return;}
  const user=await session(req);if(!user){res.status(401).json({error:'unauthorized'});return;}
  if(!['CLIENT','LIVREUR'].includes(user.role)){res.status(403).json({error:'forbidden'});return;}
  if(!secret||secret.length<32){res.status(503).json({error:'tracking_unavailable'});return;}
  if(!z.uuid().safeParse(req.params.id).success){res.status(400).json({error:'invalid_input'});return;}
  if(!await rate('recipient-issue:'+user.id,30,60)){res.status(429).json({error:'rate_limited'});return;}
  const exists=await pool.query("SELECT 1 FROM parcel_orders o LEFT JOIN parcel_manual_prices p ON p.order_id=o.id WHERE o.id=$1 AND ((o.client_id=$2 AND $3='CLIENT') OR (p.assigned_driver_id=$2 AND $3='LIVREUR' AND p.delivery_status IS NOT NULL))",[req.params.id,user.id,user.role]);
  if(!exists.rowCount){res.status(404).json({error:'not_found'});return;}
  const provided=z.object({code:z.string().regex(/^\d{9}$/).optional()}).strict().safeParse(req.body||{});if(!provided.success){res.status(400).json({error:'invalid_input'});return;}
  for(let i=0;i<5;i++){
   const existing=await pool.query('SELECT code_hash,encrypted_code FROM recipient_tracking_codes WHERE order_id=$1',[req.params.id]);
   if(existing.rowCount){
    const row=existing.rows[0];let code:string;
    if(row.encrypted_code){try{code=decrypt(row.encrypted_code);}catch{res.status(503).json({error:'tracking_unavailable'});return;}}
    else {code=provided.data.code||'';if(!code){res.status(409).json({error:'existing_code_needed'});return;}if(digest(code)!==row.code_hash){res.status(400).json({error:'invalid_code'});return;}await pool.query('UPDATE recipient_tracking_codes SET encrypted_code=$2 WHERE order_id=$1 AND code_hash=$3 AND encrypted_code IS NULL',[req.params.id,encrypt(code),row.code_hash]);}
    res.set('Cache-Control','no-store').json({code});return;
   }
   const code=String(randomInt(100000000,1000000000));
   try{const inserted=await pool.query("INSERT INTO recipient_tracking_codes(order_id,code_hash,encrypted_code,expires_at) VALUES($1,$2,$3,'infinity'::timestamptz) ON CONFLICT(order_id) DO NOTHING RETURNING order_id",[req.params.id,digest(code),encrypt(code)]);if(inserted.rowCount){res.set('Cache-Control','no-store').json({code});return;}}
   catch(e){if((e as {code?:string}).code!=='23505')throw e;}
  }
  res.status(503).json({error:'tracking_unavailable'});
 });
 app.get('/api/v1/recipient-tracking/photos/:slot',async(req,res)=>{
  if(!secure(req)){res.status(403).json({error:'secure_transport_required'});return;}
  if(!secret||secret.length<32){res.status(503).json({error:'tracking_unavailable'});return;}
  const ip=createHash('sha256').update(req.ip||'').digest('hex');
  if(!await rate('recipient-photo-ip:'+ip,30,15)||!await rate('recipient-photo-global',1000,15)){res.status(429).json({error:'rate_limited'});return;}
  const code=req.get('x-recipient-code')||'',slot=req.params.slot;
  if(!/^\d{9}$/.test(code)||! /^[1-3]$/.test(slot)){res.status(400).json({error:'invalid_input'});return;}
  const result=await pool.query("SELECT ph.object_key FROM recipient_tracking_codes c JOIN parcel_photos ph ON ph.order_id=c.order_id LEFT JOIN parcel_manual_prices p ON p.order_id=c.order_id WHERE c.code_hash=$1 AND ph.slot=$2",[digest(code),Number(slot)]);
  if(!result.rowCount){res.status(404).json({error:'not_found'});return;}
  if(!store){res.status(503).json({error:'photo_storage_unavailable'});return;}
  try{const bytes=await store.get(result.rows[0].object_key);res.set({'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}).type('image/jpeg').send(bytes);}catch{res.status(503).json({error:'photo_storage_unavailable'});}
 });
 app.post('/api/v1/recipient-tracking/delivery-request',async(req,res)=>{
  if(!secure(req)){res.status(403).json({error:'secure_transport_required'});return;}
  if(!secret||secret.length<32){res.status(503).json({error:'tracking_unavailable'});return;}
  const ip=createHash('sha256').update(req.ip||'').digest('hex');
  const ipAllowed=await rate('recipient-action-ip:'+ip,10,15);const globalAllowed=await rate('recipient-action-global',500,15);
  if(!ipAllowed||!globalAllowed){res.status(429).json({error:'rate_limited'});return;}
  const parsed=z.object({code:z.string().regex(/^\d{9}$/)}).strict().safeParse(req.body);if(!parsed.success){res.status(400).json({error:'invalid_input'});return;}
  const hash=digest(parsed.data.code);
  const result=await pool.query("UPDATE parcel_manual_prices p SET delivery_requested_at=COALESCE(p.delivery_requested_at,now()) FROM recipient_tracking_codes c WHERE c.order_id=p.order_id AND c.code_hash=$1 AND p.delivery_status='PICKED_UP' RETURNING p.delivery_requested_at",[hash]);
  res.set('Cache-Control','no-store');
  if(result.rowCount){res.json({confirmationRequested:true,deliveryRequestedAt:result.rows[0].delivery_requested_at});return;}
  const valid=await pool.query("SELECT 1 FROM recipient_tracking_codes c LEFT JOIN parcel_manual_prices p ON p.order_id=c.order_id WHERE c.code_hash=$1",[hash]);
  res.status(valid.rowCount?409:404).json({error:valid.rowCount?'delivery_unavailable':'invalid_code'});
 });
 app.post('/api/v1/recipient-tracking',async(req,res)=>{
  if(!secure(req)){res.status(403).json({error:'secure_transport_required'});return;}
  if(!secret||secret.length<32){res.status(503).json({error:'tracking_unavailable'});return;}
  const ip=createHash('sha256').update(req.ip||'').digest('hex');
  const ipAllowed=await rate('recipient-ip:'+ip,10,15);const globalAllowed=await rate('recipient-global',500,15);
  if(!ipAllowed||!globalAllowed){res.status(429).json({error:'rate_limited'});return;}
  const parsed=z.object({code:z.string().regex(/^\d{9}$/)}).strict().safeParse(req.body);if(!parsed.success){res.status(400).json({error:'invalid_input'});return;}
  const r=await pool.query(`SELECT o.parcel_name,COALESCE(o.public_description,o.description) AS description,o.pickup_address,o.destination_address,o.recipient_name,o.recipient_phone,o.weight_category,o.size_category,o.fragile,o.instructions,COALESCE((SELECT json_agg(json_build_object('slot',ph.slot,'version',md5(ph.object_key)) ORDER BY ph.slot) FROM parcel_photos ph WHERE ph.order_id=o.id),'[]'::json) AS photos,o.created_at,o.status AS order_status,s.status AS search_status,p.delivery_status,p.pickup_requested_at,p.picked_up_at,p.delivery_requested_at,p.delivered_at,p.assigned_at,COALESCE(p.agreed_price_dh,p.amount_dh,o.proposed_price_dh) AS price_dh FROM recipient_tracking_codes c JOIN parcel_orders o ON o.id=c.order_id LEFT JOIN parcel_manual_prices p ON p.order_id=o.id LEFT JOIN parcel_searches s ON s.order_id=o.id WHERE c.code_hash=$1`,[digest(parsed.data.code)]);
  res.set('Cache-Control','no-store');if(!r.rowCount){res.status(404).json({error:'invalid_code'});return;}res.json({delivery:r.rows[0]});
 });
}
