# Livraison Maroc — export source

API TypeScript/Express, application mobile Expo/React Native et migrations PostgreSQL/PostGIS. Cet export ne contient ni données, ni tests, ni configuration de service réelle.

## Prérequis

Node.js et npm, Docker avec Compose, et pour Android un JDK, Android Studio et son SDK. MapLibre exige un development build natif : Expo Go ne suffit pas.

## Base et API

Dans PowerShell, depuis le dossier extrait :

```powershell
Copy-Item infrastructure/.env.example infrastructure/.env
Copy-Item backend/.env.example backend/.env
Set-Location infrastructure
docker compose up -d
Set-Location ../backend
npm ci
npm run migrate
npm run db:check
npm run dev
```

Les identifiants de base fournis sont fictifs et réservés au développement local. Les champs de services externes sont vides : configurez vos propres services selon les fonctionnalités voulues.

## Application Android

Dans un autre terminal, depuis le dossier extrait :

```powershell
Copy-Item mobile/.env.example mobile/.env
Set-Location mobile
npm ci
npx expo run:android
```

Renseignez `EXPO_PUBLIC_API_URL` avec une adresse accessible depuis l’appareil (127.0.0.1 désigne l’appareil lui-même). Configurez un fournisseur de cartes autorisé. Les fonctions Google/Firebase nécessitent votre propre configuration, notamment un fichier Firebase Android fourni localement et une configuration Expo adaptée. Les services de courriel, stockage et appels nécessitent également leur propre configuration. Les fichiers de configuration réels ne doivent pas être publiés.
