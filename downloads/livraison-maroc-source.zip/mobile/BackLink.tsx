import React from 'react';
import {Pressable,StyleSheet,Text} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
export default function BackLink({lang,onPress,disabled=false}:{lang:'fr'|'ar';onPress:()=>void;disabled?:boolean}){
 const ar=lang==='ar';return <Pressable accessibilityRole="button" accessibilityLabel={ar?'رجوع':'Retour'} disabled={disabled} onPress={onPress} style={[styles.link,disabled&&styles.disabled]}><Ionicons name={ar?'arrow-forward':'arrow-back'} size={20} color="#087b61"/><Text style={styles.text}>{ar?'رجوع':'Retour'}</Text></Pressable>;
}
const styles=StyleSheet.create({link:{alignSelf:'flex-start',flexDirection:'row',alignItems:'center',gap:8,paddingVertical:10},text:{color:'#087b61',fontWeight:'700'},disabled:{opacity:0.5}});
