export type AvailabilityQueueOptions<T> = {
 current:()=>boolean;
 apply:(target:boolean,isCurrent:()=>boolean)=>Promise<T|null>;
 applied:(result:T)=>void;
 intent:(target:boolean|null)=>void;
 pending:(value:boolean)=>void;
 failed:(error:unknown)=>Promise<void>;
};

// Only one request at a time; the latest tap is applied after any in-flight request.
export function createAvailabilityQueue<T>(options:AvailabilityQueueOptions<T>) {
 let desired:boolean|null=null, running=false;
 const run=async()=>{
  if(running)return;
  running=true;options.pending(true);
  try {
   while(desired!==null&&desired!==options.current()){
    const target:boolean=desired;
    const result=await options.apply(target,()=>desired===target);
    if(result!==null)options.applied(result);
    if(desired===target&&options.current()!==target)throw Error('availability_not_updated');
   }
  }catch(error){desired=null;await options.failed(error);}
  finally{desired=null;running=false;options.intent(null);options.pending(false);}
 };
 const set=(target:boolean)=>{desired=target;options.intent(target);void run();};
 return {set,toggle(){set(!(desired??options.current()));}};
}
