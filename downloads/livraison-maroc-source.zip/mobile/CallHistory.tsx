import React,{useCallback,useEffect,useState} from 'react';
import {ActivityIndicator,Pressable,StyleSheet,Text,View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import BackLink from './BackLink';
import {fetchWithTimeout,requireOk,requestMessage} from './http';
import {formatDateTime} from './dateTime';

type CallRecord={id:string;order_id:string;started_at:string;outgoing:boolean;counterpart_name:string|null;counterpart_role:'CLIENT'|'LIVREUR'};
export default function CallHistory({api,session,lang,onBack,onOpen,embedded=false}:{api?:string;session:string;lang:'fr'|'ar';onBack:()=>void;onOpen:(id:string)=>void;embedded?:boolean}){
 const ar=lang==='ar';const [calls,setCalls]=useState<CallRecord[]>([]),[loading,setLoading]=useState(true),[error,setError]=useState('');
 const load=useCallback(async()=>{if(!api){setError(ar?'الخدمة غير متاحة.':'Service indisponible.');setLoading(false);return;}try{const r=await requireOk(await fetchWithTimeout(api.replace(/\/$/,'')+'/api/v1/voice/history',{headers:{Authorization:'Bearer '+session}}));const data=await r.json();setCalls(data.calls);setError('');}catch(e){setError(requestMessage(e,lang));}finally{setLoading(false);}},[api,session,lang]);
 useEffect(()=>{void load();const timer=setInterval(()=>void load(),15000);return()=>clearInterval(timer);},[load]);
 return <View style={{direction:ar?'rtl':'ltr'}}>{!embedded&&<><BackLink lang={lang} onPress={onBack}/><Text style={styles.title}>{ar?'المكالمات':'Appels'}</Text></>}{loading&&<ActivityIndicator color="#087b61"/>}{!!error&&<Text style={styles.error}>{error}</Text>}{!loading&&!error&&!calls.length&&<Text style={styles.note}>{ar?'لا توجد مكالمات بعد.':'Aucun appel pour le moment.'}</Text>}{calls.map(call=><Pressable key={call.id} accessibilityRole="button" onPress={()=>onOpen(call.order_id)} style={styles.item}><View style={styles.icon}><Ionicons name={call.outgoing?'call-outline':'call'} size={23} color="#087b61"/></View><View style={styles.content}><Text style={styles.name}>{call.counterpart_name|| (call.counterpart_role==='CLIENT'?(ar?'الزبون':'Client'):(ar?'الموصل':'Livreur'))}</Text><Text style={styles.note}>{call.outgoing?(ar?'مكالمة صادرة':'Appel sortant'):(ar?'مكالمة واردة':'Appel entrant')} · {formatDateTime(call.started_at,lang)}</Text></View><Ionicons name={ar?'chevron-back':'chevron-forward'} size={18} color="#8aa198"/></Pressable>)}</View>;
}
const styles=StyleSheet.create({title:{fontSize:30,fontWeight:'800',color:'#173d35',marginBottom:12},item:{backgroundColor:'white',borderRadius:16,borderWidth:1,borderColor:'#e0ece6',padding:15,marginVertical:6,flexDirection:'row',alignItems:'center',gap:12},icon:{width:46,height:46,borderRadius:23,backgroundColor:'#e2f2ea',alignItems:'center',justifyContent:'center'},content:{flex:1},name:{fontSize:17,fontWeight:'800',color:'#173d35'},note:{color:'#637a72',fontSize:13,marginTop:5},error:{color:'#a83232',marginVertical:8}});
