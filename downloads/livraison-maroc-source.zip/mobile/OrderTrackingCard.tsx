import React from 'react';
import {StyleSheet,Text,View} from 'react-native';
import {formatDateTime} from './dateTime';
import {deliveryTracking,DeliveryProgress} from './deliveryTracking';

export default function DeliveryTracking({delivery,lang}:{delivery:DeliveryProgress;lang:'fr'|'ar'}){
 return <View style={styles.card}><Text style={styles.title}>{lang==='fr'?'Suivi de commande':'متابعة الطلب'}</Text>{deliveryTracking(delivery,lang).map((step,index)=><View key={index} style={styles.row}><Text style={[styles.symbol,step.current&&styles.current]}>{step.done?'✓':step.current?'●':'○'}</Text><View style={styles.details}><Text style={[styles.label,!step.done&&!step.current&&styles.future]}>{step.label}</Text>{!!formatDateTime(step.date,lang)&&<Text style={styles.date}>{formatDateTime(step.date,lang)}</Text>}{step.current&&step.showWaiting!==false&&<Text style={styles.date}>{lang==='fr'?'En attente':'في الانتظار'}</Text>}</View></View>)}</View>;
}
const styles=StyleSheet.create({card:{backgroundColor:'#fff',borderWidth:1,borderColor:'#e6eee8',borderRadius:20,padding:18,marginVertical:10},title:{fontSize:18,fontWeight:'800',color:'#173d35',marginBottom:8},row:{flexDirection:'row',gap:10,marginTop:12},symbol:{color:'#087b61',fontWeight:'800',fontSize:16,width:20},current:{color:'#d58b19'},details:{flex:1},label:{color:'#173d35',fontSize:14,lineHeight:20},future:{color:'#8b9b94'},date:{color:'#637a72',fontSize:12,marginTop:2}});
