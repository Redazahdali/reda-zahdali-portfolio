import type {ImagePickerAsset} from 'expo-image-picker';
import {ApiError,fetchWithTimeout,requireOk} from './http.ts';

export async function syncParcelPhotos(api:string,session:string,id:string,photos:ImagePickerAsset[],uploaded:Map<number,string>){
 const base=api.replace(/\/$/,'')+'/api/v1/parcels/'+id+'/photos';
 const headers={Authorization:'Bearer '+session};
 const list=await requireOk(await fetchWithTimeout(base,{headers}));
 const existing=(await list.json()).photos as {slot:number}[];
 for(const item of existing.filter(item=>item.slot>photos.length)){
  await requireOk(await fetchWithTimeout(base+'/'+item.slot,{method:'DELETE',headers}));
  uploaded.delete(item.slot);
 }
 for(let i=0;i<photos.length;i++){
  const photo=photos[i],slot=i+1;
  if(uploaded.get(slot)===photo.uri&&existing.some(item=>item.slot===slot))continue;
  const local=await fetch(photo.uri);if(!local.ok)throw new ApiError(400,'invalid_photo');
  const blob=await local.blob();if(blob.size>8*1024*1024)throw new ApiError(413,'photo_too_large');
  const type=photo.mimeType||blob.type||'image/jpeg';if(!['image/jpeg','image/png','image/webp'].includes(type))throw new ApiError(400,'invalid_photo');
  await requireOk(await fetchWithTimeout(base+'/'+slot,{method:'PUT',headers:{...headers,'Content-Type':type},body:blob},45000));
  uploaded.set(slot,photo.uri);
 }
}
