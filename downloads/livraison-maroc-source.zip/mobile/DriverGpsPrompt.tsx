import React,{useCallback,useEffect,useRef,useState} from 'react';
import {Alert,AppState,Linking,Platform,Pressable,StyleSheet,Text,View} from 'react-native';
import * as Location from 'expo-location';
import {checkDriverGps,type DriverGpsStatus} from './driverGpsPermission';

const adapter={getPermission:Location.getForegroundPermissionsAsync,requestPermission:Location.requestForegroundPermissionsAsync,servicesEnabled:Location.hasServicesEnabledAsync,...(Platform.OS==='android'?{enableServices:Location.enableNetworkProviderAsync}:{})};
type Props={lang:'fr'|'ar';onReady:()=>void;paused?:boolean};
export default function DriverGpsPrompt({lang,onReady,paused=false}:Props){
 const [status,setStatus]=useState<DriverGpsStatus|null>(null);const mounted=useRef(false),started=useRef(false),inFlight=useRef(false);const ar=lang==='ar';
 const openLocationSettings=useCallback(()=>{if(Platform.OS==='android')void Linking.sendIntent('android.settings.LOCATION_SOURCE_SETTINGS').catch(()=>Linking.openSettings().catch(()=>{}));else void Linking.openSettings().catch(()=>{});},[]);
 const openPermissionSettings=useCallback(()=>{void Linking.openSettings().catch(()=>{});},[]);
 const check=useCallback(async(ask:boolean,showPrompt:boolean)=>{
  if(inFlight.current)return;inFlight.current=true;
  try {
   const next=await checkDriverGps(adapter,ask,showPrompt);if(!mounted.current)return;setStatus(next);if(next==='ready')onReady();
   if(showPrompt&&Platform.OS!=='android'&&next==='services_disabled'&&AppState.currentState==='active')Alert.alert(ar?'فعّل الموقع':'Activer le GPS',ar?'فعّل موقع الهاتف لاستقبال طلبات التوصيل القريبة.':'Activez la localisation du téléphone pour recevoir les demandes de livraison à proximité.',[{text:ar?'لاحقاً':'Plus tard',style:'cancel'},{text:ar?'الإعدادات':'Ouvrir les réglages',onPress:openLocationSettings}]);
  } finally {inFlight.current=false;}
 },[ar,openLocationSettings,onReady]);
 useEffect(()=>{
  mounted.current=true;const start=()=>{if(!started.current){started.current=true;void check(true,true);}else void check(false,false);};
  if(!paused&&(AppState.currentState==='active'||AppState.currentState===null))start();
  const subscription=AppState.addEventListener('change',state=>{if(!paused&&state==='active')start();});
  return()=>{mounted.current=false;subscription.remove();};
 },[check,paused]);
 if(!paused&&(!status||status==='ready'))return null;
 const message=status==='services_disabled'?(ar?'فعّل موقع الهاتف لتلقي الطلبات القريبة.':'Activez le GPS du téléphone pour recevoir les demandes proches.'):status==='unavailable'?(ar?'تعذر التحقق من الموقع. حاول مجدداً.':'Impossible de vérifier le GPS. Réessayez.'):(ar?'اسمح للتطبيق باستخدام الموقع لاستقبال الطلبات القريبة.':'Autorisez la localisation pour recevoir les demandes proches.');
 const action=()=>{if(status==='services_disabled')openLocationSettings();else if(status==='permission_blocked')openPermissionSettings();else void check(true,true);};
 return <View style={styles.banner}><Text style={styles.message}>{message}</Text><Pressable accessibilityRole="button" onPress={action} style={styles.button}><Text style={styles.buttonText}>{ar?'تفعيل الموقع':'Activer le GPS'}</Text></Pressable></View>;
}
const styles=StyleSheet.create({banner:{backgroundColor:'#fff1dd',borderRadius:14,padding:14,marginBottom:12},message:{color:'#765121',lineHeight:20},button:{alignSelf:'flex-start',marginTop:8,paddingVertical:8,paddingHorizontal:12,backgroundColor:'#e6eee8',borderRadius:10},buttonText:{color:'#095c4d',fontWeight:'700'}});
