export type Point=[number,number];
const cities=new Set(['Kenitra','Mehdia','Rabat','Sale','Temara','Casablanca','Mohammedia','Marrakech','Fes','Tanger']);
export const validPoint=(p:unknown):p is Point=>Array.isArray(p)&&p.length===2&&p.every(v=>typeof v==='number'&&Number.isFinite(v))&&Math.abs(p[0])<=180&&Math.abs(p[1])<=90;
export function deliveryDirectionsUrl(pickup:Point,destination:Point):string {
 if(!validPoint(pickup)||!validPoint(destination))throw Error('invalid point');
 const origin=encodeURIComponent(`${pickup[1]},${pickup[0]}`),end=encodeURIComponent(`${destination[1]},${destination[0]}`);
 return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${end}&travelmode=driving`;
}
export function publicRoute(data:any):Point[]|null {const points=data?.code==='Ok'&&data?.routes?.[0]?.geometry?.coordinates;return Array.isArray(points)&&points.length>=2&&points.every(validPoint)?points:null;}
export function publicRouteDistance(data:any):number|null {const distance=data?.code==='Ok'?data?.routes?.[0]?.distance:null;return typeof distance==='number'&&Number.isFinite(distance)&&distance>=0&&distance<=1000000?distance:null;}
export function publicCityPoint(city:string,data:any):Point|null{
 if(!cities.has(city)||!Array.isArray(data?.features))return null;
 const norm=(x:string)=>x.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const aliases:Record<string,string[]>={Mehdia:['mehdia','mehdya'],Fes:['fes','fez'],Tanger:['tanger','tangier']};const names=aliases[city]||[norm(city)];
 const matches=data.features.filter((f:any)=>f?.properties?.countrycode?.toLowerCase()==='ma'&&['city','town','village'].includes(f.properties?.osm_value)&&typeof f.properties?.name==='string'&&names.includes(norm(f.properties.name))&&validPoint(f.geometry?.coordinates));
 return matches.length===1?matches[0].geometry.coordinates:null;
}
export function approachKm(a:Point,b:Point){const rad=Math.PI/180,lat=(b[1]-a[1])*rad,lon=(b[0]-a[0])*rad;const v=Math.sin(lat/2)**2+Math.cos(a[1]*rad)*Math.cos(b[1]*rad)*Math.sin(lon/2)**2;return 12742*Math.asin(Math.sqrt(Math.min(1,v)));}
