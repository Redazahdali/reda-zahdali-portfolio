import React,{useEffect,useRef,useState} from 'react';
import {Alert,Image,Linking,Platform,Pressable,StyleSheet,Text,View} from 'react-native';
import type {ImagePickerAsset,ImagePickerOptions} from 'expo-image-picker';
import {Ionicons} from '@expo/vector-icons';
import {fetchWithTimeout,requireOk} from './http';

type Photo=ImagePickerAsset;
function imagePicker(){try{return require('expo-image-picker') as typeof import('expo-image-picker');}catch{return null;}}
type PickerProps={lang:'fr'|'ar';photos:Photo[];onChange:(photos:Photo[])=>void;beforePick:()=>Promise<void>;afterPick:()=>Promise<void>;recovering?:boolean;guided?:boolean};
export function ParcelPhotoPicker({lang,photos,onChange,beforePick,afterPick,recovering,guided=false}:PickerProps){
 const ar=lang==='ar',lock=useRef(false),current=useRef(photos);current.current=photos;
 const [busy,setBusy]=useState(false);
 const add=(assets:Photo[])=>onChange([...current.current,...assets].slice(0,3));
 useEffect(()=>{let alive=true;const picker=imagePicker();if(Platform.OS==='android'&&picker&&recovering)void picker.getPendingResultAsync().then(result=>{if(alive&&result&&'canceled' in result&&!result.canceled)add(result.assets);}).catch(()=>{}).finally(()=>{if(alive)void afterPick().catch(()=>{});});return()=>{alive=false;};},[]);
 const choose=async(camera:boolean)=>{if(lock.current)return;const picker=imagePicker();if(!picker){Alert.alert(ar?'يلزم تحديث التطبيق':'Mise à jour nécessaire',ar?'حدّث التطبيق لاستخدام الصور.':'Une nouvelle version de l’application est nécessaire pour les photos.');return;}lock.current=true;setBusy(true);try{
  if(camera){const permission=await picker.requestCameraPermissionsAsync();if(!permission.granted){Alert.alert(ar?'إذن الكاميرا':'Autorisation caméra',ar?'اسمح بالكاميرا لالتقاط صورة.':'Autorisez la caméra pour prendre une photo.',permission.canAskAgain?[{text:'OK'}]:[{text:ar?'إلغاء':'Annuler',style:'cancel'},{text:ar?'الإعدادات':'Réglages',onPress:()=>void Linking.openSettings()}]);return;}}
  await beforePick();
  const options:ImagePickerOptions={mediaTypes:['images'],quality:0.8,...(!camera?{allowsMultipleSelection:true,selectionLimit:3-current.current.length}:{}),exif:false};
  const result=camera?await picker.launchCameraAsync(options):await picker.launchImageLibraryAsync(options);
  if(!result.canceled)add(result.assets);
  await afterPick();
 }catch{void afterPick().catch(()=>{});Alert.alert(ar?'تعذر إضافة الصورة':'Photo indisponible',ar?'حاول مجدداً.':'Impossible d’ajouter la photo. Réessayez.');}finally{lock.current=false;setBusy(false);}};
 const open=()=>Alert.alert(ar?'إضافة صور':'Ajouter des photos',ar?'اختر المصدر':'Choisissez la source',[{text:ar?'التقاط صورة':'Prendre une photo',onPress:()=>void choose(true)},{text:ar?'معرض الصور':'Galerie',onPress:()=>void choose(false)},{text:ar?'إلغاء':'Annuler',style:'cancel'}]);
 return <View><Text style={styles.label}>{ar?'صور الطرد (اختياري، حتى 3)':'Photos du colis (facultatif, 3 maximum)'}</Text><View style={styles.row}>{photos.map((photo,i)=><View key={photo.uri+':'+i} style={styles.tile}><Image source={{uri:photo.uri}} style={styles.image}/><Pressable accessibilityRole="button" accessibilityLabel={(ar?'حذف الصورة ':'Supprimer la photo ')+(i+1)} onPress={()=>onChange(current.current.filter((_,index)=>index!==i))} style={styles.remove}><Ionicons name="close" size={18} color="white"/></Pressable></View>)}{photos.length<3&&<Pressable accessibilityRole="button" accessibilityLabel={ar?'إضافة صورة':'Ajouter une photo'} disabled={busy} onPress={open} style={[styles.add,guided&&styles.guide]}><Ionicons name="add" size={30} color="#087b61"/><Text style={styles.addText}>{ar?'إضافة':'Ajouter'}</Text></Pressable>}</View></View>;
}

export type RemotePhoto={slot:number;proof?:string};
export function ParcelPhotoPreview({photos,lang}:{photos:Photo[];lang:'fr'|'ar'}){
 return <View style={styles.row}>{photos.map((photo,i)=><Image key={photo.uri+':'+i} accessibilityLabel={(lang==='ar'?'صورة الطرد ':'Photo du colis ')+(i+1)} source={{uri:photo.uri}} style={styles.tile}/>)}</View>;
}
export function ParcelPhotoGallery({api,session,id,photos,lang}:{api?:string;session:string;id:string;photos:RemotePhoto[];lang:'fr'|'ar'}){
 const [broken,setBroken]=useState<number[]>([]);const stamp=photos.map(photo=>photo.slot+':'+(photo.proof||'')).join(',');
 useEffect(()=>{setBroken([]);},[id,stamp]);
 if(!api||!photos.length)return null;
 return <View style={styles.row}>{photos.map(photo=><View key={photo.slot+':'+(photo.proof||'')} style={styles.tile}>{broken.includes(photo.slot)?<Text style={styles.photoError}>{lang==='ar'?'الصورة غير متاحة':'Photo indisponible'}</Text>:<Image accessibilityLabel={(lang==='ar'?'صورة الطرد ':'Photo du colis ')+photo.slot} source={{uri:api.replace(/\/$/,'')+'/api/v1/parcels/'+id+'/photos/'+photo.slot+(photo.proof?'?proof='+encodeURIComponent(photo.proof):''),headers:{Authorization:'Bearer '+session}}} onError={()=>setBroken(current=>current.includes(photo.slot)?current:[...current,photo.slot])} style={styles.image}/>}</View>)}</View>;
}
export function ParcelPhotoViewer({api,session,id,lang}:{api?:string;session:string;id:string;lang:'fr'|'ar'}){
 const [photos,setPhotos]=useState<RemotePhoto[]>([]),[error,setError]=useState(false);
 useEffect(()=>{let active=true;if(api)void (async()=>{try{const r=await requireOk(await fetchWithTimeout(api.replace(/\/$/,'')+'/api/v1/parcels/'+id+'/photos',{headers:{Authorization:'Bearer '+session}}));const data=await r.json();if(active){setPhotos(data.photos);setError(false);}}catch{if(active){setPhotos([]);setError(true);}}})();return()=>{active=false;};},[api,id,session]);
 return error?<Text style={styles.photoError}>{lang==='ar'?'تعذر تحميل الصور.':'Impossible de charger les photos.'}</Text>:<ParcelPhotoGallery api={api} session={session} id={id} photos={photos} lang={lang}/>;
}
const styles=StyleSheet.create({label:{fontSize:15,fontWeight:'700',color:'#173d35',marginTop:14},row:{flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:8},tile:{width:90,height:90,borderRadius:10,overflow:'hidden',backgroundColor:'#edf2ee'},image:{width:'100%',height:'100%'},photoError:{color:'#a83232',fontSize:12,padding:6},add:{width:90,height:90,borderRadius:10,borderWidth:1,borderColor:'#cbdcd3',borderStyle:'dashed',alignItems:'center',justifyContent:'center'},guide:{borderColor:'#35b86a',borderStyle:'solid'},addText:{fontSize:12,color:'#095c4d',fontWeight:'700'},remove:{position:'absolute',top:4,right:4,width:28,height:28,borderRadius:14,alignItems:'center',justifyContent:'center',backgroundColor:'#173d35'}});
