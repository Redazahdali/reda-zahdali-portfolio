import React from 'react';
import {StyleSheet,Text,View} from 'react-native';
import {ParcelPhotoViewer} from './ParcelPhotos';
import {weightLabel} from './parcelWeight';

export type ParcelInformation={id:string;parcelName?:string|null;description?:string|null;pickupAddress?:string|null;destinationAddress?:string|null;recipientName?:string|null;recipientPhone?:string|null;instructions?:string|null;weightCategory?:string|null;sizeCategory?:string|null;fragile?:boolean|null;statusLabel?:string|null};
export default function ParcelInformationCard({order,api,session,lang,photoContent}:{order:ParcelInformation;api?:string;session:string;lang:'fr'|'ar';photoContent?:React.ReactNode}){
 const ar=lang==='ar';
 const sizes:Record<string,string>=ar?{SMALL:'صغير',MEDIUM:'متوسط',LARGE:'كبير'}:{SMALL:'Petit',MEDIUM:'Moyen',LARGE:'Grand'};
 const item=(label:string,value?:string|null)=>value?<><Text style={styles.label}>{label}</Text><Text style={styles.value}>{value}</Text></>:null;
 return <View style={styles.card}><Text style={styles.title}>{order.parcelName||order.description||(ar?'الاسم غير متوفر':'Nom non renseigné')}</Text>{photoContent===undefined?<ParcelPhotoViewer api={api} session={session} id={order.id} lang={lang}/>:photoContent}{!!order.statusLabel&&<Text style={styles.sub}>{order.statusLabel}</Text>}{item(ar?'الانطلاق':'Départ',order.pickupAddress)}{item(ar?'الوجهة':'Destination',order.destinationAddress)}{item(ar?'المستلم':'Destinataire',[order.recipientName,order.recipientPhone].filter(Boolean).join(' · '))}{item(ar?'وصف الطرد':'Description du colis',order.description)}{item(ar?'التعليمات':'Instructions',order.instructions)}{item(ar?'الوزن · الحجم':'Poids · Taille',[order.weightCategory?weightLabel(order.weightCategory,lang):'',order.sizeCategory?(sizes[order.sizeCategory]||order.sizeCategory):''].filter(Boolean).join(' · '))}{order.fragile!=null&&<Text style={styles.label}>{ar?'قابل للكسر':'Fragile'} : {order.fragile?(ar?'نعم':'Oui'):(ar?'لا':'Non')}</Text>}</View>;
}
const styles=StyleSheet.create({card:{backgroundColor:'white',borderWidth:1,borderColor:'#e6eee8',borderRadius:20,padding:20,marginVertical:8},title:{fontSize:18,fontWeight:'800',color:'#173d35'},sub:{fontSize:15,color:'#637a72',lineHeight:22,marginTop:8},label:{color:'#173d35',fontWeight:'700',marginTop:14},value:{color:'#173d35'}});
