type DriverLocationProfile={approval_status?:string;availability?:string;location_valid_for_ms?:number};
export function shouldRefreshDriverLocation(profile:DriverLocationProfile|null,foreground:boolean):boolean {
 return !!profile&&foreground&&profile.approval_status==='APPROVED'&&['AVAILABLE','RESERVED'].includes(profile.availability||'')&&typeof profile.location_valid_for_ms==='number'&&Number.isFinite(profile.location_valid_for_ms)&&profile.location_valid_for_ms<=180000;
}
