export async function fetchWithTimeout(url:string,options:RequestInit,ms=15000):Promise<Response>{
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),ms);
 try{return await fetch(url,{...options,signal:controller.signal});}finally{clearTimeout(timer);}
}

export class ApiError extends Error {
 status:number; code:string;
 constructor(status:number, code:string) { super(code || 'http'); this.status=status; this.code=code; }
}
export async function requireOk(response:Response):Promise<Response> {
 if (!response.ok) { let code=''; try { const data=await response.json(); if(typeof data?.error==='string') code=data.error; } catch {} throw new ApiError(response.status,code); }
 return response;
}
export function requestMessage(error:unknown,lang:'fr'|'ar'):string {
 const ar=lang==='ar';
 if(error instanceof ApiError) {
  if(error.status===429) return ar?'محاولات كثيرة. حاول لاحقاً.':'Trop de tentatives. Réessayez plus tard.';
  if(error.status===401) return ar?'انتهت الجلسة أو أصبحت غير صالحة. أعد تسجيل الدخول.':'Session expirée ou invalide. Reconnectez-vous.';
  if(error.code==='secure_transport_required') return ar?'يتطلب هذا الإجراء اتصالاً آمناً.':'Cette action nécessite une connexion sécurisée.';
  if(error.code==='contact_expired') return ar?'انتهت مدة التواصل بعد التسليم.':'La période de contact après livraison est terminée.';
  if(error.code==='voice_test_read_only') return ar?'هذا الإجراء غير متاح أثناء اختبار المكالمة.':'Cette action est désactivée pendant le test d’appel.';
  if(error.status===403) return ar?'الحساب غير مخول لهذا الإجراء. تحقق من دورك وحالة حسابك.':'Compte non autorisé pour cette action. Vérifiez votre rôle et votre statut.';
  if(error.code==='out_of_range') return ar?'الطلب خارج نطاق 30 كم.':'Cette demande est à plus de 30 km de votre position.';
  if(error.code==='parcel_incompatible') return ar?'حجم الطرد أو وزنه لا يناسب ملف مركبتك.':'Le poids ou la taille ne correspond pas à votre véhicule.';
  if(error.code==='driver_offer_pending') return ar?'انتظر رد الزبون على عرضك الحالي.':'Attendez la réponse du Client à votre proposition en cours.';
  if(error.code==='mission_limit') return ar?'بلغت الحد الأقصى وهو 10 توصيلات جارية.':'La limite de 10 livraisons en cours est atteinte.';
  if(error.code==='driver_unavailable') return ar?'الموصل غير متاح أو يحتاج إلى تحديث موقعه.':'Livreur indisponible ou position à actualiser.';
  if(error.code==='weight_category_mismatch') return ar?'الوزن لا يطابق الفئة المختارة.':'Le poids ne correspond pas à la plage choisie.';
  if(error.code==='profile_incomplete') return ar?'أكمل ملفك الشخصي أولاً.':'Complétez votre profil avant de continuer.';
  if(error.code==='photo_storage_unavailable') return ar?'تخزين الصور غير متاح حالياً. حاول مجدداً.':'Stockage des photos indisponible. Réessayez sans perdre votre saisie.';
  if(error.code==='invalid_photo') return ar?'الصورة غير صالحة. اختر صورة JPEG أو PNG أو WebP.':'Photo invalide. Choisissez une image JPEG, PNG ou WebP.';
  if(error.code==='photo_too_large') return ar?'الصورة كبيرة جداً (الحد 8 ميغابايت).':'Photo trop volumineuse (8 Mo maximum).';
  if(error.status===400 || error.status===422) return ar?'البيانات غير صالحة. راجع المعلومات المدخلة.':'Données invalides. Vérifiez les informations saisies.';
  if(error.code==='pricing_unavailable') return ar?'التسعير غير متاح حالياً.':'La tarification est actuellement indisponible.';
  if(error.status===404) return ar?'العنصر أو المسار غير موجود.':'Élément ou route introuvable.';
  if(error.status===409) return ar?'تعذر تنفيذ الإجراء بسبب حالة الطلب الحالية.':'Action impossible dans l’état actuel de la demande.';
  return ar?'الخدمة غير متاحة حالياً. حاول لاحقاً.':'Service indisponible. Réessayez plus tard.';
 }
 if(error instanceof Error && error.message==='config') return ar?'عنوان الخدمة غير مضبوط.':'Adresse du service non configurée.';
 if(error instanceof Error && error.message==='invalid response') return ar?'استجابة الخدمة غير صالحة.':'Réponse du service invalide.';
 return ar?'تعذر الاتصال بالخدمة. تحقق من الشبكة.':'Connexion au service impossible. Vérifiez le réseau.';
}
