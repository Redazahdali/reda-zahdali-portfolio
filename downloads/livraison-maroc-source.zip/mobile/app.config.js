// Expo's cloud builder receives the Firebase configuration as a file variable;
// local development keeps using the ignored file in this directory.
const {withAndroidManifest} = require('expo/config-plugins');

module.exports = ({config}) => {
  const result = {
    ...config,
    android: {
      ...config.android,
      googleServicesFile: process.env.GOOGLE_SERVICES_JSON || config.android.googleServicesFile,
    },
  };
  // This setting is only for the explicitly selected computer-connected test.
  if (process.env.EXPO_PUBLIC_LOCAL_USB_TEST !== '1') return result;
  return withAndroidManifest(result, (mod) => {
    const application = mod.modResults.manifest.application?.[0];
    if (!application) throw new Error('Android application manifest missing');
    application.$['android:usesCleartextTraffic'] = 'true';
    return mod;
  });
};
