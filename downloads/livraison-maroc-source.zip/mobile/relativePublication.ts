export function relativePublication(value:string|undefined,lang:'fr'|'ar',now=Date.now()):string {
 if(!value)return '';
 const timestamp=Date.parse(value);if(!Number.isFinite(timestamp))return '';
 const minutes=Math.max(0,Math.floor((now-timestamp)/60000));
 if(minutes<1)return lang==='ar'?'الآن':'À l’instant';
 const unit=minutes<60?'minute':minutes<1440?'hour':'day';
 const count=unit==='minute'?minutes:unit==='hour'?Math.floor(minutes/60):Math.floor(minutes/1440);
 if(lang==='fr'){
  const main=`il y a ${count} ${unit==='minute'?'minute':unit==='hour'?'heure':'jour'}${count>1?'s':''}`;
  const remainder=unit==='hour'?minutes%60:unit==='day'?Math.floor(minutes%1440/60):0;
  return remainder?`${main} et ${remainder} ${unit==='hour'?'minute':'heure'}${remainder>1?'s':''}`:main;
 }
 const words=unit==='minute'?['دقيقة','دقيقتين','دقائق']:unit==='hour'?['ساعة','ساعتين','ساعات']:['يوم','يومين','أيام'];
 const main=count===1?`منذ ${words[0]}`:count===2?`منذ ${words[1]}`:`منذ ${count} ${count<=10?words[2]:words[0]}`;
 const remainder=unit==='hour'?minutes%60:unit==='day'?Math.floor(minutes%1440/60):0;
 return remainder?`${main} و${remainder} ${unit==='hour'?'دقيقة':'ساعة'}`:main;
}
