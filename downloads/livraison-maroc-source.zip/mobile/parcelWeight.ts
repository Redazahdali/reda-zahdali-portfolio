export const parcelWeights=['UNDER_1_KG','ONE_TO_5_KG','FIVE_TO_20_KG','OVER_20_KG'] as const;
export type ParcelWeight=typeof parcelWeights[number];
export function weightLabel(category:string|undefined|null,lang:'fr'|'ar'):string {
 const index=parcelWeights.indexOf(category as ParcelWeight);if(index<0)return '';
 return (lang==='fr'?['Moins de 1 kg','1 à 5 kg','5 à 20 kg','Plus de 20 kg']:['أقل من 1 كغ','من 1 إلى 5 كغ','من 5 إلى 20 كغ','أكثر من 20 كغ'])[index];
}
