export type ClientDeliveryFilter='all'|'todo'|'searching'|'assigned'|'picked_up'|'delivered';
type FilterOrder={status:string;manual_search_status?:string|null;manual_delivery_status?:string|null;pickup_requested_at?:string|null;delivery_requested_at?:string|null};
export function matchesClientDeliveryFilter(order:FilterOrder,filter:ClientDeliveryFilter):boolean {
 if(filter==='all')return true;
 if(filter==='todo')return false;
 const delivery=order.manual_delivery_status;
 if(filter==='delivered')return delivery==='DELIVERED'||(delivery==='PICKED_UP'&&!!order.delivery_requested_at);
 if(filter==='picked_up')return (delivery==='ASSIGNED'&&!!order.pickup_requested_at)||(delivery==='PICKED_UP'&&!order.delivery_requested_at);
 if(filter==='assigned')return delivery==='ASSIGNED'||(delivery==='PICKED_UP'&&!order.delivery_requested_at)||(!delivery&&(order.manual_search_status==='ASSIGNED'||order.status==='ASSIGNED'));
 return !delivery&&(['SEARCHING','OFFER_PENDING'].includes(order.manual_search_status||'')||(!order.manual_search_status&&order.status==='DISCOVERY'));
}

export function matchesDriverDeliveryFilter(order:{status:string;pickup_requested_at?:string|null;delivery_requested_at?:string|null},filter:ClientDeliveryFilter):boolean {
 if(filter==='all')return true;
 if(filter==='todo'||filter==='searching')return order.status==='ASSIGNED'||(order.status==='PICKED_UP'&&!order.delivery_requested_at);
 if(filter==='assigned')return order.status==='ASSIGNED'&&!order.pickup_requested_at;
 if(filter==='picked_up')return (order.status==='ASSIGNED'&&!!order.pickup_requested_at)||(order.status==='PICKED_UP'&&!order.delivery_requested_at);
 return order.status==='DELIVERED'||(order.status==='PICKED_UP'&&!!order.delivery_requested_at);
}
