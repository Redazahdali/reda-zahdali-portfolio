import {fetchWithTimeout} from './http.ts';

type FirebaseResponse={idToken:string;email?:string;localId?:string};
export class FirebaseAuthError extends Error {
 code:string;
 constructor(code:string){super(code);this.code=code;}
}
async function requestFirebase<T>(apiKey:string,method:string,body:object,lang?:'fr'|'ar'):Promise<T>{
 if(!apiKey)throw new FirebaseAuthError('config');
 let response:Response;
 try{response=await fetchWithTimeout('https://identitytoolkit.googleapis.com/v1/accounts:'+method+'?key='+encodeURIComponent(apiKey),{method:'POST',headers:{'Content-Type':'application/json',...(lang?{'X-Firebase-Locale':lang}:{})},body:JSON.stringify(body)});}catch{throw new FirebaseAuthError('network');}
 let result:any;try{result=await response.json();}catch{throw new FirebaseAuthError('server');}
 if(!response.ok){const code=typeof result?.error?.message==='string'?result.error.message:'server';if(typeof __DEV__!=='undefined' && __DEV__ && process.env.EXPO_PUBLIC_AUTH_TEST_MODE==='1')console.warn('Firebase Auth',method,/^[A-Z_]{1,80}$/.test(code)?code:'error',response.status);throw new FirebaseAuthError(code);}
 return result as T;
}
export const firebaseAuth={
 signup:(key:string,email:string,password:string)=>requestFirebase<FirebaseResponse>(key,'signUp',{email:email.trim(),password,returnSecureToken:true}),
 login:(key:string,email:string,password:string)=>requestFirebase<FirebaseResponse>(key,'signInWithPassword',{email:email.trim(),password,returnSecureToken:true}),
 google:(key:string,idToken:string)=>requestFirebase<FirebaseResponse>(key,'signInWithIdp',{postBody:'id_token='+encodeURIComponent(idToken)+'&providerId=google.com',requestUri:'https://localhost',returnSecureToken:true,returnIdpCredential:true}),
 linkGoogle:(key:string,firebaseToken:string,googleToken:string)=>requestFirebase<FirebaseResponse>(key,'signInWithIdp',{idToken:firebaseToken,postBody:'id_token='+encodeURIComponent(googleToken)+'&providerId=google.com',requestUri:'https://localhost',returnSecureToken:true,returnIdpCredential:true}),
 lookup:(key:string,idToken:string)=>requestFirebase<{users?:Array<{emailVerified?:boolean;providerUserInfo?:Array<{providerId?:string}>}>}>(key,'lookup',{idToken}),
 verify:(key:string,idToken:string,lang:'fr'|'ar')=>requestFirebase(key,'sendOobCode',{requestType:'VERIFY_EMAIL',idToken},lang),
 reset:(key:string,email:string,lang:'fr'|'ar')=>requestFirebase(key,'sendOobCode',{requestType:'PASSWORD_RESET',email:email.trim()},lang),
};

export function hasGoogleProvider(account:{users?:Array<{providerUserInfo?:Array<{providerId?:string}>}>}):boolean { return account.users?.[0]?.providerUserInfo?.some(provider=>provider.providerId==='google.com')===true; }
