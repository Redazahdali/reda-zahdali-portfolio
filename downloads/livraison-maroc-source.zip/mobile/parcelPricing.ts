// Existing whole-kilometre rule: every started kilometre after the first is billed.
export function priceForDistance(meters:number):number|null {
 if(!Number.isFinite(meters)||meters<0||meters>1000000)return null;
 return 7+Math.max(0,Math.ceil(Math.ceil(meters)/1000)-1)*4;
}
