export function validLocation(address:string, point:[number,number]|null):boolean {
 return address.trim().length>=5 && address.trim().length<=300 && !!point && Number.isFinite(point[0]) && Number.isFinite(point[1]) && Math.abs(point[0])<=180 && Math.abs(point[1])<=90;
}
export function validRecipient(name:string, phone:string):boolean {
 const p=phone.trim(); return name.trim().length>=2 && name.trim().length<=120 && /^\+?[0-9 ()-]{7,25}$/.test(p) && p.replace(/\D/g,'').length>=7;
}
