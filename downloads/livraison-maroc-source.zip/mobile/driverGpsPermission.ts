type Permission={granted:boolean;canAskAgain:boolean};
export type GpsAdapter={getPermission:()=>Promise<Permission>;requestPermission:()=>Promise<Permission>;servicesEnabled:()=>Promise<boolean>;enableServices?:()=>Promise<void>};
export type DriverGpsStatus='ready'|'permission_denied'|'permission_blocked'|'services_disabled'|'unavailable';
export async function checkDriverGps(adapter:GpsAdapter,askPermission:boolean,askServices=false):Promise<DriverGpsStatus> {
 try {
  let permission=await adapter.getPermission();
  if(!permission.granted&&askPermission&&permission.canAskAgain)permission=await adapter.requestPermission();
  if(!permission.granted)return permission.canAskAgain?'permission_denied':'permission_blocked';
  let enabled=await adapter.servicesEnabled();if(!enabled&&askServices&&adapter.enableServices){try{await adapter.enableServices();}catch{}enabled=await adapter.servicesEnabled();}return enabled?'ready':'services_disabled';
 } catch {return 'unavailable';}
}

export async function requestStartupGps(allow:boolean,adapter:GpsAdapter):Promise<boolean> {
 if(!allow)return false;
 return (await checkDriverGps(adapter,true,true))==='ready';
}
