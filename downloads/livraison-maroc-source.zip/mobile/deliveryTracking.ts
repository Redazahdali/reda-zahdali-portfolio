export type DeliveryProgress={status:'UNASSIGNED'|'ASSIGNED'|'PICKED_UP'|'DELIVERED';searchStatus?:string|null;createdAt?:string|null;assignedAt?:string|null;pickupRequestedAt?:string|null;pickedUpAt?:string|null;deliveryRequestedAt?:string|null;deliveredAt?:string|null};

type TrackingStep={label:string;done:boolean;current:boolean;date?:string|null;showWaiting?:boolean};
export function deliveryTracking(progress:DeliveryProgress,lang:'fr'|'ar'):TrackingStep[] {
 const ar=lang==='ar';
 if(progress.status==='UNASSIGNED'){
  const labels:Record<string,[string,string]>={SEARCHING:['Recherche d’un livreur en cours','جارٍ البحث عن موصل'],OFFER_PENDING:['Proposition en attente de votre réponse','عرض بانتظار ردك'],EXHAUSTED:['Aucun livreur trouvé','لم يتم العثور على موصل'],CANCELLED:['Recherche annulée','أُلغيت عملية البحث'],DRAFT:['Recherche non démarrée','لم يبدأ البحث'],DISCOVERY:['Demande partagée avec les livreurs','تمت مشاركة الطلب مع الموصلين']};
  const status=labels[progress.searchStatus||'']||labels.DRAFT;
  const upcoming=deliveryTracking({status:'ASSIGNED'},lang).map(step=>({...step,done:false,current:false}));
  return [{label:ar?'تم حفظ الطلب':'Demande enregistrée',done:true,current:false,date:progress.createdAt},{label:status[ar?1:0],done:false,current:true,date:null,showWaiting:false},...upcoming];
 }
 const picked=progress.status==='PICKED_UP'||progress.status==='DELIVERED';
 const delivered=progress.status==='DELIVERED';
 const steps=[
  {label:ar?'تم تعيين موصل':'Livreur attribué',done:true,date:progress.assignedAt},
  {label:ar?'أكد الزبون تسليم الطرد للموصل':'Remise du colis indiquée par le client',done:!!progress.pickupRequestedAt||picked,date:progress.pickupRequestedAt},
  {label:ar?'أكد الموصل استلام الطرد':'Récupération confirmée par le livreur',done:picked,date:progress.pickedUpAt},
  {label:ar?'أبلغ الزبون أو المستلم عن تسليم الطرد':'Livraison indiquée par le client ou le destinataire',done:!!progress.deliveryRequestedAt||delivered,date:progress.deliveryRequestedAt},
  {label:ar?'أكد الموصل التسليم':'Livraison confirmée par le livreur',done:delivered,date:progress.deliveredAt},
 ];
 return steps.map((step,index)=>({...step,current:!step.done&&steps.slice(0,index).every(previous=>previous.done)}));
}
