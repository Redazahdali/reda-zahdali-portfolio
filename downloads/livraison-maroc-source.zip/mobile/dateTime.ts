export function formatDateTime(value:string|null|undefined,lang:'fr'|'ar'):string {
 if(!value)return '';
 const date=new Date(value);
 if(Number.isNaN(date.getTime()))return '';
 return date.toLocaleString(lang==='ar'?'ar-MA':'fr-MA',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:false});
}
