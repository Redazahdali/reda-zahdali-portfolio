export function callablePhone(value:unknown):string|null{
 if(typeof value!=='string'||!/^\+?[0-9 ()-]+$/.test(value))return null;
 const digits=value.replace(/\D/g,'');
 return digits.length>=7&&digits.length<=25?(value.trim().startsWith('+')?'+':'')+digits:null;
}
