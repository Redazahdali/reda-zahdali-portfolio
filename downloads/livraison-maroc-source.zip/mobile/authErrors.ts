export type AuthIssue='input'|'credentials'|'limited'|'verification'|'server'|'network'|'config'|'timeout'|'insecure';
export function authIssue(status:number, code?:string):AuthIssue {
 if(status===400) return 'input';
 if(status===401) return 'credentials';
 if(status===429) return 'limited';
 if(status===503 && code==='verification_unavailable') return 'verification';
 return 'server';
}
export function validEmail(email:string):boolean { const address=email.trim();return address.length<=254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address); }
export function validAuthFields(email:string,password:string):boolean { try{return validEmail(email)&&password.length>=12&&password.length<=128&&encodeURIComponent(password).replace(/%[A-F\d]{2}|./gi,'x').length<=256;}catch{return false;} }

export function safeApiOrigin(value:string|undefined,development:boolean):boolean {
 try {if(!value)return false;const u=new URL(value);if(u.username||u.password||u.search||u.hash||!(u.pathname==='/'||u.pathname===''))return false;return u.protocol==='https:' || (development && u.protocol==='http:' && (u.hostname==='127.0.0.1'||u.hostname==='localhost'));}catch{return false;}
}
