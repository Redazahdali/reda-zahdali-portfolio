export const mapStyleUrl = process.env.EXPO_PUBLIC_MAP_STYLE_URL || 'https://tiles.openfreemap.org/styles/liberty';
export const usingDefaultMapStyle = !process.env.EXPO_PUBLIC_MAP_STYLE_URL;
export const defaultMapAttribution = 'OpenFreeMap · © OpenMapTiles · © OpenStreetMap contributors';
