export type Point = [number, number];
export type AddressState = {text:string; point:Point|null; selected:boolean; adjusted:boolean; complement:string; source:'none'|'search'|'manual'|'gps'; coordinateLabel?:boolean; needsAddress?:boolean};
export type Suggestion = {name:string; detail:string; locality:string; country:string; countryCode:string; point:Point};
export const emptyAddress = ():AddressState => ({text:'',point:null,selected:false,adjusted:false,complement:'',source:'none'});
export const editAddress = (state:AddressState,text:string):AddressState => state.needsAddress && state.point
 ? {...state,text,selected:false,coordinateLabel:false}
 : {...state,text,point:null,selected:false,adjusted:false,source:'none',coordinateLabel:false,needsAddress:false};
type DeviceAddress={formattedAddress?:string|null;name?:string|null;streetNumber?:string|null;street?:string|null;district?:string|null;city?:string|null;region?:string|null;postalCode?:string|null;country?:string|null};
export function formatDeviceAddress(address:DeviceAddress|null|undefined):string {
 if(!address)return '';
 const clean=(v:unknown)=>typeof v==='string'?v.replace(/\s+/g,' ').trim():'';
 const isAddress=(v:string)=>/[\p{L}]/u.test(v)&&!/-?\d{1,3}\.\d{3,}/.test(v);
 const formatted=clean(address.formattedAddress);if(formatted&&isAddress(formatted))return formatted.slice(0,240);
 const street=[clean(address.streetNumber),clean(address.street)].filter(Boolean).join(' ');
 const parts=[street,clean(address.name),clean(address.district),clean(address.city),clean(address.region),clean(address.postalCode),clean(address.country)].filter(v=>v&&!/-?\d{1,3}\.\d{3,}/.test(v));
 const result=parts.filter((v,i)=>parts.findIndex(x=>x.toLocaleLowerCase()===v.toLocaleLowerCase())===i).join(', ');
 return isAddress(result)?result.slice(0,240):'';
}
export function selectLocatedPoint(state:AddressState,point:Point,address:string,source:'gps'|'manual'):AddressState {
 const text=address.trim();return {...state,text,point,selected:!!text,adjusted:false,source,coordinateLabel:false,needsAddress:!text};
}
export function selectMapPoint(state:AddressState,point:Point):AddressState {
 return {...state,point,adjusted:!!state.point,source:'manual',coordinateLabel:false};
}
export function parseSuggestions(data:unknown):Suggestion[] {
 const features=(data as {features?:unknown[]})?.features;
 if(!Array.isArray(features))return [];
 return features.flatMap((item:unknown)=>{
  const f=item as {geometry?:{coordinates?:unknown};properties?:Record<string,unknown>};
  const c=f.geometry?.coordinates, p=f.properties||{};
  if(!Array.isArray(c)||c.length<2||typeof c[0]!=='number'||typeof c[1]!=='number'||!Number.isFinite(c[0])||!Number.isFinite(c[1])||Math.abs(c[0])>180||Math.abs(c[1])>90)return [];
  const clean=(x:unknown)=>typeof x==='string'?x.trim():'';
  const name=clean(p.name)||clean(p.street)||clean(p.city)||clean(p.district);
  if(!name)return [];
  const category=clean(p.type)||clean(p.osm_value)||clean(p.osm_key);
  const city=clean(p.city)||clean(p.district)||clean(p.county)||clean(p.state);
  const countryCode=clean(p.countrycode).toUpperCase(),country=clean(p.country)||(countryCode==='MA'?'Maroc':countryCode);
  return [{name,detail:[category,city,country].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(' · '),locality:city,country,countryCode,point:[c[0],c[1]] as Point}];
 }).slice(0,10);
}
export function prioritizeSuggestions(morocco:Suggestion[],world:Suggestion[],origin?:Point|null):Suggestion[] {
 const all=[...morocco.filter(s=>s.countryCode==='MA'),...world.filter(s=>s.countryCode==='MA'),...world.filter(s=>s.countryCode!=='MA')];
 const seen=new Set<string>();const unique=all.filter(s=>{const key=`${s.name.toLocaleLowerCase()}|${s.point[0]}|${s.point[1]}`;if(seen.has(key))return false;seen.add(key);return true;});
 if(origin&&Number.isFinite(origin[0])&&Number.isFinite(origin[1])&&Math.abs(origin[0])<=180&&Math.abs(origin[1])<=90){
  const radians=Math.PI/180;
  const distance=(p:Point)=>{const lat1=origin[1]*radians,lat2=p[1]*radians,dLat=(p[1]-origin[1])*radians,dLon=(p[0]-origin[0])*radians;return Math.sin(dLat/2)**2+Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2;};
  unique.sort((a,b)=>distance(a.point)-distance(b.point));
 }
 return unique.slice(0,10);
}
export function suggestionAddress(s:Suggestion):string {return [s.name,s.locality,s.country].filter(Boolean).filter((v,i,a)=>a.findIndex(x=>x.toLocaleLowerCase()===v.toLocaleLowerCase())===i).join(', ');}
export function fullAddress(state:AddressState):string {return state.coordinateLabel||!state.text.trim()?'':[state.text.trim(),state.complement.trim()].filter(Boolean).join(', ');}
