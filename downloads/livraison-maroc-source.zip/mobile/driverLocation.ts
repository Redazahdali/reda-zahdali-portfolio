import * as Location from 'expo-location';
import {Platform} from 'react-native';
import {checkDriverGps} from './driverGpsPermission';

export async function getDriverLocation(askPermission:boolean,allowRecent=false) {
 const status=await checkDriverGps({getPermission:Location.getForegroundPermissionsAsync,requestPermission:Location.requestForegroundPermissionsAsync,servicesEnabled:Location.hasServicesEnabledAsync,...(Platform.OS==='android'?{enableServices:Location.enableNetworkProviderAsync}:{})},askPermission,askPermission);
 if(status!=='ready')throw Error('gps');
 let timer:ReturnType<typeof setTimeout>|undefined;
 try {
  const recent=allowRecent?await Location.getLastKnownPositionAsync({maxAge:90000,requiredAccuracy:1000}).catch(()=>null):null;
  const position=recent||await Promise.race([Location.getCurrentPositionAsync({accuracy:Location.Accuracy.Balanced}),new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('gps')),15000);})]);
  if(position.coords.accuracy==null||position.coords.accuracy>1000)throw Error('gps');
  return {latitude:position.coords.latitude,longitude:position.coords.longitude,accuracy:position.coords.accuracy,capturedAt:position.timestamp};
 } finally {if(timer)clearTimeout(timer);}
}
