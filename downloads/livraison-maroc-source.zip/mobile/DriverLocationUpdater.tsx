import {useEffect} from 'react';
import {AppState} from 'react-native';
import {getDriverLocation} from './driverLocation';
import {shouldRefreshDriverLocation} from './driverLocationPolicy';
import {fetchWithTimeout,requireOk} from './http';

type Props={api?:string;session:string;gpsRevision:number};
// Availability is persistent; nearby matching uses only a recent foreground position.
export default function DriverLocationUpdater({api,session,gpsRevision}:Props){
 useEffect(()=>{
  if(!api)return;let active=true,inFlight=false;
  const sync=async()=>{
   if(!active||inFlight||AppState.currentState!=='active')return;inFlight=true;
   try {
    const base=api.replace(/\/$/,'')+'/api/v1/driver/';
    const headers={Authorization:'Bearer '+session,'Content-Type':'application/json'};
    const response=await requireOk(await fetchWithTimeout(base+'me',{headers}));
    const data=await response.json(),profile=data.profile;
    if(!active||!shouldRefreshDriverLocation(profile,AppState.currentState==='active'))return;
    const point=await getDriverLocation(false);
    if(!active||AppState.currentState!=='active')return;
    await requireOk(await fetchWithTimeout(base+'location',{method:'POST',headers,body:JSON.stringify(point)}));
   } catch { /* The availability screen reports missing connectivity or GPS. */ } finally {inFlight=false;}
  };
  void sync();const timer=setInterval(()=>void sync(),60000);
  const sub=AppState.addEventListener('change',state=>{if(state==='active')void sync();});
  return()=>{active=false;clearInterval(timer);sub.remove();};
 },[api,session,gpsRevision]);
 return null;
}
