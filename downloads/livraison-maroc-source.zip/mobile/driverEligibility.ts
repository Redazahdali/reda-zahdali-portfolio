export type DriverProfile={approval_status:string;availability:string;location_confirmed_at:string|null;location_valid_for_ms:number};
export type DriverBlock='profile_unavailable'|'not_approved'|'busy'|'gps_expired'|'offline'|null;
export function driverBlock(profile:DriverProfile|null,elapsedMs=0):DriverBlock {
 if(!profile)return 'profile_unavailable';
 if(profile.approval_status!=='APPROVED')return 'not_approved';
 if(profile.availability==='BUSY'||profile.availability==='RESERVED')return 'busy';
 if(profile.availability==='AVAILABLE' && profile.location_valid_for_ms>elapsedMs)return null;
 if(profile.location_confirmed_at)return 'gps_expired';
 return 'offline';
}
export function remainingOfferMinutes(expiresAt:string,now:number):number {
 const end=Date.parse(expiresAt);
 return Number.isFinite(end)?Math.min(10,Math.max(0,Math.ceil((end-now)/60000))):0;
}
